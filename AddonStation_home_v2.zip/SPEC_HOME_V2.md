# AddonStation — UI Spec: Home v2 (Dark + Light themes, English + Arabic RTL)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp.
This spec **replaces** the previous Home spec. It adds: a lighter, content-first layout, a Light theme, and full Arabic (RTL) support. The bottom navigation bar uses the structure in `SPEC_WALLET_BOTTOMBAR.md`; only its theme colors are given here (section 6).
Placeholders in brackets (`[Username]`, `[Addon name]`, `[Creator]`, `[N]`) are data-bound. All English texts already exist in `strings.xml`; the Arabic texts in section 5 go in `values-ar/strings.xml` (reuse existing Arabic strings where the app already has them).

## 1. What changed vs. the previous Home
| Before | Now |
|---|---|
| Hero 250dp + two big plan cards before any content | Hero 190dp + **one** compact plan strip, content starts higher |
| AC balance pill was display-only | AC pill is a **button** (44dp) that opens the AC Wallet screen |
| Old bottom bar (Home / Store / Community / Creators / Profile) | New bar: Settings · Chat · Home (center, raised) · Store · Profile |
| Dark theme only | **Dark + Light** (follows the existing App theme setting: Dark / Light) |
| Pixel font used for 11sp section labels and everything uppercase | Pixel font **only** for the app name and the Latin hero slogan; section labels use Nunito 800 (Tajawal in Arabic) |
| Chips 40dp, "View all" small | Chips and "View all" have 44dp touch height |
| LTR only | Full **RTL**: all layout mirrors automatically |

## 2. Theme tokens
Put every color in an `AppColors` data class provided through a `CompositionLocal`; build both a dark and a light instance. Switching the App theme setting must recompose immediately and persist. Set status/navigation bar icon colors to match (light icons on dark, dark icons on light).

| Token | Dark | Light |
|---|---|---|
| bg | `#0A0F1C` | `#F4F7FC` |
| surface | `#121A2B` | `#FFFFFF` |
| surfaceHigh | `#1A2438` | `#E8EEF8` |
| barSurface | `#0E1526` | `#FFFFFF` |
| border | `#223049` | `#D5DEEC` |
| text | `#EAF0FA` | `#0E1526` |
| textMuted | `#9DB0CF` | `#53627F` |
| chipText (unselected) | `#C4D1E8` | `#33425F` |
| blue (primary buttons, selected chip) | `#2E7BEF` | `#2563D6` |
| blueLink ("View all", active tab label) | `#6FA8FF` | `#1D4FB8` |
| goldFill (buttons, badges) | `#F0C25E` | `#F0C25E` (text on it: `#1B1405`) |
| goldText (AC balance, gold text) | `#F0C25E` | `#7A5600` |
| planStrip gradient | `#3A2A0B` → `#1B1405` (135°) | `#FFF3D2` → `#FFE7A8` (135°) |
| planStrip border | `#8A6A22` | `#E0B24A` |
| planStrip secondary text | `#E8D5A3` | `#5C4300` |
| epic badge | `#9B6BFF` | `#9B6BFF` |
| tab inactive (icon + label) | `#8EA0BF` | `#53627F` |
| home button inactive bg / icon | `#1A2438` / `#C4D1E8` | `#E8EEF8` / `#33425F` |
| notification badge | `#FF6B78` | `#E5484D` |
| card elevation | none (use 1dp border) | shadow 0 1dp 3dp `#0E1526`@8% + 1dp border |
| bar shadow | 0 10dp 30dp black@50% | 0 10dp 30dp `#0E1526`@18% |

Always-dark elements in both themes: hero image overlay and the text on it (white / gold `#F0C25E` / `#D3DDF0`), because they sit on a photo.
Contrast: all text/background pairs above are chosen to meet WCAG 4.5:1 (3:1 for large text and icons). Do not use `#6B7A94` or other lighter greys for text. Verify with a contrast checker after implementation.
Values are approximated from the app icon; if the project already defines brand colors in its theme, prefer those and keep the roles above.

## 3. Typography
- **App name** "ADDONSTATION" (both languages, it is a brand): pixel font `pixel_regular.ttf`, 15sp, letter spacing 1sp.
- **English hero slogan**: pixel font 15sp, line height 1.5, color `#F0C25E`.
- **Arabic hero slogan**: **Tajawal** ExtraBold 20sp, line height 1.35 — the pixel font has no Arabic glyphs, never use it for Arabic text.
- **Section titles**: 14sp/800, uppercase with letter spacing 1sp in English; in Arabic no uppercase and no letter spacing. Font: Nunito (EN) / Tajawal (AR).
- Body: Nunito 500/700/800 (EN), Tajawal 500/700/800 (AR). Bundle Tajawal in `res/font/` (or use Downloadable Fonts) and choose the font family from the app language.
- Sizes: greeting small 13/700 · greeting big 22/800 · card title 14/800 · secondary 12 · buttons 13–14/800 · badges 10/800 · tab labels 11.
- Never render Arabic text with a letter-spacing value other than 0.

## 4. Screen layout (top → bottom)
Column, bg `bg`, vertical scroll; bottom content padding = bar height 72 + top overflow 20 + 12 + system inset. All horizontal paddings are 16 and use *start/end* (not left/right).

1. **Top bar** (padding 16/16/8, gap 10, centered): app icon 40×40 radius 10 · "ADDONSTATION" (weight 1) · **AC pill button** (44 tall, radius 22, bg surfaceHigh, padding start 6 / end 12; `coin_ac.png` 28 + balance 15sp/800 goldText; opens AC Wallet) · **Bell** (44 circle, bg surface, 1dp border; opens notifications).
2. **Greeting block** (padding 4/16/0): small line 13sp/700 muted — "Good morning" before 12:00, "Good evening" from 18:00 (afternoon uses the same evening string unless the app has a separate one); big line 22sp/800 — logged in "Welcome back, [Username]"; logged out "Welcome to" + app name. **Search field** under it: height 48, radius 14, bg surface, 1dp border, padding 14, search icon 20 + hint, margin top 12 (opens search).
3. **Hero** (margin 14/16/0): height **190**, radius 20, `hero_home.jpg` cover-fit, overlay gradient transparent(5%) → `#0A0F1C`@92% (stop 80%). Bottom row (padding 16/14, gap 12, aligned to bottom): column [slogan, then subtitle 12sp `#D3DDF0` margin top 4] weight 1 + button **Start now** (44 tall, radius 12, bg blue `#2E7BEF`, white 14/800, padding 20). Logged out: also show "Join the family" as a text/outlined button under the subtitle. Logged in: "Start now" only.
4. **Plan strip** (margin 12/16/0): one row, radius 16, padding 10×12, gradient + 1dp border from tokens. Star circle 40 (gold fill, dark star) · column [plan title 14sp/800 e.g. "Your plan: Free"; second line 12sp e.g. "Free content · Basic access"] weight 1 · **Upgrade** button (44, radius 12, gold fill, `#1B1405` text 13/800, padding 18). Paid plan: title = plan name, second line "Expires on [date]", button hidden. Legendary: hide the strip. Logged out: replace with the Guest card (text "Sign in to continue your adventure", buttons Sign in / Create account).
5. **Chips** (padding 14/16/0, gap 8, horizontally scrollable): height **44**, radius 22, padding 18, 14sp. Selected "All": bg blue, white, 800. Unselected: bg surface, 1dp border, chipText, 700. Items: All · Addons · Worlds · Favorites. Selection filters the lists below.
6. **Section header** (padding 22/16/10): title (weight 1) + "View all" link 13sp/700 blueLink, min height 44.
7. **LATEST ADDONS** — horizontal list, padding 16, gap 12. Card width 150, radius 14, bg surface, 1dp border (+ light shadow); thumbnail 100 tall (`thumb_placeholder.jpg` fallback), badge at top-**start** 6dp: NEW blue/white, EPIC `#9B6BFF`/white, LEGENDARY gold/`#1B1405` (10sp/800, radius 8, padding 2×8; none for free items); text block padding 8/10/10: title 14/800, "By [Creator]" 12 muted.
8. **MOST DOWNLOADED** — vertical list, gap 10, padding 16. Row: radius 14, bg surface, 1dp border, padding 10, gap 12: thumb 64×64 radius 10 · column [title 14/800, "By [Creator]" 12] weight 1 · **Download** button 44×44 radius 12, bg blue, white download icon 20.
9. **FEATURED CREATORS** — caption 12sp muted "Creator specials selected by AddonStation" (padding 0/16/10), then a horizontal row (padding 16, gap 14): item width 72 centered, avatar 64 circle with 2dp ring (rank colors: gold `#F0C25E`, purple `#9B6BFF`, blue `#2E7BEF`, border color), name 12/700 below. Fallback avatar `ic_default_profile.jpg`.
10. **Bottom bar** — see `SPEC_WALLET_BOTTOMBAR.md`, with these theme values:
    - container bg = barSurface, border 1dp = border, shadow from tokens; Home button ring (3dp) = screen `bg`.
    - active tab: gradient `#2E7BEF` → `#4C9AFF`, white filled icon, label = blueLink; inactive: icon/label = tab inactive; Home inactive: bg/icon from tokens.
    - badge border color = barSurface.

### States
Loading: skeleton blocks (surfaceHigh) in the same shapes, shimmer. Empty section: "No content published yet" (muted, centered). Error: "Something went wrong" + "Tap to retry" (44 tall button). Offline: use the existing offline string with a small banner under the top bar.

## 5. Arabic (RTL)
**Implementation:** `android:supportsRtl="true"` in the manifest; use `Arrangement.Start/End`, `start/end` paddings and `Modifier.padding(start=…, end=…)`; never `left/right`. The app language setting must set the locale and layout direction together (`LocalLayoutDirection` follows it). Test with Arabic locale on a real device.

**Mirrors automatically:** order of the top bar (icon at the right, bell at the left), horizontal lists (start from the right), badge position (top-start), text alignment (right), progress/slider direction, the bottom bar order (Profile · Store · Home · Chat · Settings from left to right, Home stays centered).
**Icons that must flip (directional):** back arrow, chevrons, "send", share. Use `AutoMirrored` Material icons.
**Icons that must not flip:** bell, search, download, star, home, person, settings, coin, flame, gift.
**Numbers:** keep Western digits (0–9) as the app does today; AC balance and counts use the same number formatter. Mixed text such as "[N] AC" keeps its order — wrap Latin/number runs with Unicode isolates if the layout shows reordering.
**Text:** no uppercase transformation, no letter spacing, line height 1.35–1.5, font Tajawal. The brand "ADDONSTATION" stays Latin and keeps the pixel font. Allow Arabic strings 30% longer than English (buttons wrap or grow; don't clip).

**Arabic strings** (`values-ar/strings.xml`; keep the app's existing Arabic wording if it differs):
| Key (English) | Arabic |
|---|---|
| Good evening / Good morning | مساء الخير / صباح الخير |
| Welcome back, [Username] | مرحباً بعودتك، [الاسم] |
| Search addons and worlds... | ابحث عن الإضافات والعوالم... |
| DREAM IT. BUILD IT. CREATE IT. | احلم. ابنِ. أبدع. |
| Addons and worlds ready for your adventure | إضافات وعوالم جاهزة لمغامرتك |
| Start now | ابدأ الآن |
| Your plan: Free | خطتك: مجانية |
| Free content · Basic access | محتوى مجاني · وصول أساسي |
| Upgrade | ترقية |
| All / Addons / Worlds / Favorites | الكل / إضافات / عوالم / المفضلة |
| LATEST ADDONS | أحدث الإضافات |
| MOST DOWNLOADED | الأكثر تنزيلاً |
| FEATURED CREATORS | المبدعون المميزون |
| View all | عرض الكل |
| By [Creator] | بواسطة [المنشئ] |
| Creator specials selected by AddonStation | اختيارات المبدعين من AddonStation |
| Tabs: Settings / Chat / Home / Store / Profile | الإعدادات / الشات / الرئيسية / المتجر / البروفايل |

## 6. Accessibility & QA checklist
- Every interactive element ≥ 44×44dp; AC pill, bell, chips, "View all", tabs have content descriptions (tabs: the label text).
- Contrast: verify body text, muted text, gold text and white-on-blue in **both** themes.
- Test matrix: Dark/EN, Light/EN, Dark/AR, Light/AR; font scale 100% and 130%; small screen (360dp wide).
- Check that the hero text stays readable on every theme (it sits on the photo overlay, not on the theme background).
- Reduce motion: skeleton shimmer and count-up animations respect the system setting.

## 7. Assets
```
assets/images/hero_home.jpg           hero background
assets/images/app_icon.png            top bar app icon
assets/images/coin_ac.png             AC coin in the pill
assets/images/thumb_placeholder.jpg   fallback thumbnail for cards/rows
assets/images/ic_default_profile.jpg  fallback creator avatar
assets/fonts/pixel_regular.ttf        pixel font (brand + English slogan only)
assets/fonts/roboto_medium_numbers.ttf
```
Copy images to `res/drawable-nodpi/` (keep file names) and fonts to `res/font/`. Tajawal is not included — add it from Google Fonts (Tajawal Medium / Bold / ExtraBold) to `res/font/` or use Downloadable Fonts.
