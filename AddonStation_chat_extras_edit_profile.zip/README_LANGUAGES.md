# Languages — Chat extras + Edit profile

The app has **8 languages**: English (default), العربية `ar` (RTL), Français `fr`, Türkçe `tr`, Español `es`, Русский `ru`, Português `pt`, 中文 `zh`.

## Strings
`res/values*/strings_chat_editprofile.xml` (one per language) holds the **5 new keys**: `edit_profile_tab_item`, `edit_profile_unsaved`, `chat_admin_only`, `comm_room_cash` and `comm_rules_banner_plain` (the app's own banner text without the emoji) (the room name is a proposal — confirm it). All other texts used by these screens already exist in the app in all 8 languages (use the existing keys; for keys that start with an emoji use the app's `*_plain` copies).

## Layout rules for all languages
- Only Arabic is RTL: use start/end everywhere, never left/right. Allow **30–40% longer text** (fr, es, pt, ru) — buttons grow, labels wrap, no fixed widths; Chinese is shorter.
- No uppercase transform or letter spacing for ar and zh. Turkish uppercase needs the Turkish locale (i → İ).
- **Fonts:** the pixel font covers Latin with fr/es/pt/tr accents but **not Cyrillic, Chinese or Arabic**: use Nunito ExtraBold for ru, the system CJK font (bold) for zh, Tajawal ExtraBold for ar. Keep the pixel font for Latin text and the brand name.
- Dates, numbers, plurals: locale formatters and plural resources only.
- Test: Dark/Light × en · ar · ru · zh, font scale 100% and 130%.
