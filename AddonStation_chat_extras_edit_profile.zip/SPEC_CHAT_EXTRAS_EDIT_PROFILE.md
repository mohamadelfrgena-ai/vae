# AddonStation — UI Spec: Rooms list v2 · Attach sheet · Media messages · Composer states · Edit profile (sections, avatar packs, separate Item)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light and Arabic (RTL) are specified. This package is based on the latest build: it keeps the app's logic (rooms, roles, uploads, plans, avatar packs) and changes layout, icons and colors only.
`reference/chat_editprofile_preview.html` is a clickable reference (screen selector, state buttons, Light/Dark, English/Arabic). Open it in a browser and follow it for the exact look. Tokens (dark/light), fonts, chips, fields and sheets are the same as `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0. The chat room header, message bubbles, emoji/stickers panels and the bottom bar are in `SPEC_CHAT_PANELS_STORE.md` and `SPEC_WALLET_BOTTOMBAR.md`.
All texts already exist in the app in 8 languages (see `README_LANGUAGES.md`); the 5 new keys are in `res/values*/strings_chat_editprofile.xml`.

| Screen | Opens from |
|---|---|
| Rooms list (Community) | Chat tab |
| Attach sheet | add (photo) button in the composer |
| Media messages | inside a room |
| Composer states | inside a room |
| Edit profile | Profile → Edit my profile |

## 1. Rooms list (Community tab)
Bottom bar visible (Chat tab selected). Title `comm_title` in the pixel font 18sp, no back button.
- **Rules banner:** surface, 1dp border, radius 14, padding 12×14, shield icon 18 + `comm_rules_banner_plain` 12sp chipText.
- **Sections** `comm_main_rooms` and `comm_lang_rooms` (section label 13sp/800 goldText), each in one card (surface, 1dp border, radius 16, 1dp dividers). Main rooms: General, Minecraft, Creator, Support, Social Media Makers and the new **Cash** room (icon `ic_room_cash`, name key `comm_room_cash` — confirm the name). Language rooms: English, Arabic, French, Turkish, Spanish, Russian, Portuguese, Chinese with their `ic_room_lang_*` icons.
- **Room row** (min height 72, padding 12×14, gap 12): icon 48 circle · column [name 15sp/800 + (if read-only for the user) a **Locked chip** `comm_locked` (10sp/800, surfaceHigh, textMuted, radius 8, lock icon 12) + time 11sp muted at the end · last message 12sp muted, one line, ellipsis (weight 1) + online count `chat_online` (11sp, okText) + **unread badge** (min 20, radius 10, blue, white 11sp/800)].
- Guests see the same list with `comm_members_only` instead of entering (rooms are locked).

## 2. Attach sheet
Bottom sheet (barSurface, radius 24 top, padding 8/16/24, grab handle) over the dimmed room. Two option cards in a 2-column grid (gap 12): card = surface, 1dp border, radius 18, padding 16×10, min height 150, centered column gap 10: icon tile 56 (radius 18) + label 14sp/800 + helper 12sp muted.
- **Photo** (`chat_attach_photo`, image icon, blue; helper `chat_image_formats`, `chat_image_max`).
- **Audio / Video file** (`chat_attach_media`, video icon, purple; helper `chat_media_max`).
- **Member:** the media card is disabled (70% opacity) with a chip **`chat_admin_only`** (lock 12, 10sp/800, surfaceHigh) and an info message under the grid (blue@12% bg, 1dp blue@35%, radius 14, padding 12×14, info icon 18) with `chat_media_admin_only`. **Admin:** both cards enabled. Footer hint `chat_image_formats` · `chat_image_max` (12sp muted, centered).

## 3. Media messages
- **Audio bubble** (width 250, surface, 1dp border, radius 16/16/16/4, padding 10×12, gap 10): play button 40 circle (blue, white play icon 18) · waveform (24 bars, gap 2, up to 30 high, blueLink) + a row "0:00 / 0:34" (11sp muted) and mic icon 12 + `chat_audio_label_plain`. **Own audio:** blue gradient bubble, white play button with blue icon, white waveform. Playing: bars fill left→right, button becomes pause.
- **Video bubble:** thumbnail 230×150, radius 16/16/16/4 (mirrored in RTL), center play circle 56 (black@60%, 2dp white border, white icon 26), duration chip bottom-end (black@60%, white 11sp/700, radius 10, padding 2×8), tag top-start (video icon 12 + `chat_video_label_plain`, black@55%). Tap → full-screen player (content description `chat_play_video`).
- **Announcement card** (`chat_announcement`): gradient 135° `#2A1F08` → `#121A2B` (light `#FFF3D2` → `#FFFFFF`), 1dp gold border, radius 16, padding 12×14, gap 12: megaphone tile 40 (gold) · column [label 11sp/800 goldText, letter spacing .6sp; text 14sp].
- **Uploading** (own, radius 16/16/4/16, width 230, surfaceHigh): progress ring 36 (3dp blue arc, upload icon 16) · column [progress bar 6 high (track border color, fill blue) + `chat_uploading` 11sp muted] · cancel ✕. **Failed:** the media is dimmed to 60% and under it, end-aligned, an alert icon 14 + `chat_send_failed` · **`chat_tap_to_retry`** (errorText 12sp/700, retry underlined).
- Rules unchanged: only admins send audio/video (`chat_media_admin_only`, `chat_media_max` 100 MB); confirmations `chat_audio_sent`, `chat_video_sent` as snackbars.

## 4. Composer states
- **Replying:** strip above the composer (barSurface, 1dp top border, padding 8/12/8/16, gap 10): 3dp blue bar (full height) · column [reply icon 14 + `chat_replying_to` (without the arrow) 12sp/800 blueLink; quoted text 12sp muted, one line] · close button 36.
- **Typing:** strip (barSurface, 1dp top border, padding 6/16/8, 12sp muted): three 6dp dots (blueLink, opacity pulse 1.2s, static for reduced motion) + `chat_typing`.
- **New messages:** divider at the first unread: 1dp blue lines on both sides with `chat_new_tag` (11sp/800 blueLink, letter spacing .8) in the middle; floating pill centered 8dp above the composer (36 high, radius 18, blue fill, white 13sp/800, arrow-down icon 16, shadow 0 6dp 18dp blue@45%) with `chat_new_messages_plain` — tap scrolls to the bottom. Date chips: `chat_today`, `chat_yesterday` (centered, surfaceHigh, 12sp/800 muted, radius 14).
- **Empty room:** 88 circle (surfaceHigh) with a chat icon 40 + `chat_no_messages_plain` 14sp muted.
- **Loading:** 4 skeleton message rows (avatar 36 + a 12-high name bar at 30% and a 36-high bubble bar at 70%, shimmer 1.4s, static for reduced motion) + `chat_loading_messages` 12sp muted centered.

## 5. Edit profile (redesigned)
Top bar (back + title `profile_edit_plain`), then a vertical scroll, then a fixed action bar. The screen is organised in **sections**; the user picks a section, then picks from **packs**; everything shows live in the preview card.
### 5.1 Preview card (top, always visible)
Surface, 1dp border, radius 20. **Banner** 88 high (the user's banner, or the default) with a gradient overlay (transparent at 30% → `#0A0F1C`@55%) and a **Preview** chip (`edit_profile_preview`, top-start 10, black@65%, white 10sp/800, radius 8, padding 3×9). Row (padding 0/14/14, gap 12, bottom-aligned): **avatar** 68 circle with a 3dp gold border, overlapping the banner by 30, status dot 16 (green/grey, 3dp surface border) · column [name 18sp/800 + **item badge** (28 circle, accent@20% fill, 1dp accent@50% border, glow 12dp accent@55%) + level chip (11sp/800, surfaceHigh, radius 8); `@username` 12sp muted]. Changing the avatar, banner or item updates it instantly (Save is only needed to keep the changes).
### 5.2 Section tabs
Container: surface, 1dp border, radius 18, padding 4, gap 6, margin top 14. **Four equal segments**, height 60, radius 14, column [icon 22 + label 11sp/800]: **Avatar** (`edit_profile_avatar_label`) · **Banners** (`profile_banner_section`) · **Item** (`edit_profile_tab_item`) · **About** (`profile_tab_about`). Selected = blue fill, white, shadow 0 6dp 16dp blue@40%.
### 5.3 Avatar section (packs)
- **Pack chips** (horizontal scroll, edge to edge, margin 14/−16/0, gap 8): height 40, radius 20, padding 0/14/0/6, 13sp/800: 26 circle thumbnail (the pack's first picture; **All** uses a grid icon) + pack name + a lock icon (12, goldText) for packs the plan does not include. Selected = blue fill, white. Packs are the app's existing avatar packs (the same packs managed in the admin "Avatars" screen).
- **Search** `profile_assets_search` (48 high, radius 14) and the counter `profile_assets_count` ("8 of 24 pictures", 12sp muted). Empty result: 88 circle + `edit_profile_no_results`.
- When a pack is selected: section header — pack name uppercase (12sp/800 goldText, letter spacing .6) + count chip (surfaceHigh, muted, radius 10) + tier chip (Epic purple / Legendary gold) when locked + a 1dp divider.
- **Grid:** 4 columns, gap 12, tiles square, radius 20, 1dp border. **Selected:** 3dp blue border + 4dp blue@22% halo + check badge 22 (top-end, blue, 2dp bg border). **Locked:** picture dimmed to 35% + lock badge 22 (bottom-end, `#0A0F1C`@80%, gold lock). Tapping a locked tile shows the **upgrade card** below the grid (radius 16, gradient `#3A2A0B` → `#1B1405`, 1dp gold border, lock icon 22 + `plan_locked_avatars_plain` 12sp + **Upgrade** button `item_upgrade`, 44 high, gold).
### 5.4 Item section (separate from avatar and banner)
- **Chat preview card** (radius 18, surface, padding 12): label `plan_item_section` 12sp muted + a mini message row (avatar 36 · name 12sp/800 blueLink + item badge 22 · bubble with `[Message text]`).
- **None row** (height 60, radius 16, surface, 1dp border, margin 12): a 44 circle with ✕ + `profile_item_none` + (when selected) the **Equipped** tag (`profile_item_equipped`); selected = 3dp blue border.
- **Sections** with the same section header style: `edit_profile_epic_item` (tier chip Epic when locked) and `edit_profile_golden_item` (tier chip Legendary when locked). Grid 4 columns, gap 12/10: tile (square, radius 20, item icon 28 in its accent color) + the item name under it (11sp/700 muted, one line). **Selected:** blue 3dp border + halo + **Equipped** ribbon (9sp/800, white on blue, radius 7) centered on the top edge. **Locked:** icon at 45% + lock badge + the upgrade card (`plan_locked_items_plain`). Empty section: `edit_profile_no_items` (14sp muted, centered).
- The item is **independent**: choosing or removing an item never changes the avatar or the banner, and vice versa.
### 5.5 Banners section
Same pack chips (All + packs). Grid 2 columns (gap 10, tiles 16:7, radius 14, 1dp border; selected = 3dp blue + check; locked = dimmed + lock badge). Button **`profile_banner_clear`** (outlined, errorText, 44 high). Locked note card `plan_locked_banner_note_plain` with **Upgrade**.
### 5.6 About section
Field **`profile_custom_status`** (max 60) and **`profile_about_me`** (max 160, multiline min 92), each with a counter at the end of its label (12sp muted); card with the **Online status** switch (`profile_online_status`; disabled with `plan_locked_online_plain` unless Legendary).
### 5.7 Action bar (fixed)
barSurface, 1dp top border, padding 8/16/14. When there are unsaved changes, a caption line `edit_profile_unsaved` (warning color, 12sp/800, 8dp dot) sits above two buttons (gap 10, height 48, radius 12): **Discard** (`edit_profile_discard`, outlined, weight 1) and **Save** (`common_save`, primary gradient, weight 2). Save is disabled when nothing changed. Back with changes shows the existing dialog (`edit_profile_discard_title`, `edit_profile_discard_body`, `edit_profile_keep_editing`). Keep the app's current dirty tracking and plan locks.

## 6. Light theme, Arabic (RTL), accessibility
- Light: use the light tokens; the banner overlay and media overlays stay dark; the announcement card uses its light gradient.
- RTL: start/end everywhere; bubble corner radii mirror; the waveform and progress fill from the right; tabs, chips and grids flow from the right; chevrons AutoMirrored.
- Accessibility: targets ≥ 44dp; tab segments use the tab role; pack chips and tiles announce name, locked state and selection ("selected", "locked, requires Epic"); icon-only buttons have content descriptions; the typing and upload states use polite live regions.

## 7. Assets
```
reference/chat_editprofile_preview.html   clickable reference
assets/images/ic_default_profile.jpg      default avatar (fallback)
```
Room icons (`ic_room_*`, including `ic_room_cash`) and fonts are already in the app. Strings: `res/values*/strings_chat_editprofile.xml` (8 languages) — merge into the project.
