package com.addonstation.app.ui.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Someone else's profile (opened from chat / community). */
@Composable
fun PublicProfileScreen(
    name: String, handle: String, role: String, level: Int, xp: Float, bio: String?,
    downloads: Int, worlds: Int, published: Int, isFriend: Boolean, isOnline: Boolean,
    onBack: () -> Unit, onMessage: () -> Unit, onAddFriend: () -> Unit,
    avatar: @Composable () -> Unit,
    contentGrid: @Composable () -> Unit = {},
) {
    Column(Modifier.fillMaxSize().background(PBg).verticalScroll(rememberScrollState())) {
        ProfileBanner(150) {
            TextButton(onClick = onBack, modifier = Modifier.padding(8.dp)) { Text("←", color = Color.White, fontSize = 22.sp) }
        }
        Column(Modifier.padding(horizontal = 16.dp).offset(y = (-44).dp)) {
            ProfileAvatar(level, 92, avatar)
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, color = Color.White, fontFamily = PixelFont, fontSize = 24.sp)
                Spacer(Modifier.width(8.dp)); RoleBadge(role)
            }
            Text(
                "@$handle  ·  ${if (isOnline) "🟢 Online" else "⚪ Offline"}",
                color = PMuted, fontSize = 13.sp
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onMessage, shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PGreen, contentColor = Color.Black),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text("💬 Message", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = onAddFriend, shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, PGreen), enabled = !isFriend,
                    modifier = Modifier.weight(1f).height(48.dp)
                ) { Text(if (isFriend) "✓ Friends" else "🤝 Add friend", color = PGreen, fontWeight = FontWeight.Bold) }
            }
        }
        Column(Modifier.offset(y = (-28).dp)) {
            SectionTitle("📝", "About")
            Box(Modifier.padding(horizontal = 16.dp).fillMaxWidth().background(PCard, RoundedCornerShape(16.dp)).padding(16.dp)) {
                Text(bio ?: "No bio yet.", color = PMuted, fontSize = 14.sp)
            }
            SectionTitle("🏆", "Level & reputation")
            XpBar(xp, "Level $level · Active member")
            SectionTitle("📊", "Statistics")
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("$downloads", "Downloads", Modifier.weight(1f))
                StatCard("$worlds", "Worlds", Modifier.weight(1f))
                StatCard("$published", "Published", Modifier.weight(1f))
            }
            SectionTitle("📦", "Content")
            if (published == 0) {
                Text(
                    "No content published yet", color = PMuted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(24.dp)
                )
            } else contentGrid()
            Spacer(Modifier.height(32.dp))
        }
    }
}
