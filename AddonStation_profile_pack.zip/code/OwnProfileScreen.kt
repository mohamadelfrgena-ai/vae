package com.addonstation.app.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** My own profile (Profile tab). */
@Composable
fun OwnProfileScreen(
    name: String, handle: String, role: String, memberSince: String,
    level: Int, xp: Float, plan: String, email: String, bio: String?,
    avatarItem: String?, hidden: Boolean, acBalance: Int,
    downloads: Int, content: Int, favorites: Int,
    onEdit: () -> Unit, onOpenPlan: () -> Unit, onToggleHidden: (Boolean) -> Unit,
    onOpenAvatarItem: () -> Unit, onOpenEmail: () -> Unit, onOpenSettings: () -> Unit,
    avatar: @Composable () -> Unit,
) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("About", "My content", "Favorites", "My plan")

    Column(Modifier.fillMaxSize().background(PBg).verticalScroll(rememberScrollState())) {
        ProfileBanner(120) {
            Text(
                "🪙 $acBalance AC", color = PGold, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = .35f))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        Row(Modifier.padding(horizontal = 16.dp).offset(y = (-40).dp), verticalAlignment = Alignment.Bottom) {
            ProfileAvatar(level, 88, avatar)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.padding(bottom = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = Color.White, fontFamily = PixelFont, fontSize = 22.sp)
                    Spacer(Modifier.width(8.dp)); RoleBadge(role)
                }
                Text("@$handle · Member since $memberSince", color = PMuted, fontSize = 12.sp)
            }
        }
        Column(Modifier.offset(y = (-24).dp)) {
            Button(
                onClick = onEdit, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PGreen, contentColor = Color.Black),
                modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(48.dp)
            ) { Text("✏️ Edit profile", fontWeight = FontWeight.Bold) }

            Spacer(Modifier.height(14.dp))
            XpBar(xp, "Level $level · ${(xp * 100).toInt()}% to next level")
            Spacer(Modifier.height(12.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("$downloads", "Downloads", Modifier.weight(1f))
                StatCard("$content", "My content", Modifier.weight(1f))
                StatCard("$favorites", "Favorites", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            ScrollableTabRow(
                selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = PGreen,
                edgePadding = 16.dp, divider = {}
            ) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i },
                        text = { Text(t, color = if (tab == i) PGreen else PMuted) })
                }
            }
            if (tab == 0) {
                SectionTitle("📝", "Bio")
                Box(
                    Modifier.padding(horizontal = 16.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp)).background(PCard).padding(16.dp)
                ) { Text(bio ?: "You haven't added a bio yet.", color = PMuted, fontSize = 14.sp) }

                SectionTitle("⚡", "Account")
                PlanCard(plan, onOpenPlan)
                Spacer(Modifier.height(10.dp))
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AccountTile("🙈", "Online status", if (hidden) "Hidden" else "Visible", Modifier.weight(1f),
                            onClick = { onToggleHidden(!hidden) }) {
                            Switch(checked = hidden, onCheckedChange = onToggleHidden,
                                colors = SwitchDefaults.colors(checkedTrackColor = PGreen, checkedThumbColor = Color.Black))
                        }
                        AccountTile("🎽", "Avatar / item", avatarItem ?: "None", Modifier.weight(1f), onOpenAvatarItem)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AccountTile("✉️", "Email", email, Modifier.weight(1f), onOpenEmail)
                        AccountTile("⚙️", "Full settings", "All options", Modifier.weight(1f), onOpenSettings)
                    }
                }
            }
            Spacer(Modifier.height(100.dp)) // space for bottom nav
        }
    }
}

@Composable
private fun PlanCard(plan: String, onClick: () -> Unit) {
    Row(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF2A2410)).border(1.dp, PGold, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(PGold), contentAlignment = Alignment.Center) { Text("👑", fontSize = 20.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(plan, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            Text("Your current plan", color = Color(0xFFD9B45A), fontSize = 12.sp)
        }
        Text("Manage", color = PGold, fontSize = 12.sp,
            modifier = Modifier.border(1.dp, PGold, CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
    }
}

@Composable
private fun AccountTile(
    icon: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null,
) {
    Column(
        modifier.heightIn(min = 96.dp).clip(RoundedCornerShape(16.dp)).background(PCard)
            .border(1.dp, Color.White.copy(alpha = .06f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(PCardHi), contentAlignment = Alignment.Center) { Text(icon) }
            trailing?.invoke()
        }
        Column {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(sub, color = PMuted, fontSize = 12.sp, maxLines = 1)
        }
    }
}
