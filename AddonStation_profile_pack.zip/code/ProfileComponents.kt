package com.addonstation.app.ui.profile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Replace with your existing palette / Minecraft font
val PBg = Color(0xFF0B1220)
val PCard = Color(0xFF131C2E)
val PCardHi = Color(0xFF1A2540)
val PGreen = Color(0xFF3DDC84)
val PGreenDark = Color(0xFF1E9E5A)
val PMuted = Color(0xFF8A97B2)
val PGold = Color(0xFFFFC53D)
val PixelFont: FontFamily = FontFamily.Monospace // <- put your Minecraft font here

@Composable
fun ProfileBanner(height: Int = 140, content: @Composable BoxScope.() -> Unit = {}) {
    Box(
        Modifier.fillMaxWidth().height(height.dp)
            .background(Brush.linearGradient(listOf(Color(0xFF14532D), Color(0xFF0F2A4A), Color(0xFF3B1D6E)))),
        content = content
    )
}

@Composable
fun ProfileAvatar(level: Int, size: Int = 96, content: @Composable () -> Unit) {
    Box(contentAlignment = Alignment.BottomCenter) {
        Box(
            Modifier.size(size.dp).clip(CircleShape)
                .border(BorderStroke(3.dp, Brush.sweepGradient(listOf(PGreen, Color(0xFF4DA3FF), PGreen))), CircleShape)
                .background(PCard).padding(4.dp).clip(CircleShape),
            contentAlignment = Alignment.Center
        ) { content() }
        Box(
            Modifier.offset(y = 10.dp).clip(RoundedCornerShape(50)).background(PGreen)
                .padding(horizontal = 10.dp, vertical = 2.dp)
        ) { Text("LV $level", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun RoleBadge(text: String) {
    Text(
        "$text ✦", color = PGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(PGreen.copy(alpha = .14f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(PCard)
            .border(1.dp, Color.White.copy(alpha = .06f), RoundedCornerShape(16.dp)).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = PGreen, fontFamily = PixelFont, fontSize = 22.sp)
        Spacer(Modifier.height(2.dp))
        Text(label, color = PMuted, fontSize = 12.sp)
    }
}

@Composable
fun SectionTitle(emoji: String, title: String) {
    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 18.sp)
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontFamily = PixelFont, fontSize = 16.sp)
    }
}

@Composable
fun XpBar(progress: Float, label: String) {
    Column(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(PCard).padding(16.dp)
    ) {
        LinearProgressIndicator(
            progress = { progress }, color = PGreen, trackColor = PCardHi,
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape)
        )
        Spacer(Modifier.height(8.dp))
        Text(label, color = PMuted, fontSize = 12.sp)
    }
}
