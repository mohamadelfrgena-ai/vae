محتويات الحزمة
1) code/  : ProfileComponents.kt, OwnProfileScreen.kt, PublicProfileScreen.kt
2) PROMPT_for_Arena.txt : النص الجاهز لإعطائه لأرينا

ما تعطيه لأرينا:
- النص من PROMPT_for_Arena.txt
- ملفات مجلد code (الصق محتواها)
- صورتا شاشتيك الأصليتان
- لقطة شاشة للمعاينة النهائية (من المحادثة)
- ملفات مشروعك: Color.kt و Theme.kt و Type.kt  (لتناسق الألوان والخط)

بعد الناتج: أرسله لي لأدمجه في المشروع.
