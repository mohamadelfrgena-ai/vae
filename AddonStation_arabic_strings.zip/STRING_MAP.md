# Design text → string keys

Use the **existing** keys below in the new screens. A key marked ⚠ is an admin/other-screen key — prefer the first non-admin key when there is one. For strings that begin with an emoji in the app (e.g. `✏️ Edit profile`) the new designs use a vector icon instead: use the `*_plain` key from `strings_v2.xml`.

| Design text (English) | Key | Arabic |
|---|---|---|
| Good morning | `greeting_morning` | صباح الخير |
| Good evening | `greeting_evening` | مساء الخير |
| Welcome back, %1$s | `home_welcome_back` | مرحبًا بعودتك، سيد %1$s |
| Welcome to | `home_welcome_guest` | مرحبًا بك في |
| Search addons and worlds... | `home_search_hint` | ابحث عن إضافات وعوالم… |
| DREAM IT. | `splash_dream_it` | احلم بها. |
| BUILD IT. | `splash_build_it` | ابنِها. |
| CREATE IT. | `splash_create_it` | أبدعها. |
| Addons and worlds ready for your adventure | `store_title` | إضافات وعوالم جاهزة لمغامرتك |
| Start now | `plan_start_now` | ابدأ الآن |
| Join the family | `auth_signup_title` | انضم إلى العائلة |
| Your plan: Free | `home_plan_card_free_title` | خطتك: مجاني |
| Free content · Basic access · No subscription | `plan_free_features` | محتوى مجاني · وصول أساسي · بدون اشتراك |
| Upgrade | `item_upgrade (⚠ also: home_qa_upgrade, profile_upgrade)` | ترقية |
| Buy subscription | `plan_buy_plain` | شراء اشتراك |
| Expires on %1$s | `home_plan_expires` | تنتهي في %1$s |
| All | `common_all` | الكل |
| Addons | `store_tab_addons (⚠ also: admin_addons)` | الإضافات |
| Worlds | `store_tab_worlds (⚠ also: profile_stat_worlds, admin_worlds)` | العوالم |
| Favorites | `profile_tab_favorites (⚠ also: profile_stats_favorites)` | مفضلتي |
| Latest addons | `home_latest_plain` | أحدث الإضافات |
| Most downloaded | `store_sort_downloads` | الأكثر تحميلًا |
| Featured creators | `home_creators (⚠ also: creator_featured)` | المبدعون المميزون |
| View all | `view_all` | عرض الكل |
| By %1$s | `item_by` | بواسطة %1$s |
| Creator specials selected by AddonStation | `home_exclusives_sub` | عروض خاصة من المبدعين اختارتها AddonStation |
| Home | `nav_home` | المنزل |
| Store | `nav_store` | المتجر |
| Chat | `admin_chat_plain` | الدردشة |
| Profile | `nav_profile` | الملف الشخصي |
| Settings | `nav_settings` | الإعدادات |
| Sign in | `auth_sign_in (⚠ also: common_sign_in)` | تسجيل الدخول |
| Create account | `auth_create_account` | إنشاء الحساب |
| Sign in to continue your adventure | `auth_login_subtitle_plain` | سجّل الدخول لمتابعة مغامرتك |
| Forgot password? | `auth_forgot` | نسيت كلمة المرور؟ |
| Email | `auth_email (⚠ also: profile_email, set_email_row)` | البريد الإلكتروني |
| Password | `auth_password` | كلمة المرور |
| Confirm password | `auth_confirm_password` | كرر كلمة المرور |
| Username | `auth_username (⚠ also: set_username_row)` | اسم المستخدم |
| AC wallet | `ac_title` | محفظة AC |
| Current balance | `ac_balance` | الرصيد الحالي |
| Daily reward | `ac_kind_daily` | مكافأة يومية |
| Claim | `ac_claim` | استلام |
| Claimed | `ac_claimed` | تم الاستلام |
| Streak reward | `ac_kind_streak` | مكافأة سلسلة |
| day streak | `ac_freq_streak` | سلسلة أيام |
| Redeem code | `ac_redeem_action` | استبدال الكود |
| How to earn AC | `ac_tasks` | كيف تكسب AC |
| Transaction history | `ac_history` | سجل العمليات |
| Gift code | `ac_kind_code` | كود هدية |
| Latest AC operations | `admin_give_ac_history` | آخر عمليات AC |
| No AC operations yet | `admin_give_ac_none` | لا توجد عمليات AC بعد |
| Not enough AC | `ac_not_enough` | رصيد AC غير كافٍ |
| AC task | `ac_kind_task` | مهمة AC |
| Content unlock | `ac_kind_unlock` | فتح محتوى |
| Event reward | `ac_kind_event` | مكافأة حدث |
| Admin reward | `admin_reward (⚠ also: admin_reason_reward)` | مكافأة إدارية |
| Message %1$s | `chat_hint` | اكتب في %1$s |
| Friend request | `notif_friend_request` | طلب صداقة |
| Request sent | `profile_friend_sent` | تم إرسال الطلب |
| Mute this user | `chat_mute_user` | كتم هذا المستخدم |
| Block user | `block_user` | حظر المستخدم |
| Report | `chat_report` | إبلاغ |
| Edit profile | `profile_edit_plain` | تعديل الملف |
| My favorites | `home_qa_favorites` | مفضلتي |
| My downloads | `home_qa_downloads` | تحميلاتي |
| My orders | `plan_my_orders` | طلباتي |
| My content | `profile_tab_content (⚠ also: profile_stats_content)` | محتواي |
| About me | `profile_about_me` | عني |
| Member since %1$s | `profile_member_since` | عضو منذ %1$s |
| Log out | `set_log_out (⚠ also: common_log_out)` | تسجيل الخروج |
| Delete account | `set_delete_account` | حذف الحساب |
| App language | `set_language` | لغة التطبيق |
| App theme | `set_theme` | مظهر التطبيق |
| Dark | `set_theme_dark` | داكن |
| Light | `set_theme_light` | فاتح |
| Online status | `profile_online_status` | حالة الظهور |
| Notification settings | `notif_settings` | إعدادات الإشعارات |
| Help center | `set_help` | مركز المساعدة |
| Contact us | `set_contact` | تواصل معنا |
| Report a problem | `set_report_problem` | الإبلاغ عن مشكلة |
| About the app | `set_about` | حول التطبيق |
| Privacy policy | `set_privacy` | سياسة الخصوصية |
| Terms of use | `set_terms` | شروط وأحكام الاستخدام |
| App version | `set_version` | إصدار التطبيق |
| Allow notifications | `notif_allow` | السماح بالإشعارات |
| Send me a test notification | `notif_test` | أرسل لي إشعاراً تجريبياً |
| Quiet hours | `notif_quiet (⚠ also: notif_quiet_section)` | ساعات الهدوء |
| From | `notif_quiet_from` | من |
| To | `notif_quiet_to` | إلى |
| Chat messages | `notif_ch_chat (⚠ also: notif_cat_chat)` | رسائل الشات |
| Friends & social | `notif_cat_social` | الأصدقاء والتفاعل |
| Subscriptions | `plan_title` | الاشتراكات |
| New content | `notif_ch_content` | محتوى جديد |
| Reminders | `notif_ch_reminders` | تذكيرات |
| Come-back reminder | `notif_reengage_section` | تذكير العودة |
| Premium member | `home_plan_active_forever` | عضو مميز |
| Add photo | `chat_add_photo` | إضافة صورة |
| Stickers | `chat_stickers (⚠ also: chat_stickers_tab)` | الملصقات |
| Send | `chat_send` | إرسال |
| Pinned messages | `chat_pinned_plain` | الرسائل المثبتة |
| %1$s is typing… | `chat_typing` | %1$s يكتب… |
| Hidden from other users | `set_email_note` | مخفي عن المستخدمين الآخرين |
| Account | `set_account (⚠ also: notif_ch_account, set_account_area)` | الحساب |
| Preferences | `set_prefs` | التفضيلات |
| Notifications | `notif_title (⚠ also: set_notifications)` | التنبيهات |
| Support | `set_support (⚠ also: comm_room_support)` | الدعم |
| Master switch | `notif_master_section` | المفتاح الرئيسي |
| Level %1$s · %2$d/100 to next level | `profile_xp_progress` | المستوى %1$s · %2$d من 100 للمستوى التالي |
| Your new account gets a free default avatar automatically | `auth_signup_subtitle` | حسابك الجديد يحصل تلقائياً على أفاتار مجاني |
| By creating an account you agree to the community rules and the terms set by AddonStation. | `auth_terms_note` | من خلال إنشاء حساب، توافق على قواعد المجتمع والشروط التي تحددها AddonStation. |
| Already have an account? | `auth_have_account` | لديك حساب؟ |
| Don't have an account? | `auth_no_account` | ليس لديك حساب؟ |
| Cancel | `common_cancel` | إلغاء |
| Delete | `common_delete` | حذف |
| Retry | `common_retry` | إعادة المحاولة |
| Back | `common_back` | رجوع |
| Edit | `common_edit` | تعديل |
| Accept | `notif_accept` | قبول |
| Reject | `admin_reject` | رفض |
| Unblock | `block_user_undo` | إلغاء الحظر |
| Pin | `chat_pin` | تثبيت |
| Unpin | `chat_unpin` | إلغاء التثبيت |
| Copy text | `chat_copy_text` | نسخ النص |
| Reply | `chat_reply (⚠ also: notif_reply)` | رد |
| Add reaction | `chat_add_reaction` | إضافة تفاعل |
| Download | `item_download_plain` | تحميل |
| Open Dashboard | `home_creator_open` | افتح اللوحة |
| Admin dashboard | `admin_title (⚠ also: admin_kicker_dashboard)` | لوحة الإدارة |

## New keys (not in the app yet) — see `values/strings_v2.xml`
- `ac_unlock_with_ac` — Unlock with AC / افتح بالـ AC
- `admin_chat_plain` — Chat / الدردشة
- `cd_download_item` — Download %1$s / تنزيل %1$s
- `cd_hide_password` — Hide password / إخفاء كلمة المرور
- `cd_more_options` — More options / خيارات إضافية
- `cd_new_activity` — New activity / نشاط جديد
- `cd_open_wallet` — Open AC wallet / افتح محفظة AC
- `cd_show_password` — Show password / إظهار كلمة المرور
- `chat_pinned_plain` — Pinned messages / الرسائل المثبتة
- `home_latest_plain` — Latest addons / أحدث الإضافات
- `item_download_plain` — Download / تحميل
- `nav_chat` — Chat / الشات
- `profile_edit_plain` — Edit profile / تعديل الملف
- `ac_streak_days` (plurals) — "%d day streak" / Arabic with all 6 plural forms
- `cd_chat_unread` (plurals) — unread-messages content description for the Chat tab badge
