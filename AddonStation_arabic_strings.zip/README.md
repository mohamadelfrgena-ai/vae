# AddonStation — Arabic for the whole app

## ملاحظة للمستخدم (بالعربي)
التطبيق **عنده ترجمة عربية كاملة أصلاً**: من 616 نصاً في التطبيق، 608 مترجمين للعربية، والباقي (8 نصوص) أسماء ثابتة مثل اسم التطبيق وأدوار الأعضاء (Admin وCreator...) ما تتغير. هذا الملف يحتوي على:
1. **ملف العربية الحالي** (`values-ar/strings.xml`) مستخرج من تطبيقك، مع النسخة الإنجليزية (`values/strings.xml`) للمقارنة.
2. **نصوص جديدة** (`strings_v2.xml` بالإنجليزي والعربي) تحتاجها التصاميم الجديدة: تبويب Chat، وأوصاف الوصول (للقارئات الصوتية)، وعبارة "سلسلة أيام" بصيغ الجمع العربية الست، ونسخ بدون إيموجي للنصوص اللي استبدلنا إيموجيها بأيقونات.
3. **جدول ربط** (`STRING_MAP.md`): كل نص في التصاميم والمفتاح الموجود له في التطبيق، عشان الـ agent يستخدم المفاتيح الموجودة ولا يكرر النصوص.

مهم: المشروع الأصلي عندك في Android Studio هو المرجع. هذي الملفات مستخرجة من ملف APK، فلا تستبدل بها ملفاتك، **ادمج** النصوص الجديدة بس (`strings_v2.xml`). الملفات المستخرجة ما تحتفظ بالتنسيق داخل النص (مثل الخط العريض أو اللون إن وجد).

---

## Instructions for the agent
**Source of truth:** the project's own `res/values*/strings.xml`. The files here were extracted from the built APK for reference and review — do **not** overwrite project files with them. Do:
1. Copy `res/values/strings_v2.xml` and `res/values-ar/strings_v2.xml` into the project as new files (merge by key if a key already exists).
2. Use the existing keys listed in `STRING_MAP.md` for every text in the new screens. Do not create duplicates.
3. Where the app's existing string starts or ends with an emoji (e.g. `✏️ Edit profile`) the new designs use a vector icon instead — use the matching `*_plain` key from `strings_v2.xml`.
4. Add `nav_chat` to the bottom bar and use the plurals `ac_streak_days` / `cd_chat_unread` with `pluralStringResource` (Arabic needs all six forms: zero, one, two, few, many, other — already provided).

## Arabic / RTL implementation checklist
- Manifest: `android:supportsRtl="true"`. Use `start/end` (never left/right) in padding, alignment and arrangement.
- Apply the app-language setting as a locale **and** layout direction together (`AppCompatDelegate.setApplicationLocales`), so Compose gets `LayoutDirection.Rtl`.
- Mirror directional icons with the `AutoMirrored` Material icons (back, chevron, send). Do not mirror: bell, search, download, star, home, person, settings, coin, flame, gift.
- **Fonts:** the pixel font has no Arabic glyphs. Use Tajawal (Medium / Bold / ExtraBold) for every Arabic text, including headings and the hero slogan. Keep the pixel font only for the Latin brand name ("ADDONSTATION") and the English slogan. Do not set letter spacing or uppercase on Arabic text.
- Bottom bar logical order is Settings · Chat · Home · Store · Profile; it mirrors automatically in Arabic.
- Numbers stay Western digits (0–9), as the app does now. Keep mixed strings like "120 AC" stable; wrap Latin/number runs with Unicode isolates (`\u2068…\u2069`) if the order looks wrong.
- Allow ~30% longer text: buttons wrap/grow, no clipped labels. Test font scale 130%.
- Test matrix: dark/light × English/Arabic, on a small (360dp) screen.

## Files
```
res/values/strings.xml          English, 616 app strings (reference)
res/values-ar/strings.xml       Arabic, 608 translatable app strings (reference — the app already has these)
res/values/strings_v2.xml       NEW keys, English
res/values-ar/strings_v2.xml    NEW keys, Arabic (incl. 6-form plurals)
STRING_MAP.md                   design text → existing key → Arabic
```
Library strings (Material, ExoPlayer, Firebase, Google Play services) are not included; they come from their own libraries and are already localized.
