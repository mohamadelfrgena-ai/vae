# AddonStation — UI Spec: Admin panel (gate, dashboard, bottom bar and 12 screens)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified. Tokens, fonts, shapes, chips, sheets and dialogs are the same as in `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0 and `SPEC_CHAT_DETAILS_STATES.md` — read those first. `reference/core_screens_preview.html` is a clickable reference of every admin screen and state (switch **Admin bar: 5 / 6** to compare both bottom-bar options).
The panel exists today as the "Admin dashboard" (only for the admin account; moderators get the chat tools for their rooms). **Do not change any admin logic or backend call**: only layout, navigation and colors. All texts exist in `strings.xml` (table in section 12); use the `*_plain` keys where the app's string starts with an emoji or symbol.

## 1. Gate (password lock)
Shown before the panel and again after **15 minutes** (`admin_gate_locked_note`) or when the user taps the lock button (`admin_lock_now`). **No bottom bar.** Top bar title `admin_kicker_dashboard`.
- Lock circle 96 (gold@14% bg, 1dp gold@45%, shield-lock icon 48 goldText) centered · title `admin_gate_title` 20sp/800 · hint `admin_gate_hint` 13sp muted, line height 1.6.
- Field `admin_gate_password` (48 high, radius 12, show/hide eye) · primary button `admin_gate_unlock` (56 high, radius 16) · note with a clock icon 14 + `admin_gate_locked_note` 12sp muted.
- **States:** checking (`admin_gate_checking`, button disabled with progress) · wrong password (error line `admin_gate_wrong`) · too many attempts (warning message `admin_gate_too_many` + `admin_gate_cooldown` with a live countdown, button disabled) · not an admin (error message `admin_gate_denied_body`, only a Cancel/back button).

## 2. Admin navigation — bottom bar
All admin screens except the gate use a **floating bottom bar** with the same visual language as the main app bar (see `SPEC_WALLET_BOTTOMBAR.md` 4.2–4.3, without the raised center button): container margin 10/12/12, height **72**, radius 26, barSurface, 1dp border, shadow 0 10dp 30dp black@45% (light: `#0E1526`@18%).
- **Tab:** column, height 64, gap 3: indicator pill (44×32, radius 16; 40×32 in the 6-tab version) + label (11sp/700; 10sp in the 6-tab version). Active: pill gradient blue → light blue + soft shadow, filled/white icon, label blueLink/800. Inactive: icon and label textMuted.
- **Badges:** red circle (min 18, white 10sp/800, 2dp border in barSurface) on **Payments** (orders waiting for review) and **Chat** (open reports); counts come from the existing admin stats; hide at 0.
- **Option A — 5 tabs (recommended):** Overview · Users · Payments · Content · Chat. **More** (⋯) moves to the top bar next to the lock button and opens the More screen (section 11); screens reached from More show no active tab.
- **Option B — 6 tabs:** Overview · Users · Payments · Content · Chat · More (matches the six sections the app has today). Labels are tight in Arabic.
Pick one for the whole panel. Icons (Material): Dashboard/GridView, Group, CreditCard, ViewInAr, ChatBubble, MoreHoriz. Screen → active tab: Overview (+ AC tools, gift codes) · Users (+ give AC) · Payments (+ confirm dialog) · Content · Chat · More (+ plans & payment, creators, assets, audit log).
Behavior: tapping the active tab scrolls to top; switching tabs keeps each tab's state; when the panel auto-locks, return to the gate.
**Admin header** (top bar of every admin screen): back · column [kicker 11sp/800 goldText, letter spacing 1sp (`admin_kicker_*` of the section) + title `admin_title` in the pixel font 12sp] · (Option A) More button · **lock button** (44 circle).

## 3. Overview
Scroll, padding 16. **Stat grid** (2 columns, gap 10): cards (surface, 1dp border, radius 16, padding 12, min height 84): number 24sp/800 + label 12sp/700 muted. Cards: Users (`admin_users`), Payments (`admin_payments`), Chat reports (`admin_chat_reports_plain`), Creator requests (`admin_creator_requests_plain`), Addons (`admin_addons`), Worlds (`admin_worlds`). Cards that need action (payments, reports, requests with count > 0) get a warning-colored border and number. Tapping a card opens its screen.
Section `admin_tools`: **tool cards** (icon tile 44, title 15sp/800, subtitle 12sp muted, chevron): **AC management and grants** (`admin_ac_tools`, coin, gold → Users/Give AC) and **AC gift codes** (`admin_codes_title`, gift, purple → Gift codes). Then `admin_give_ac_history` ("Latest AC operations") rows as in the AC history (section 6 of the profile spec).

## 4. Users and AC grants
- Search field `admin_search_users`; label `admin_filter_role` + horizontal role chips (All, `grp_admin`, `grp_moderators`, `grp_creators`, Legendary, Epic; 40 high).
- **User row** (min 64): avatar 44 · column [name 15sp/800; "email · [N] AC" 12sp muted] · role chip · **Give** button (`admin_give_plain`, 36 high, radius 10, primary).
- **Give AC sheet** (bottom sheet, top at 92dp): title `admin_give_ac_title`; selected-user card (avatar 44, name, "balance [N] AC"); field `admin_give_ac_amount`; label `admin_give_ac_quick` + chips +10 · +50 · +100 · +500 (44 high, selected = 2dp gold border); field `admin_give_ac_note` ("Reason (the user sees it)"); switch row `admin_give_ac_all`; buttons: **Deduct** (`admin_give_ac_deduct`, error fill) and **Give** (`admin_give_ac_give`, ok fill), 48 high. Confirmation dialogs `admin_give_ac_confirm`, `admin_give_ac_confirm_deduct`, `admin_give_ac_confirm_all`; results `admin_give_ac_done`, `…_deduct`, `…_done_all`; errors `admin_give_ac_invalid`, `admin_give_ac_no_users`.

## 5. AC gift codes
Top bar `admin_codes_title`. Hint `admin_codes_hint`; fields `admin_codes_amount` (min 100 AC, error `admin_codes_bad_amount`) and `admin_codes_count`; summary message (info style) `admin_codes_summary` ("5 codes × 500 AC = 2500 AC total"); button `admin_codes_generate` (56 high). After generating: section `admin_codes_created` and one row per code (8 characters, monospace 800, letter spacing 2, left-to-right) with a **Copy** button (`plan_copy`); section `admin_codes_latest`: rows with code + status chip (value in ok `+500 AC`, `admin_code_used` warning, `admin_code_expired` error).

## 6. Payments
Header kicker `admin_kicker_payments`. Status filter chips: `plan_status_pending`, `plan_status_submitted`, `plan_status_approved`, `plan_status_rejected` (default: Under review). **Order card** (surface, 1dp border, radius 16, padding 14): header — avatar 44 + [name 15sp/800; `plan_order_number` [N] · date 12sp muted] + status chip; row — plan chip + price line `[N] LYD · $[N]` (800) + receipt thumbnail 56×72 (tap = full image); buttons row (gap 8, 44 high): **View receipt** (`admin_view_receipt`, outlined) · **Approve** (`admin_approve`, ok fill) · **Reject** (`admin_reject`, error outline). **Confirm dialog** (`admin_confirm_payment`): body "[name] · [plan] · [N] LYD · +30 days" (`admin_plan_days`), buttons Cancel / Approve.

## 7. Plans and payment settings (More)
Top bar `admin_plans_settings`. One card per plan (Epic, Legendary; icon tile 40 + name 16sp/800): 2-column fields `admin_price_lyd_label`, `admin_price_usd_label`, `admin_duration_days_label`, `admin_download_limit_label`; button Save (44 high). Section `plan_payment_method`: list of payment methods (card icon tile, name, `admin_method_code_label`, delete icon button) and an "add method" card with fields `admin_method_name_label`, `admin_method_code_label` + Save.

## 8. Content
Header kicker `admin_kicker_content`. **List:** segmented chips `admin_addons` / `admin_worlds` + button `admin_add_content_plain` (44 high, primary); section `admin_published_content`; rows (min 64): thumbnail 56 radius 10 · column [title 15sp/800; "[N] downloads · [N] AC" 12sp muted] · tier badge (FREE / EPIC purple / LEGENDARY gold) · edit icon button (36).
**Add/edit form:** title `admin_content`; fields: Title (`creator_field_title`), type chips (Addons/Worlds), Description (`admin_content_description`), required plan chips (Free/Epic/Legendary, `admin_required_plan`), AC price (`admin_ac_price_label`) and download limit (`admin_download_limit_label`) side by side, Cover and File dashed upload zones (`admin_cover_label`, `admin_file_label`); buttons Delete (`admin_delete_content_label`, outlined, confirm first) and Save (`admin_save`).

## 9. Chat moderation
Header kicker `admin_kicker_chat`. Segmented control: **Reports** (`admin_chat_reports_plain`) · **Rooms** (`admin_rooms_all`) · **Moderators** (`admin_rooms_manage`).
- **Reports:** card per report — flag icon tile 40 (error), title "Report: [reason]" (`chat_report` + `chat_reason_*`), line "[reporter] → [reported] · [room] · [time]", message preview box, buttons: Hide message (`chat_hide_message`), Mute this user (`chat_mute_user`), Ban user (`admin_ban_user`, error outline), and a full-width **Close report** (`admin_close_report`). Empty: `admin_open_reports_none_plain`.
- **Rooms:** card with one row per room (chat icon tile, name, `admin_room_category` value, edit and delete buttons); card "Add room" with fields `admin_room_name`, `admin_room_category` + button `admin_add_room`; card **Announcement** (megaphone tile, `chat_announcement`, multiline field, button `admin_send_announcement`).
- **Moderators:** text `admin_rooms_choose`, a card of rows with a checkbox + room name, hint `admin_rooms_hint`, Save; success `admin_rooms_saved_plain`. Moderators see only their rooms; admins see all.

## 10. Creators (More)
Top header with the segmented control **Requests** (`admin_tab_requests`) · **Content** (`admin_tab_submissions`) · **Tips** (`admin_tips_title`).
- **Request card:** avatar + name; country and experience (`creator_field_country`, `creator_field_experience`); content types; motivation preview (`creator_field_motivation`); buttons Approve / Reject.
- **Content submissions:** rows as in Content with Approve / Reject.
- **Tip card:** "[from] → [creator]", amount, date, receipt thumbnail, buttons View receipt / Approve / Reject (`creator_review_tip` flow).

## 11. Avatars & stickers · Audit log · More
- **Assets** (kicker `admin_kicker_assets`): segmented (Avatars `admin_tab_avatars`, Stickers `chat_stickers_tab`, Banners `profile_banner_section`); field `admin_pack_id_label`; dashed **Upload** button (`admin_upload`); grid 4 columns of assets (square, radius 14); card with `admin_shrink_assets` + hint `admin_shrink_assets_hint` + button (one-time action, confirm first).
- **Audit log** (`admin_audit_log`): one card of rows — icon tile 40 (by operation: AC adjustment, codes, payment confirmation, report closed, content change, reward), operation title 15sp/800, "[actor] · [date]" 12sp muted.
- **More** (`admin_more`): list card with rows (tile 44, title, subtitle, chevron): Creator requests, Creator tips, Plans & payment (`admin_plans_and_payment_plain`), Avatars & stickers (`admin_assets_plain`), Audit log; then an outlined **Lock panel now** button (`admin_lock_now`, lock icon).

## 12. Light theme, Arabic (RTL), permissions, accessibility
- Light/dark tokens as in the item spec; success = ok, danger = error, "needs attention" = warning. Monospace codes stay LTR in Arabic.
- RTL: start/end everywhere; the bottom bar order mirrors automatically; chevrons AutoMirrored; Arabic uses Tajawal; allow longer text (rows grow).
- Permissions: admins see everything; moderators only Chat moderation for their rooms (`admin_no_permission`, `admin_not_allowed`); hide tabs the user cannot use.
- Destructive/financial actions (approve/reject payment, give/deduct AC, give to everyone, delete content, shrink assets, ban) always ask for confirmation and are logged in the audit log.
- Accessibility: targets ≥ 44dp (small mini-buttons must have a 44dp hit area), badges have content descriptions ("3 payments waiting"), lock countdown announced politely.

## 13. String keys used (admin + profile + wallet)
| Key | English | Arabic |
|---|---|---|
| `profile_level_reputation` | Level & reputation | المستوى والسمعة |
| `profile_statistics` | Statistics | الإحصائيات |
| `profile_tab_about` | About | نبذة |
| `profile_tab_content` | My content | محتواي |
| `profile_tab_favorites` | Favorites | مفضلتي |
| `profile_tab_plan` | My plan | خطتي |
| `profile_about_me` | About me | عني |
| `profile_about_default` | This member has not added a bio yet. | هذا العضو لم يضف نبذة بعد. |
| `profile_account_info_plain` | Account info | معلومات الحساب |
| `profile_email` | Email | البريد الإلكتروني |
| `profile_online_status` | Online status | حالة الظهور |
| `profile_roles` | Roles | الرتب |
| `grp_epic_plain` | Epic | ملحمي |
| `role_creator_plain` | Creator | Creator |
| `profile_content_section` | Content | المحتوى |
| `profile_no_content_published` | No content published yet | لا محتوى منشور بعد |
| `profile_favorites_empty_plain` | No favorites yet — tap on any content to save it here | لا توجد مفضلة بعد — اضغط على أي محتوى لحفظه هنا |
| `profile_current_plan` | Your current plan | خطتك الحالية |
| `plan_epic_name` | Epic | ملحمي |
| `plan_status_approved` | Active | مفعّل |
| `plan_epic_features_plain` | Epic addons · More downloads · Subscriber access | إضافات Epic · تنزيلات أكثر · وصول المشتركين |
| `profile_manage` | Manage | إدارة |
| `profile_upgrade_plain` | Upgrade | ترقية |
| `profile_custom_status` | Custom status | حالة مخصصة |
| `profile_edit_mine_plain` | Edit my profile | تعديل الملف الشخصي |
| `profile_dashboard_plain` | Dashboard | لوحة |
| `profile_full_settings` | Full settings | الإعدادات الكاملة |
| `grp_legendary_plain` | Legendary | أسطوري |
| `profile_add_friend_plain` | Add friend | إضافة صديق |
| `profile_friend_sent` | Request sent | تم إرسال الطلب |
| `profile_friends_plain` | Friends | أصدقاء |
| `profile_message_plain` | Message | رسالة |
| `profile_stat_published` | Published | المنشور |
| `profile_stats_downloads` | Downloads | تحميلاتي |
| `profile_stats_level` | Level | المستوى |
| `comm_room_general` | General | عام |
| `profile_online` | Online | عبر الإنترنت |
| `profile_open_profile` | Open profile ↗ | فتح الملف ↗ |
| `ac_title` | AC wallet | محفظة AC |
| `ac_balance` | Current balance | الرصيد الحالي |
| `ac_claim` | Claim | استلام |
| `ac_claimed` | Claimed | تم الاستلام |
| `ac_redeem_title` | AC gift code | كود هدية AC |
| `ac_redeem_hint` | 8 characters: uppercase, lowercase and two digits | الكود من 8 خانات: حروف كبيرة وصغيرة ورقمان |
| `ac_redeem_used` | You have already redeemed this code. | لقد استبدلت هذا الكود من قبل. |
| `ac_redeem_action` | Redeem code | استبدال الكود |
| `ac_tasks` | How to earn AC | كيف تكسب AC |
| `ac_freq_daily` | daily | يومياً |
| `ac_freq_once` | one time | مرة واحدة |
| `ac_freq_streak` | day streak | سلسلة أيام |
| `ac_history` | Transaction history | سجل العمليات |
| `ac_desc` | AC is an internal reward currency. Earn it through activity and use it to unlock eligible addons and worlds. T | AC هي عملة مكافآت داخلية. اكسبها من النشاط اليومي، واستخدمها لفتح الإضافات والعو |
| `ac_freq_manual` | manual | من الإدارة |
| `ac_no_transactions` | No AC transactions yet. | لا توجد عمليات على AC حتى الآن. |
| `admin_title` | ADMIN DASHBOARD | لوحة الإدارة |
| `admin_overview` | Overview | الرئيسية |
| `admin_users` | Users | المستخدمون |
| `admin_payments` | Payments | المدفوعات |
| `admin_content` | Content | المحتوى |
| `admin_chat_plain` | Chat | الدردشة |
| `admin_more` | More | المزيد |
| `admin_kicker_dashboard` | Admin dashboard | لوحة الإدارة |
| `admin_gate_title` | Admin panel is protected | لوحة الإدارة محمية |
| `admin_gate_hint` | This panel is for the admin only. Enter your account password to continue. | هذه اللوحة للأدمن فقط. أدخل كلمة مرور حسابك للمتابعة. |
| `admin_gate_password` | Account password | كلمة مرور الحساب |
| `admin_gate_wrong` | Wrong password. Try again. | كلمة المرور غير صحيحة. حاول مرة أخرى. |
| `admin_gate_unlock` | Unlock panel | فتح اللوحة |
| `admin_gate_locked_note` | The panel locks automatically after 15 minutes and asks for the password again. | تُقفل اللوحة تلقائياً بعد ١٥ دقيقة وتطلب كلمة المرور من جديد. |
| `admin_gate_too_many` | Too many wrong attempts — try again in a couple of minutes. | محاولات خاطئة كثيرة — أعد المحاولة بعد دقيقتين. |
| `admin_gate_denied_body` | This panel is for the admin account only. Your account is not an admin. | هذه اللوحة لحساب الأدمن فقط — حسابك ليس Admin. |
| `common_cancel` | Cancel | إلغاء |
| `admin_chat_reports_plain` | Chat reports | بلاغات الشات |
| `admin_creator_requests_plain` | Creator requests | طلبات المبدعين |
| `admin_addons` | Addons | الإضافات |
| `admin_worlds` | Worlds | العوالم |
| `admin_tools` | Admin tools | أدوات الإدارة |
| `admin_ac_tools` | AC management and grants | إدارة AC ومنح الأرصدة |
| `admin_give_ac_title` | Give AC to a user | منح AC لمستخدم |
| `admin_codes_title` | AC gift codes | أكواد هدايا AC |
| `admin_codes_hint` | Copy the codes and send them to whoever you want. Each code works once per member. | انسخ الأكواد وأرسلها لمن تريد. كل كود يُستخدم مرة واحدة لكل مستخدم. |
| `admin_give_ac_history` | Latest AC operations | آخر عمليات AC |
| `admin_give_plain` | Give | منح |
| `admin_search_users` | Search by name or email | ابحث بالاسم أو البريد |
| `admin_filter_role` | Filter by role | تصفية حسب الرتبة |
| `grp_admin` | Admin | الإدارة |
| `grp_moderators` | Moderators | المشرفون |
| `grp_creators` | Creators | المبدعون |
| `admin_give_ac_balance_after` | balance | الرصيد |
| `admin_give_ac_amount` | Amount (any number) | المبلغ (أي رقم) |
| `admin_give_ac_quick` | Quick amounts | مبالغ سريعة |
| `admin_give_ac_note` | Reason (the user sees it) | السبب (يظهر للمستخدم) |
| `admin_give_ac_all` | Give to every user | منح لكل المستخدمين |
| `admin_give_ac_deduct` | Deduct | خصم |
| `admin_give_ac_give` | Give | منح |
| `admin_codes_amount` | Code value (AC) | قيمة الكود (AC) |
| `admin_codes_count` | Number of codes | عدد الأكواد |
| `admin_codes_generate` | Generate codes | توليد الأكواد |
| `plan_copy` | Copy | نسخ |
| `admin_codes_latest` | Latest codes | أحدث الأكواد |
| `plan_order_number` | Order number | رقم الطلب |
| `admin_view_receipt` | View receipt | عرض الإيصال |
| `admin_approve` | Approve | موافقة |
| `admin_reject` | Reject | رفض |
| `admin_kicker_payments` | Payments | المدفوعات |
| `plan_status_pending` | Pending | قيد الانتظار |
| `plan_status_submitted` | Under review | قيد المراجعة |
| `plan_status_rejected` | Rejected | مرفوض |
| `plan_legendary_name` | Legendary | أسطوري |
| `admin_confirm_payment` | Confirm payment | تأكيد الدفع |
| `admin_plan_days_plain` | 30 days | 30 يوم |
| `admin_price_lyd_label` | Price in LYD | السعر بالدينار |
| `admin_price_usd_label` | Price in USD | السعر بالدولار |
| `admin_duration_days_label` | Duration (days) | المدة (أيام) |
| `admin_download_limit_label` | Download limit (empty = unlimited) | حد التنزيل (فارغ = بلا حد) |
| `admin_save` | Save | حفظ |
| `admin_plans_settings` | Plans and payment data | الخطط وبيانات الدفع |
| `plan_payment_method` | Payment method | طريقة الدفع |
| `admin_method_code_label` | Code | الرمز |
| `admin_method_name_label` | Name | الاسم |
| `admin_kicker_content` | Content administration | إدارة المحتوى |
| `admin_add_content_plain` | Add content | إضافة محتوى |
| `admin_published_content` | Published content | المحتوى المنشور |
| `creator_field_title` | Title | العنوان |
| `creator_field_content_types` | Content types (addons, worlds…) | أنواع المحتوى (إضافات، عوالم…) |
| `plan_free_name` | Free | مجاني |
| `chat_report` | Report | إبلاغ |
| `chat_reason_insult` | Insult | إهانة |
| `chat_hide_message` | Hide message | إخفاء الرسالة |
| `chat_mute_user` | Mute this user | كتم هذا المستخدم |
| `admin_room_category` | Category | القسم |
| `admin_kicker_chat` | Chat moderation | إدارة الشات |
| `admin_rooms_all` | All rooms | كل الغرف |
| `admin_rooms_manage` | Room moderation | إشراف الغرف |
| `admin_open_reports_none_plain` | No open reports | لا توجد بلاغات مفتوحة |
| `admin_room_name` | Room name | اسم الغرفة |
| `admin_add_room` | Add room | إضافة غرفة |
| `chat_announcement` | Announcement | إعلان |
| `admin_rooms_choose` | Pick the rooms this moderator can moderate | اختر الغرف التي يشرف عليها هذا المشرف |
| `admin_rooms_hint` | Admins moderate all rooms automatically. | الأدمن يشرف على كل الغرف تلقائياً. |
| `creator_field_country` | Country | الدولة |
| `creator_field_experience` | Experience | الخبرة |
| `creator_field_motivation` | Why AddonStation? | لماذا AddonStation؟ |
| `home_creator_dashboard` | Creator Dashboard | لوحة المبدع |
| `admin_tips_title` | Creator tips | نصائح صنّاع المحتوى |
| `admin_kicker_assets` | Asset management | إدارة الأصول |
| `chat_stickers_tab` | Stickers | ملصقات |
| `profile_banner_section` | Banners | الأغلفة |
| `admin_pack_id_label` | Pack id (meme / Minecraft_Memes1 …) | معرّف الحزمة (meme / Minecraft_Memes1 …) |
| `chat_stickers` | Stickers | الملصقات |
| `admin_shrink_assets` | Shrink all asset images | تصغير كل صور الأصول |
| `admin_shrink_assets_hint` | Makes the picture grid light and instant. One time only. | يجعل شبكة الصور خفيفة وتظهر فوراً. مرة واحدة فقط. |
| `admin_audit_log` | Audit log | سجل العمليات |
| `admin_adjustment` | Admin Adjustment | تعديل إداري |
| `admin_reward` | Admin Reward | مكافأة إدارية |
| `home_creator_text` | Share your addons and worlds with the AddonStation community and open the door to creator earnings. | شارك إضافاتك وعوالمك مع مجتمع AddonStation وافتح طريقاً لتحقيق أرباح المبدعين. |
| `creator_tip_title` | Support this creator | دعم منشئ المحتوى |
| `admin_plans_and_payment_plain` | Plans & payment | الخطط والدفع |
| `admin_assets_plain` | Avatar & sticker management | إدارة الأفاتارات والملصقات |
| `admin_lock_now` | Lock panel now | قفل اللوحة الآن |
| `item_by` | By %1$s | بواسطة %1$s |
| `profile_level_active` | Level %1$s · Active member | المستوى %1$s · عضو نشط |
| `profile_lv_badge` | LV %1$d | مستوى %1$d |
| `profile_xp_progress` | Level %1$s · %2$d/100 to next level | المستوى %1$s · %2$d من 100 للمستوى التالي |
| `profile_member_since` | Member since %1$s | عضو منذ %1$s |
| `home_plan_expires` | Expires on %1$s | تنتهي في %1$s |
| `admin_give_ac_done_plain` | %1$d AC · balance %2$d | %1$d AC · الرصيد %2$d |
| `ac_redeem_detected` | Code tier: %1$s AC | فئة الكود: %1$s AC |
| `ac_redeem_success` | Added %1$s AC to your balance. | تمت إضافة %1$s AC إلى رصيدك. |
| `admin_gate_cooldown` | Locked for %1$d seconds. | موقوف مؤقتاً %1$d ثانية. |
| `admin_codes_summary` | %1$s codes × %2$s AC = %3$s AC total | %1$s كود × %2$s AC = %3$s AC إجمالاً |
| `admin_codes_created` | Generated %1$s codes — copy them now: | تم توليد %1$s كوداً — انسخها الآن: |
| `admin_gate_checking` | Checking permission… | جارٍ التحقق من الصلاحية… |
| `admin_no_permission` | You do not have permission for this action | لا تملك صلاحية هذا الإجراء |
| `admin_not_allowed` | Not allowed — your account is not an Admin yet. | غير مسموح — حسابك ليس Admin بعد. |
| `admin_rooms_saved_plain` | Room moderation updated | تم تحديث إشراف الغرف |
| `admin_codes_bad_amount` | Enter at least 100 AC. | أدخل قيمة 100 AC على الأقل. |
| `admin_give_ac_confirm` | Give %1$d AC to %2$s? | منح %1$d AC للمستخدم %2$s؟ |
| `admin_give_ac_confirm_all` | Give %1$d AC to every user? | منح %1$d AC لكل المستخدمين؟ |
| `admin_give_ac_confirm_deduct` | Deduct %1$d AC from %2$s? | خصم %1$d AC من %2$s؟ |
| `admin_give_ac_done_all` | %1$d AC given to %2$d users | تم منح %1$d AC لـ %2$d مستخدم |
| `admin_give_ac_done_deduct_plain` | %1$d AC · balance %2$d | %1$d AC · الرصيد %2$d |
| `admin_give_ac_invalid` | Type a valid amount | اكتب مبلغاً صحيحاً |
| `admin_give_ac_no_users` | No matching user | لا يوجد مستخدم مطابق |
| `admin_give_ac_none` | No AC operations yet | لا توجد عمليات AC بعد |
| `ac_redeem_invalid` | This code is not valid. Check the letters and digits. | الكود غير صحيح. تحقّق من الحروف والأرقام. |
| `ac_redeem_off` | This code is currently disabled. | هذا الكود غير مُفعَّل حالياً. |
| `ac_redeem_expired` | This code has expired. | انتهت صلاحية هذا الكود. |
| `ac_redeem_exhausted` | This code reached its usage limit. | انتهى عدد مرات استخدام هذا الكود. |
| `ac_redeem_sign_in` | Sign in first to redeem a code. | سجّل الدخول أولاً لاستبدال الكود. |
| `ac_not_enough` | Not enough AC | رصيد AC غير كافٍ |
| `ac_unlocked` | Unlocked | تم فتحه |
| `admin_delete_content_label` (NEW) | Delete content | حذف المحتوى |
| `admin_content_description` (NEW) | Description | الوصف |
| `admin_required_plan` (NEW) | Required plan | الخطة المطلوبة |
| `admin_ac_price_label` (NEW) | AC price | سعر AC |
| `admin_cover_label` (NEW) | Cover | الغلاف |
| `admin_file_label` (NEW) | File | الملف |
| `admin_ban_user` (NEW) | Ban user | حظر المستخدم |
| `admin_close_report` (NEW) | Close report | إغلاق البلاغ |
| `admin_send_announcement` (NEW) | Send announcement | إرسال الإعلان |
| `admin_code_used` (NEW) | Used | مستخدم |
| `admin_code_expired` (NEW) | Expired | منتهي |
| `admin_tab_avatars` (NEW) | Avatars | الأفاتارات |
| `admin_upload` (NEW) | Upload | رفع |
| `admin_tab_requests` (NEW) | Requests | الطلبات |
| `admin_tab_submissions` (NEW) | Content | المحتوى |
| `admin_confirm_payment_body` (NEW) | %1$s · %2$s · %3$s LYD | %1$s · %2$s · %3$s د.ل |
| `plan_locked_online_plain` | The online status switch is for Legendary subscribers only. | زر حالة الاتصال متاح لمشتركي Legendary فقط. |
| `profile_my_content_empty_plain` | No content yet — create your addons and worlds from the admin panel | لا يوجد محتوى بعد — أنشئ إضافاتك وعوالمك من لوحة الإدارة |
| `profile_offline_plain` | Hidden | مخفي |
| `profile_open_profile_plain` | Open profile ↗ | فتح الملف ↗ |
