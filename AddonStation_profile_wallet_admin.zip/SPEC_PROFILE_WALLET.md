# AddonStation — UI Spec: Profile · Member profile · Profile sheet · AC wallet · How to earn AC · Transaction history

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified. The designs were checked against the app's real structure (screen classes, data models and string keys), so they follow what the app actually has.
`reference/core_screens_preview.html` is a clickable visual reference of every screen and state here (screen selector with *User* and *Admin* groups, Light/Dark, English/Arabic, state buttons). Open it in a browser and follow it for the exact look.
Tokens (dark/light), fonts, shapes, icon tiles, status chips, top bar and fixed action bar are the same as in `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0. Shared chat parts (sheets, dialogs, fields) are in `SPEC_CHAT_DETAILS_STATES.md`; the bottom navigation bar is in `SPEC_WALLET_BOTTOMBAR.md`. Read those first.
All texts already exist in `strings.xml` (key table in the admin spec, section 12). Emoji/symbols in existing strings are replaced by vector icons: use the `*_plain` keys from `res/values*/strings_profile_wallet_admin.xml`. **Do not change profile, friends, wallet, task or redeem logic.** This spec **replaces** the "AC wallet" screen and the profile screens of earlier specs (`SPEC_PROFILES.md`, wallet part of `SPEC_WALLET_BOTTOMBAR.md`); the compact wallet card and the bottom bar stay as they are.

| Screen | Opens from |
|---|---|
| My profile | Profile tab |
| Member profile | tap a user (members list, creators, friend requests, notifications) |
| Profile sheet | "View profile" in the chat message menu |
| AC wallet | AC pill on Home, compact wallet card, Quick actions |
| How to earn AC | "How to earn AC" section of the wallet |
| Transaction history | "View all" in the wallet |

## 1. My profile
Bottom navigation bar visible (Profile tab selected). Vertical scroll.
1. **Cover** (height 130): the user's banner or the default gradient; gradient overlay to `bg`. Top row (padding 12): back button · spacer · **Full settings** gear (44 circle, `#0A0F1C`@60%, white) → Settings.
2. **Header** (padding 16, overlapping the cover by 38): avatar 80 circle with a 4dp `bg` border; **status dot** 22 at the end corner (green when online, grey `#6B7A94` when hidden; 4dp border in `bg`). Beside it: display name 20sp/800, `@username` 12sp muted.
3. **Chips** (wrap, gap 6): level chip `profile_lv_badge` (surfaceHigh, chipText, 11sp/800, radius 8) + one chip per role (Epic purple, Legendary gold, Creator blue, Admin gold, Moderator blue — section "Roles").
4. **Custom status** box (margin top 12, barSurface, radius 12, padding 10×12, 13sp chipText) — hidden when empty.
5. **Action row** (margin top 14, gap 10, height 44, radius 12): **Edit my profile** (`profile_edit_mine_plain`, primary gradient, weight 1) → Edit profile · **Dashboard** (`profile_dashboard_plain`, outlined; only for creators and admins → Creator Dashboard / Admin panel).
6. **Level card** (surface, 1dp border, radius 16, padding 14, margin top 12): bolt icon tile 44 · column [`profile_level_reputation` 12sp muted; `profile_level_active` 15sp/800] · LV chip at the end. Below: XP bar (8 high, radius 4, track surfaceHigh, fill blue→blueLink gradient) and `profile_xp_progress` ("Level 7 · 40/100 to next level") 12sp muted.
7. **Statistics** (`profile_statistics`, section label): 3-column grid, gap 8, two rows of stat cards (min height 72, radius 16, surface, 1dp border): number 20sp/800 + label 12sp/700 muted — Published (`profile_stat_published`), Worlds (`profile_stat_worlds`), My content (`profile_stats_content`), Downloads (`profile_stats_downloads`), Favorites (`profile_stats_favorites`), Level (`profile_stats_level`).
8. **Tabs** (segmented, margin top 16): About · My content · Favorites · My plan (`profile_tab_about`, `profile_tab_content`, `profile_tab_favorites`, `profile_tab_plan`). Selected = blue fill, white 12sp/800.
   - **About:** card "About me" (`profile_about_me` label 12sp muted + bio 14sp, default `profile_about_default`); section `profile_account_info_plain` → one card with rows (min 48, 1dp dividers): Email (`profile_email`) · Member since (`profile_member_since`) · Online status (`profile_online_status`) with a **switch** (hidden shows `profile_offline_plain`; locked for non-Legendary, see `plan_locked_online_plain`); section `profile_roles` with role chips.
   - **My content:** section `profile_content_section`; 2-column grid (gap 12) of item cards as in Addon details (thumbnail 100, tier badge, title, `item_by`). Empty: `profile_no_content_published` (visitors) / `profile_my_content_empty_plain` (owner), cube icon in an 88 circle.
   - **Favorites:** 2-column grid; each card has a gold filled star button (30 circle) at the thumbnail's bottom-end to unsave. Empty: `profile_favorites_empty_plain`.
   - **My plan:** card — label `profile_current_plan` (12sp muted) · icon tile 44 (Free sparkle / Epic gem / Legendary crown) + plan name 18sp/800 + "Expires on [date]" (`home_plan_expires`) or `home_plan_active_forever` · **Active** status chip · feature chips of the plan · buttons (gap 10, height 44): **Manage** (`profile_manage`, primary → Plans/My orders) and **Upgrade** (`profile_upgrade_plain`, outlined, goldText) for non-Legendary users.
9. **Footer row** (margin 20/0/30, surface, 1dp border, radius 14, min height 56): gear icon · `profile_full_settings` · chevron (AutoMirrored) → Settings.

## 2. Member profile
Same cover (back button only), header, chips and bio card. **Action row:** relationship button (weight 1) + **Message** (`profile_message_plain`, outlined, → private chat):
- not friends: **Add friend** (`profile_add_friend_plain`, primary, plus icon)
- request sent: **Request sent** (`profile_friend_sent`, outlined, disabled, check icon)
- friends: **Friends** (`profile_friends_plain`, green fill `#3FBF6A`, white, check icon)
Then bio card · 3 stat cards (Published, Downloads, Level) · **Content** section grid. Block/Report live in the chat message menu and in this screen's overflow menu (see `SPEC_CHAT_DETAILS_STATES.md`).

## 3. Profile sheet (chat → View profile)
Bottom sheet over the dimmed room (barSurface, radius 24 top, padding 8/16/22, grab handle). Row: avatar 72 + status dot · column [name 18sp/800; `@username` 12sp muted; "Online" (`profile_online`, okText) or hidden]. Role chips and custom status as above. Buttons (gap 10, 44 high): **Add friend / Request sent / Friends** + **Message**. Centered link **Open profile** (`profile_open_profile_plain`, blueLink 13sp/800, 44 high) → Member profile.

## 4. AC wallet
Top bar title `ac_title` ("AC wallet"). Scroll content, padding 16. **No bottom bar** (detail screen).
1. **Balance card:** gradient 145° `#3E2D0C`→`#1B1405` (both themes), 1dp `#8A6A22`, radius 18, padding 16: `coin_ac.png` 56 + label "AC wallet · Current balance" (12sp/700 `#E8D5A3`) + balance 34sp/800 gold + "AC" 14sp. (Daily reward claiming stays on the compact card / Home as today.)
2. **AC gift code card** (surface, 1dp border, radius 16, padding 14): gift icon tile 44 (purple) · title `ac_redeem_title` 15sp/800 · hint `ac_redeem_hint` ("8 characters: uppercase, lowercase and two digits") 12sp muted. **Code input:** 8 separate slots (gap 6, each flex 1, 48 high, radius 10, surface, 1dp border; the filled slot border = blueLink; characters 18sp/800, left-to-right even in Arabic). Typing/pasting fills the slots (auto-detect pasted codes).
   - **Detected:** info message (blue@12% bg, 1dp blue@35%, spark icon 18, 13sp/800 blueLink): `ac_redeem_detected` ("Code tier: 500 AC").
   - **Success:** ok message with check: `ac_redeem_success` ("Added 500 AC to your balance."), and the balance counts up.
   - **Errors** (error message, alert icon): `ac_redeem_invalid`, `ac_redeem_off`, `ac_redeem_expired`, `ac_redeem_exhausted`, `ac_redeem_used`; signed-out: `ac_redeem_sign_in`.
   - Button **`ac_redeem_action`** (full width, 48 high, radius 12, primary gradient), disabled until 8 characters.
3. **How to earn AC** (`ac_tasks`): section label + one card with the first 3 tasks (see 5) + "View all".
4. **Transaction history** (`ac_history`): section label + "View all" link (blueLink 13sp/800) + the latest 3 rows (see 6).
5. Info note at the end: info icon 16 + `ac_desc` 12sp muted ("AC is an internal reward currency… no purchase or cash-out").

## 5. How to earn AC (tasks)
Top bar title `ac_tasks`. One card; **task row** (min height 64, padding 12×14, gap 12, 1dp dividers): icon tile 40 (target, blueLink) · column [task title 15sp/800; line with a **frequency chip** (22 high, radius 11, surfaceHigh, 11sp/800) + "+[N] AC" 12sp muted] · action at the end:
- claimable: **Claim** (`ac_claim`, 40 high, radius 10, primary fill, 12sp/800)
- done: **Claimed** (`ac_claimed`, okText, check icon 16, no border)
- admin-granted (manual): lock icon in a disabled button (no action).
Frequency chips: `ac_freq_daily`, `ac_freq_once`, `ac_freq_streak`, `ac_freq_manual`. Claim success → snackbar with the amount and the balance updates; the "streak" task shows the day streak. Note `ac_desc` at the bottom.

## 6. Transaction history
Top bar title `ac_history`. One card of rows (min height 64, padding 12×14, gap 12): icon tile 40 · column [kind title 15sp/800; "balance [N] · [date]" 12sp muted] · amount 15sp/800 (`+[N] AC` in okText, `−[N] AC` in errorText, real minus sign).
| Kind | String | Icon | Accent | Sign |
|---|---|---|---|---|
| Welcome bonus | `ac_kind_welcome` | Gift | ok | + |
| Daily reward | `ac_kind_daily` | Schedule | gold | + |
| Streak reward | `ac_kind_streak` | Bolt | gold | + |
| AC task | `ac_kind_task` | Target | blueLink | + |
| Gift code | `ac_kind_code` | Gift | purple | + |
| Event reward | `ac_kind_event` | AutoAwesome | purple | + |
| Admin grant | `ac_kind_admin` | Shield | gold | + / − |
| Content unlock | `ac_kind_unlock` | Lock | error | − |
Empty state: 88 circle with a receipt icon + `ac_no_transactions`. Paginate (load more on scroll). Loading/error states: see `SPEC_CHAT_DETAILS_STATES.md` section 8.

## 7. Members list correction (chat)
The chat members screen is grouped by role, then presence: sections `grp_admin`, `grp_moderators`, `grp_creators`, `grp_legendary`, `grp_epic`, then `grp_online` / `grp_offline` for everyone else (section label 13sp/800 goldText + count). This replaces the flat list in `SPEC_CHAT_DETAILS_STATES.md` section 3.

## 8. Light theme, Arabic (RTL), accessibility
- Light/dark tokens as in `SPEC_ITEM_PLANS_ORDERS_ALERTS.md`; the cover overlay, the gold balance card and the code slots keep their colors in both themes.
- RTL: start/end everywhere; tabs, chips and grids mirror; chevrons AutoMirrored; **the 8-slot code stays left-to-right**; amounts "+[N] AC" keep their order (use Unicode isolates). Arabic uses Tajawal (no letter spacing).
- Numbers follow the app-wide digit convention (see `SPEC_HOME_V2.md`).
- Accessibility: targets ≥ 44dp, content descriptions on the gear/back/star buttons and slots ("character 3 of 8"), message regions announce politely, tab segments use the tab role.

## 9. Assets
```
assets/images/coin_ac.png            AC coin
assets/images/ic_default_profile.jpg default avatar
assets/images/item_placeholder.jpg   fallback thumbnail
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/core_screens_preview.html  clickable visual reference
```
Copy images to `res/drawable-nodpi/`, fonts to `res/font/`, merge the strings file into the project.
