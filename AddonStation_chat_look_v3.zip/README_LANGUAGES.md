# Languages — Chat look v3

The app has **8 languages**: English (default), العربية `ar` (RTL), Français `fr`, Türkçe `tr`, Español `es`, Русский `ru`, Português `pt`, 中文 `zh`.

## Strings
`res/values*/strings_chat_look.xml` (one per language) holds the **5 new keys**: `chat_filter_unread`, `chat_search_members`, `chat_last_seen`, `cd_scroll_to_bottom`, `cd_search_rooms`. All other texts already exist in the app in 8 languages (`comm_*`, `chat_*`, `grp_*`, `nav_*`). Two keys come from the previous package (`AddonStation_chat_extras_edit_profile`): `comm_rules_banner_plain` and `comm_room_cash`.

## Layout rules for all languages
- Only Arabic is RTL: this design uses logical corners/insets (start/end) everywhere; in Compose use `RoundedCornerShape` with the layout direction, never left/right.
- Allow **30–40% longer text** (fr, es, pt, ru): bubbles wrap at 272dp, labels ellipsize on one line, buttons grow. Chinese is shorter.
- No uppercase transform or letter spacing for ar and zh (section labels use uppercase + .6sp only for Latin scripts). Turkish uppercase needs the Turkish locale.
- Fonts: Nunito for Latin and Cyrillic (ru), Tajawal for Arabic, the system CJK font for zh. The pixel font only for the `comm_title` heading in Latin scripts.
- Dates, relative times, numbers and plurals: locale formatters only.
- Test: Dark/Light × en · ar · ru · zh, font scale 100% and 130%.
