# AddonStation — UI Spec: Chat look v3 (messages, rooms list, members list, message menu)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light and Arabic (RTL) are specified. This is a **visual polish** of the chat: it keeps all chat logic (roles, replies, reactions, hiding, pinning, muting, read-only rooms, uploads) and changes layout, shapes and colors only.
`reference/chat_look_v3_preview.html` is a clickable reference (screen selector, state buttons, Light/Dark, English/Arabic). Open it in a browser and follow it for the exact look. Tokens (dark/light), fonts, chips, fields and sheets: `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0. This spec **replaces** the message styling in `SPEC_CHAT_PANELS_STORE.md` (2.2), the rooms list in `SPEC_CHAT_EXTRAS_EDIT_PROFILE.md` (1), the members list in `SPEC_CHAT_DETAILS_STATES.md` (3) / `SPEC_PROFILE_WALLET.md` (7), and the message menu in `SPEC_CHAT_DETAILS_STATES.md` (1). Everything else in those specs (header actions, emoji/stickers panels, warnings, dialogs, media messages) stays.

## 1. Room — messages
### 1.1 Background and date chips
- Background: `bg` plus a soft glow from the top: radial gradient, ellipse 120% × 50% centered at the top, `#2E7BEF`@10% (light: `#2563D6`@8%) → transparent at 65%.
- Room avatar in the header: 44 circle; when someone is online it gets an **online ring** (2dp gap in `bg` + 2dp `#3FBF6A`).
- **Date chip** (`chat_today`, `chat_yesterday`, or the date): centered pill, surfaceHigh@88% with a 6dp background blur, textMuted 12sp/800, padding 5×14, radius 14, margin 10/0/6.
### 1.2 Grouping
Consecutive messages from the same sender within 5 minutes form a **group** (gap 3 between bubbles, 8 between groups). Inside a group:
- Others: **name row** above the first bubble only — name 12sp/800 in the role color + role chip (10sp/800, radius 9, padding 2×8; Manager = ok tint with a shield icon). **Avatar 32** only beside the last bubble (aligned to its bottom); the other bubbles keep a 32dp spacer on the avatar side.
- Own messages: no name, no avatar; aligned to the end.
### 1.3 Bubble
Padding 8×12×6, text 15sp/600, line height 1.45, max width 272, radius 18; others: surface, 1dp border, light shadow 0 1dp 3dp; **own: gradient 135° `#2E7BEF` → `#4C9AFF`, white text, shadow 0 4dp 14dp blue@28%, no border**.
Corner radii (sender side = start for others, end for own; use `RoundedCornerShape` with the layout direction so RTL mirrors):
| Position | Sender-side corners | Other corners |
|---|---|---|
| Single | bottom 4 (tail), top 18 | 18 |
| First | top 18, bottom 6 | 18 |
| Middle | top 6, bottom 6 | 18 |
| Last | top 6, bottom 4 (tail) | 18 |
**Meta line:** time 11sp/700 textMuted (own: white@78%) + double-check delivery icon 14 (own only, `cd_message_delivered`), inline at the end of the last text line (floats to the end, 12dp from the text).
### 1.4 Rich content inside bubbles
- **Reply quote:** at the top of the bubble (margin bottom 6): radius 10, padding 6×10×6×8, background blueLink@12% (own: white@18%), a 3dp bar (blueLink; own: white) · name 12sp/800 blueLink (own: white) · quoted text 12sp textMuted, one line (own: white@85%). Tap scrolls to the original.
- **Mention** `@name`: blueLink 800 on blueLink@14%, radius 6, padding 0×4.
- **Image:** inside the bubble with 2dp padding: image 236×150, radius 14; optional caption below (margin 6). Tap → image viewer.
- **Reactions:** a row under the bubble (margin 0/4, gap 4, wraps): chips 26 high, radius 13, padding 0×9, surfaceHigh, 1dp border, emoji 13 + count 12sp/800 chipText; your reaction: blueLink@20% fill, blueLink@50% border, count in blueLink. Tap toggles; long-press shows who reacted.
- **Hidden message, announcement, audio/video, upload states:** as in the earlier specs.
- **Typing:** a small bubble (padding 12×14) with three 7dp dots (blueLink, opacity pulse 1.2s, static with reduced motion), with the sender's avatar.
### 1.5 Scroll and unread
- **NEW divider** at the first unread message: 1dp blue lines with `chat_new_tag` (11sp/800 blueLink, letter spacing .8) in the middle (margin 10/0/4).
- **Scroll-to-bottom button:** 44 circle (surface, 1dp border, shadow 0 6dp 18dp black@35%, arrow-down icon 20, `cd_scroll_to_bottom`), at the bottom-end, 12 above the composer; appears when scrolled up more than one screen; unread badge (min 20 high, radius 10, blue, white 11sp/800) at its top-end corner (−8, −4).
### 1.6 Composer
Container: barSurface, 1dp top border, padding 8/10/14, gap 8, bottom-aligned. **One rounded field** (min height 48, radius 24, surface, 1dp border, padding 0/6, gap 2): emoji toggle 40 at the start · text (15sp, hint `chat_hint`) · attach button 40 at the end. **Send button** 48 circle, primary gradient, shadow 0 6dp 16dp blue@40% (disabled and surfaceHigh when empty). The reply strip, typing strip and warnings sit above this container as before.

## 2. Rooms list (Community)
Bottom bar visible (Chat tab selected).
- **Header:** `comm_title` in the pixel font 20sp + a search icon button 44 (`cd_search_rooms`).
- **Rules chip:** height 40, radius 12, warning@10% over surface, 1dp warning@35% border, padding 0/12, gap 8: shield icon 16 (warning) + `comm_rules_banner_plain` 12sp chipText, one line with ellipsis + chevron (AutoMirrored) → Community rules.
- **Filter chips** (edge to edge, horizontal scroll, 36 high, radius 18, 13sp/800): `common_all`, `chat_filter_unread` (with a blue count badge), `comm_main_rooms`, `comm_lang_rooms`; selected = blue fill, white.
- **Section labels** (`comm_main_rooms`, `comm_lang_rooms`): 12sp/800 goldText, uppercase with .6sp spacing for Latin scripts (none for ar/zh), margin 18/4/6.
- **Room row** (no card; min height 72, padding 10×4, gap 14, inset divider starting 76 from the start edge): room icon **52** circle with the online ring when someone is online · column [line 1: name 16sp/800 + a small pin icon 13 (gold) for pinned rooms + time 11sp textMuted at the end · line 2: "**[Sender]:** [last message]" 13sp textMuted, one line (sender in chipText 700) + trailing indicators: lock 14 (read-only, `comm_locked`), bell-off 14 (muted), **unread badge** (min 22, radius 11, blue, white 12sp/800)]. Locked rows at 80% opacity. Sort: pinned first, then by last activity. Language rooms use the `ic_room_lang_*` icons; the Cash room uses `ic_room_cash`.

## 3. Members list
Top bar `chat_members` + a count chip (30 high, min 30, radius 15, surfaceHigh, 13sp/800). Search field `chat_search_members` (48 high, radius 14, margin 8/16/4).
- **Section header:** 8dp color dot + label 12sp/800 chipText + count chip (11sp/800, surfaceHigh, radius 9). Order and dot colors: Admin (gold) · Moderators (blue) · Creators (purple) · Legendary (gold) · Epic (purple) · **Online** (green) · **Offline** (muted) — labels `grp_admin`, `grp_moderators`, `grp_creators`, `grp_legendary`, `grp_epic`, `grp_online`, `grp_offline`.
- **Row** (min height 64, padding 8×4, gap 12, inset divider starting 60): avatar 44 + presence dot 14 (3dp `bg` border; green / grey `#6B7A94`) · column [name 15sp/800 + role chip; line 2: the member's custom status (12sp textMuted, one line) or `chat_last_seen` for offline members] · ghost **message button** 40 circle (surface, message icon 18) → private chat. Offline rows at 62% opacity. Tap a row → profile sheet.

## 4. Message menu (floating)
Replaces the bottom sheet. On long-press (with haptic feedback): scrim `#050810`@70% + 3dp blur; the pressed message stays visible in place; around it:
- **Reaction pill:** barSurface, 1dp border, radius 28, padding 6, shadow 0 10dp 30dp black@50%: five quick emoji in 44 circles (24sp) + a **+** circle (surfaceHigh, opens the emoji panel). Enters with a scale from .9 → 1 (120 ms; none with reduced motion).
- **Menu card:** width 260, barSurface, 1dp border, radius 20, shadow 0 14dp 40dp black@55%, padding 6/0; rows 50 high, padding 0/16, gap 14, icon 20 textMuted + label 15sp/700. Group 1: Reply, Copy text, Pin, View profile · divider (1dp, margin 4/0) · group 2: Report, Mute this user, **Block user** (danger = errorText). **Own message:** Reply, Copy text, Pin · divider · **Delete my message** (danger) with a sub-line `chat_delete_left` (11sp textMuted). **Staff:** add Hide message and the moderation delete as in `SPEC_CHAT_DETAILS_STATES.md`.
- Alignment: the pill and card align to the sender's side (start for others, end for own); if there is no room below the message, place them above it.
- Same actions, results and rules as before (3-minute delete window, mute rules, snackbars).

## 5. Light theme, Arabic (RTL), accessibility
- Light: use the light tokens; own bubbles keep the blue gradient; the chat glow is blue@8%; the menu scrim stays dark.
- RTL: corners, tails, avatar side, reply bars, ticks and insets all mirror (logical start/end). Arabic text uses Tajawal; times and numbers follow the app's digit convention; mixed Latin names inside Arabic text use Unicode isolates.
- Accessibility: touch targets ≥ 44dp (the 36–40dp ghost buttons need 44dp hit areas); each message is one accessibility node ("[name], [text], [time], delivered, [N] reactions"); reactions and the scroll button have descriptions; typing and new-message announcements use polite live regions; respect reduced motion (static dots, no scale-in).

## 6. Strings
All existing: `comm_title`, `comm_main_rooms`, `comm_lang_rooms`, `comm_locked`, `comm_rules_banner`, `common_all`, `chat_members`, `chat_today`, `chat_yesterday`, `chat_new_tag`, `chat_hint`, `chat_reply`, `chat_copy_text`, `chat_pin`, `chat_view_profile`, `chat_report`, `chat_mute_user`, `block_user`, `chat_delete_mine`, `chat_delete_left`, `grp_*`, `role_moderator`, `nav_chat`, `nav_settings`, `nav_store`. New (in `res/values*/strings_chat_look.xml`, 8 languages): `chat_filter_unread`, `chat_search_members`, `chat_last_seen`, `cd_scroll_to_bottom`, `cd_search_rooms`. From the previous package: `comm_rules_banner_plain`, `comm_room_cash`, `cd_message_delivered`.
