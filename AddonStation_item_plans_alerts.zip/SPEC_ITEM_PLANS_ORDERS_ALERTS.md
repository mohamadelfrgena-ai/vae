# AddonStation — UI Spec: Addon details · Plans · Checkout · My orders · Notifications

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified for every screen.
The file `reference/new_screens_preview.html` is a clickable visual reference of all five screens (theme, language and state switches). Open it in a browser and follow it for exact look; this spec gives the numbers and rules.
All texts already exist in `strings.xml` (see the key table at the end). Emoji in existing strings are replaced by vector icons: use the emoji-free `*_plain` keys from `res/values*/strings_item_plans_alerts.xml`. Do not change the payment, download or permission logic: only layout, icons and colors change.
These five screens are **detail screens: no bottom navigation bar**.

| Screen | Opens from |
|---|---|
| 1. Addon details | any addon/world card (Home, Store, search, creators, profile lists) |
| 2. Plans | Upgrade buttons, "Buy subscription", locked items, Settings → My plan |
| 3. Checkout | Choose plan on the Plans screen |
| 4. My orders | Profile → My orders, after sending a receipt |
| 5. Notifications | Bell icon on Home (settings gear opens Notification settings) |

## 0. Tokens
All colors live in one `AppColors` object with a dark and a light instance (see also `SPEC_HOME_V2.md`).
| Token | Dark | Light |
|---|---|---|
| bg | `#0A0F1C` | `#F4F7FC` |
| surface | `#121A2B` | `#FFFFFF` |
| surfaceHigh | `#1A2438` | `#E8EEF8` |
| barSurface | `#0E1526` | `#FFFFFF` |
| border | `#223049` | `#D5DEEC` |
| text / textMuted / chipText | `#EAF0FA` / `#9DB0CF` / `#C4D1E8` | `#0E1526` / `#53627F` / `#33425F` |
| blue / blueLink | `#2E7BEF` / `#6FA8FF` | `#2563D6` / `#1D4FB8` |
| gold (fills) / goldText | `#F0C25E` / `#F0C25E` | `#F0C25E` / `#7A5600` |
| gold border / Legendary bg | `#8A6A22` / `#2A1F08`→`#121A2B` (135°) | `#E0B24A` / `#FFF3D2`→`#FFFFFF` |
| epic / epicText | `#9B6BFF` / `#B79BFF` | `#9B6BFF` / `#6D3FD6` |
| ok / okText | `#3FBF6A` / `#7FD99A` | `#3FBF6A` / `#1E7A44` |
| warning / error / errorText | `#F0A04B` / `#FF6B78` / `#FF8791` | `#B25E00` / `#FF6B78` / `#B3262E` |
| card elevation | none | 0 1dp 3dp `#0E1526`@8% |
Primary gradient 135° `#2E7BEF` → `#4C9AFF`; gold gradient `#F0C25E` → `#E0A93A`; epic gradient `#9B6BFF` → `#7C4DFF`.
Fonts: pixel font `assets/fonts/pixel_regular.ttf` for screen titles in the top bar (15sp, letter spacing 1sp; **Arabic: Tajawal ExtraBold, no letter spacing**). Body: Nunito (Arabic: Tajawal).
Shapes: cards 14–20 radius, buttons 12–16, chips full-round (28dp high), icon tiles 44×44 radius 12. Min touch target 44dp. Screen margin 16.
**Icon tile:** 44×44 (40 in compact rows), radius 12, bg = accent@16%, 1dp border = accent@40%, Material Outlined icon 22dp tinted with the accent.
**Status chip:** 11sp/800, radius 10, padding 4×10, bg = color@18%, text = the color's text variant: Active=ok, Under review=blue, Pending=warning, Rejected=error.
**Top bar:** barSurface, 1dp bottom border, padding 10; back button 44×44 circle (surface, AutoMirrored ArrowBack); title in the pixel font; optional action button 44×44.
**Fixed action bar:** barSurface, 1dp top border, padding 12/16/20 + system inset; content scrolls above it (add bottom padding ≈110dp to the scroll content so nothing is hidden).

---

## 1. Addon details
Column: **scrollable content + fixed action bar**. No top bar: the back and save buttons float over the hero image.
1. **Hero** (height 250, full width): item cover (center-crop; fallback `item_placeholder.jpg`). Gradient overlay: `#0A0F1C`@55% at top → transparent at 32% → `bg` at 100% (blends into the page in both themes). Top row (padding 12, gap 10): back button (44 circle, `#0A0F1C`@60%, white icon) · spacer · **Save pill** (height 44, radius 22, padding 0/14, bg `#0A0F1C`@60%, 1dp white@25%, white 13sp/800): outline star + `item_save_plain` ("Save"); when saved: star filled gold + `item_saved_plain` ("Saved") in gold. Bottom-start (16, 26): tier badge **EPIC** (purple) or **LEGENDARY** (gold) for premium items (10sp/800, radius 8, padding 3×9).
2. **Header block** (padding 16, overlaps the hero by 14): title 22sp/800 · row (gap 8): creator avatar 28 + `item_by` ("By [Creator]") muted · row (gap 10, margin top 10): download count (download icon 16 + number), view count (eye icon 16 + number), category chip ("Addons"/"Worlds"). Numbers have content descriptions `item_stats_downloads_cd` / `item_stats_views_cd`.
3. **Description:** label `item_description` (13sp/800 goldText, margin 22/8) + text 14sp, line height 1.6, chipText.
4. **Similar content:** header row [label `item_similar` weight 1 · link `view_all` blueLink 13sp/800, 44 high], then a horizontal list (gap 12): cards 150 wide, radius 14, surface, 1dp border; thumbnail 100 high with badge top-start 6 (NEW blue / EPIC purple / LEGENDARY gold); title 14sp/800; `item_by` 12sp muted. Empty: `item_no_similar`.
5. **Fixed action bar — states** (pick by the user's plan, AC and the item's tier):
   - **Free / allowed:** full-width **Download** button — height 56, radius 16, primary gradient, white 17sp/800, download icon 22 + `item_download_plain`, shadow 0 8dp 22dp blue@40%.
   - **Downloading:** same button disabled with a progress bar and `item_download_progress` ("Downloading… 40%"); on failure show snackbar `item_download_failed` with Retry.
   - **Locked by plan:** row — lock icon 20 + `item_requires_epic_plain` / `item_requires_legendary_plain` in epicText (800, weight 1) · **Upgrade** button (`item_upgrade`, 44 high, radius 12, gold gradient, `#1B1405` text 14sp/800, padding 18) → Plans screen.
   - **Unlock with AC:** full-width gold button 56 high — `coin_ac.png` 26 + `item_unlock_ac` ("[N] AC · Unlock with AC"). If the balance is too low show snackbar "Not enough AC" with an action that opens the AC wallet.
   - Existing error messages stay: `item_no_permission`, `plan_download_limit` (with Upgrade action), `item_file_missing`.
6. **Not found** (`item_not_found_plain`): centered empty state — 88 circle (surfaceHigh) with a cube icon 40, text 14sp muted, and a "Back" button.
7. Saving shows snackbars `item_added_fav_plain` / `item_removed_fav`; content descriptions `cd_save_item` / `cd_unsave_item`.

## 2. Plans
Top bar title: `plan_label` ("CHOOSE YOUR EXPERIENCE"). Scrollable content, padding 16.
- Intro `plan_intro` 13sp, line height 1.6, textMuted, margin 8/0/16.
- **Plan card** (radius 20, padding 16, surface, 1dp border, margin bottom 12, light elevation):
  - Header row (gap 12): icon tile 44 (Free: sparkle, ok · Epic: gem, epic · Legendary: crown, gold) · column [name 18sp/800 (`plan_*_name`; Legendary name in goldText) · tagline 12sp muted (`plan_*_tagline`)] weight 1 · status chip **Active** (`plan_status_approved`) on the user's current plan.
  - **Feature chips** (margin top 12, wrap, gap 6, chips 28 high, radius 14, padding 12, surfaceHigh, chipText 12sp/800): split `plan_free_features`, `plan_epic_features_plain`, `plan_legendary_features_plain` on " · " (3 chips each); Epic adds a chip `plan_current_epic`, Legendary adds `plan_current_legendary`.
  - **Price** (Epic, Legendary; margin 14/10): `plan_price_line_usd` ("[N] LYD · $[N] / [N] days") 13sp/800 chipText.
  - **Button** (Epic, Legendary): `plan_choose`, full width, 56 high, radius 16, epic gradient / gold gradient (dark text). Not shown on the current plan; disabled with `plan_unavailable` if the plan is not available.
  - Epic card: 1dp border epic. Legendary card: 1dp gold border + Legendary background. Free card: normal border.
  - If the user already has a paid plan: the Active chip moves there and the card shows "Expires on [date]" (existing string) instead of the button; lower tiers have no button.
- **Footer note:** lock icon 16 + `plan_payment_note` 12sp muted, padding 4/4/24.

## 3. Checkout
Top bar title: `plan_checkout`. Scrollable content (padding 16, bottom ≈110) + fixed action bar.
- **Stepper** (margin bottom 14): 3 steps with labels 11sp/800 — `plan_choose` (done: blue circle with check), `plan_payment_method` (current: 2dp blue ring, label text color), `plan_submit_receipt` (todo: border color, label muted); circle 24; connectors 2dp border color.
- **Order-ready banner** (after the order is created): radius 16, padding 12×14, bg ok@14%, 1dp ok@40%, check icon 20 + `plan_order_ready` 14sp/800 and `plan_order_number`: [N] 12sp muted.
- **Summary card:** surface, 1dp border, radius 16, padding 12×14; icon tile 40 + plan name 18sp/800 + price line 12sp muted.
- **Payment method:** label `plan_payment_method`, hint `plan_order_instructions` (13sp muted), then one row per method (radio): min height 56, radius 14, surface; selected 2dp blue border + blue radio (6dp inner ring) + card icon at the end.
- **Transfer details card:** two rows, 1dp divider: [label `plan_account_number` / `plan_beneficiary` 12sp muted + value 15sp/800] weight 1 · **Copy** button (44 high, radius 12, 1dp border, blueLink 13sp/800, copy icon 16 + `plan_copy`); copying shows snackbar `plan_copied`.
- **Receipt:** label `plan_receipt`; dashed 2dp border zone (radius 16, min height 112, surface, upload icon 28, text "Choose the receipt image" 14sp/800 chipText, "PNG · JPEG · WEBP" 12sp muted). After picking an image show its thumbnail + a Replace action. Field `plan_transaction_ref` (48 high, radius 12, surface, 1dp border).
- **Fixed action bar:** before the order exists: **`plan_create_order`** (primary gradient, 56). After: **`plan_submit_receipt`** (primary gradient, upload icon 20 + label). If tapped without an image show `plan_choose_receipt`. On success go to My orders and show the banner `plan_order_sent_plain`.
- Keep the existing validation, accepted image types and size limit.

## 4. My orders
Top bar title: `plan_my_orders`. Scrollable list, padding 12/16.
- **Info banner** (only right after sending a receipt): radius 16, padding 12×14, bg blue@14%, 1dp blue@40%, clock icon 20 + `plan_order_sent_plain` 14sp/800.
- **Order card** (radius 18, padding 14, surface, 1dp border, margin bottom 12): header — icon tile 40 (Epic gem / Legendary crown) · column [plan name 18sp/800 · `plan_order_number` + number 12sp muted] · status chip. Bottom row (margin top 12, padding top 10, 1dp top border): price line and date, 12sp muted, space-between.
  - Statuses: `plan_status_approved` (Active), `plan_status_submitted` (Under review), `plan_status_pending` (Pending), `plan_status_rejected` (Rejected).
  - **Pending:** button `plan_submit_receipt` (44 high, radius 12, primary gradient, upload icon 18, padding 18) under the row.
  - **Rejected:** hint `plan_status_rejected_hint` (12sp errorText) and a "Contact us" text button (existing Settings string).
- Newest first. Empty: `orders_empty`.

## 5. Notifications
Top bar title: `notif_title`; end action: gear icon button → Notification settings (`notif_settings`).
- Section labels (13sp/800 goldText, margin 14/0/6): `notif_section_new`, `notif_section_earlier`. Each section is one card (surface, 1dp border, radius 16, clipped, 1dp row dividers).
- **Row** (padding 14, gap 12): avatar 48 circle (or a 48 circle icon tile for system items) · column [name 15sp/800 + optional chip **`notif_new`** (10sp/800, white on blue, radius 7, padding 2×7) + time 11sp muted pushed to the end · type line 12sp muted · optional message preview box (13sp chipText, surfaceHigh, radius 10, padding 8×10)]. Unread rows: bg blue@8% and an 8dp blue dot at the start edge.
  - **Friend request:** type `notif_friend_request`; buttons row (gap 8, margin top 10): `notif_accept` (blue gradient, 44 high, radius 12, weight 1) and `notif_decline` (transparent, 1dp border, muted).
  - **Mention:** type `notif_mention` + " · [Room name]" + preview. **Reply:** type `notif_reply` + preview. Tap opens the chat at that message.
  - **Account & subscription:** gold star tile, title `notif_cat_account`, text from the notification.
  - **New content:** sparkle tile, title `notif_cat_content`, addon name; tap opens Addon details.
- **Empty state** (`notif_empty_plain`): centered, 88 circle (surfaceHigh) with a bell-off icon 40, text 14sp, line height 1.6, muted.
- Opening the screen marks items as read after 1s; pull to refresh.

## 6. Light theme and Arabic (RTL)
- Light: use the token table. Hero overlay stays dark at the top (white icons on photos) and fades into `bg`.
- RTL: `android:supportsRtl="true"`, start/end everywhere. Mirrors automatically: top-bar order, hero buttons, chips, horizontal lists, stepper direction, badge/dot positions, text alignment. Use `AutoMirrored` for the back arrow and chevrons; do not mirror download, star, lock, copy, upload, gear, bell icons.
- Arabic fonts: Tajawal for all text including titles; no letter spacing, no uppercase. Allow ~30% longer text: chips wrap, buttons grow (min height instead of fixed).
- Number format: follow the app-wide digit convention (see `SPEC_HOME_V2.md`); price line, order numbers and counts are formatted with `NumberFormat`. Wrap mixed Latin/number runs ("[N] AC · …", prices) with Unicode isolates if they reorder.

## 7. Accessibility
Touch targets ≥ 44dp; icon-only buttons have content descriptions; status chips are read with their meaning ("Pending"); the stepper announces "Step 2 of 3"; contrast checked for both themes (do not use `#6B7A94` or lighter greys for text).

## 8. Assets
```
assets/images/coin_ac.png            AC coin (unlock button)
assets/images/ic_default_profile.jpg default avatar
assets/images/item_placeholder.jpg   fallback cover/thumbnail
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/new_screens_preview.html   clickable visual reference
```
Copy images to `res/drawable-nodpi/`, fonts to `res/font/`, merge the two strings files into the project. Icons are Material Icons (ArrowBack, Star/StarBorder, Download, Visibility, Lock, Diamond, WorkspacePremium, AutoAwesome, ContentCopy, FileUpload, Check, Schedule, Settings, NotificationsOff, Chat, ViewInAr).

## 9. String keys used
| Key | English | Arabic |
|---|---|---|
| `item_by` | By %1$s | بواسطة %1$s |
| `item_description` | Description | الوصف |
| `item_download_plain` | Download | تحميل |
| `item_download_failed` | Download failed | تعذر التحميل |
| `item_downloading_plain` | Downloading... | جارٍ التحميل... |
| `item_file_missing` | The download file is not uploaded yet | ملف التحميل غير مرفوع بعد |
| `item_no_permission` | You don't have permission to download this content | لا تملك صلاحية تحميل هذا المحتوى |
| `item_no_similar` | No similar content | لا يوجد محتوى مشابه |
| `item_not_found_plain` | Not found — the content may have been deleted or not published yet | غير موجود — ربما حُذف المحتوى أو لم يُنشر بعد |
| `item_requires_epic_plain` | Requires Epic | يتطلب Epic |
| `item_requires_legendary_plain` | Requires Legendary | يتطلب Legendary |
| `item_save_plain` | Save | حفظ |
| `item_saved_plain` | Saved | محفوظ |
| `item_similar` | Similar content | محتوى مشابه |
| `item_unlock_ac` | %1$s AC · Unlock with AC | %1$s AC · افتح بالـ AC |
| `item_upgrade` | Upgrade | ترقية |
| `item_added_fav_plain` | Added to favorites | أُضيف إلى المفضلة |
| `item_removed_fav` | Removed from favorites | أُزيل من المفضلة |
| `item_view` | View → | عرض ← |
| `plan_account_number` | Account / wallet number | رقم الحساب / المحفظة |
| `plan_beneficiary` | Beneficiary name | اسم المستفيد |
| `plan_buy_plain` | Buy subscription | شراء اشتراك |
| `plan_checkout` | CHECKOUT | إتمام الشراء |
| `plan_choose` | Choose plan | اختيار الخطة |
| `plan_choose_receipt` | Choose the receipt image first | اختر صورة الإيصال أولًا |
| `plan_copy` | Copy | نسخ |
| `plan_create_order` | Create payment order | إنشاء طلب الدفع |
| `plan_current_epic` | Premium avatars + all the basics | أفاتارات مميزة + كل الأساسيات |
| `plan_current_free` | Free basics | الأساسيات المجانية |
| `plan_current_legendary` | Everything + a golden item next to your name | كل شيء + أداة ذهبية بجانب اسمك |
| `plan_download_limit` | You reached your download limit for this plan | وصلت إلى حد التحميلات لهذه الخطة |
| `plan_epic_features_plain` | Epic addons · More downloads · Subscriber access | إضافات Epic · تنزيلات أكثر · وصول المشتركين |
| `plan_epic_name` | Epic | ملحمي |
| `plan_epic_tagline` | More content and a wider play experience. | محتوى أكثر وتجربة لعب أوسع. |
| `plan_free_features` | Free content · Basic access · No subscription | محتوى مجاني · وصول أساسي · بدون اشتراك |
| `plan_free_name` | Free | مجاني |
| `plan_free_tagline` | Start exploring free addons and worlds. | ابدأ باكتشاف الإضافات والعوالم المجانية. |
| `plan_intro` | Continue your adventure without interruption and enjoy all exclusive features by upgrading your plan and unlocking unlimited downloads of addons and worlds | تابع مغامرتك دون انقطاع واستفد من كامل الميزات الحصرية، عبر ترقية باقتك وفتح تحميل غير محدود للإضافات والعوالم |
| `plan_item_section` | Item next to your name in chat | الأداة بجانب الاسم في الشات |
| `plan_join_legendary_plain` | JOIN LEGENDARY | انضم إلى الأسطوري |
| `plan_label` | CHOOSE YOUR EXPERIENCE | اختر تجربتك |
| `plan_legendary_features_plain` | Legendary addons · Legendary worlds · Priority access | إضافات Legendary · عوالم Legendary · أولوية الوصول |
| `plan_legendary_name` | Legendary | أسطوري |
| `plan_legendary_tagline` | Unlock premium content and VIP privileges. | افتح المحتوى المميز وامتيازات VIP. |
| `plan_locked_avatars_plain` | Locked avatars unlock with Epic or Legendary . | الأفاتارات المقفلة تفتح مع Epic أو Legendary . |
| `plan_locked_banner_note_plain` | All banners are locked — unlock with an Epic or Legendary subscription. | الأغلفة كلها مقفولة — لا تُفتح إلا باشتراك Epic أو Legendary . |
| `plan_locked_banners` | Locked banners need the right plan. | الأغلفة المقفلة تحتاج الخطة المناسبة. |
| `plan_locked_online_plain` | The online status switch is for Legendary subscribers only. | زر حالة الاتصال متاح لمشتركي Legendary فقط. |
| `plan_my_orders` | My orders | طلباتي |
| `plan_order_instructions` | Transfer the amount using the method below, then upload the receipt. | حوّل المبلغ عبر الطريقة التالية ثم ارفع الإيصال. |
| `plan_order_number` | Order number | رقم الطلب |
| `plan_order_ready` | Your order is ready | طلبك جاهز |
| `plan_order_sent_plain` | Your request was sent for review | تم إرسال طلبك للمراجعة |
| `plan_payment_method` | Payment method | طريقة الدفع |
| `plan_payment_note` | Payment: local transfer methods, then upload your receipt for review. | الدفع: طرق تحويل محلية، ثم ترفع الإيصال للمراجعة. |
| `plan_price_line` | %1$s / %2$s days | %1$s / %2$s يوم |
| `plan_price_line_usd` | %1$s LYD · $%2$s / %3$s days | %1$s د.ل · %2$s$ / %3$s يوم |
| `plan_receipt` | Receipt image (PNG / JPEG / WEBP) | صورة الإيصال (PNG / JPEG / WEBP) |
| `plan_start_now` | Start now | ابدأ الآن |
| `plan_status_approved` | Active | مفعّل |
| `plan_status_pending` | Pending | قيد الانتظار |
| `plan_status_rejected` | Rejected | مرفوض |
| `plan_status_submitted` | Under review | قيد المراجعة |
| `plan_submit_receipt` | Send receipt | إرسال الإيصال |
| `plan_title` | Subscriptions | الاشتراكات |
| `plan_transaction_ref` | Transaction number | رقم العملية أو التحويل |
| `plan_unavailable` | This plan is not available. | الخطة غير متاحة. |
| `notif_title` | Notifications | التنبيهات |
| `notif_empty_plain` | No notifications — when someone mentions you or sends you a friend request, it will appear here. | لا توجد تنبيهات — عندما يذكرك أحد أو يرسل لك طلب صداقة، سيظهر هنا. |
| `notif_friend_request` | Friend request | طلب صداقة |
| `notif_accept` | Accept | قبول |
| `notif_decline` | Decline | رفض |
| `notif_mention` | Mention | إشارة إليك |
| `notif_reply` | Reply | رد |
| `notif_new` | NEW | جديد |
| `notif_cat_account` | Account & subscription | الحساب والاشتراك |
| `notif_cat_content` | New addons & worlds | إضافات وعوالم جديدة |
| `notif_settings` | Notification settings | إعدادات الإشعارات |
| `view_all` | View all | عرض الكل |
| `common_back` | Back | رجوع |
| `common_cancel` | Cancel | إلغاء |
| `item_stats_downloads_cd` (NEW) | %1$s downloads | %1$s تنزيل |
| `item_stats_views_cd` (NEW) | %1$s views | %1$s مشاهدة |
| `plan_copied` (NEW) | Copied | تم النسخ |
| `orders_empty` (NEW) | No orders yet | لا توجد طلبات بعد |
| `notif_section_new` (NEW) | New | جديد |
| `notif_section_earlier` (NEW) | Earlier | السابقة |
| `item_download_progress` (NEW) | Downloading… %1$d%% | جارٍ التحميل… %1$d%% |
| `plan_status_rejected_hint` (NEW) | Your receipt was rejected. Check it and send it again, or contact us. | تم رفض الإيصال. تحقق منه وأرسله مرة أخرى، أو تواصل معنا. |
| `cd_save_item` (NEW) | Save to favorites | حفظ في المفضلة |
| `cd_unsave_item` (NEW) | Remove from favorites | إزالة من المفضلة |