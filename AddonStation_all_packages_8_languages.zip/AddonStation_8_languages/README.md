# AddonStation — all packages in all 8 languages

Every package keeps its previous content and now includes strings for the app's 8 languages
(English, العربية, Français, Türkçe, Español, Русский, Português, 中文) in `res/values-xx/`, a `README_LANGUAGES.md`,
and key tables with all languages where the spec has one.

- `AddonStation_arabic_strings.zip` also contains the app's full existing string files (`res/values-*/strings.xml`) for every language, extracted from the app.
- Packages without strings (handoff, home_v2, profiles, wallet_bottombar, auth_settings*, speedboat) need no new strings: all their texts already exist in the app in every language.
- Interactive previews (HTML) still switch between English and Arabic only (to test RTL); the other languages are LTR and only change text length and fonts.
