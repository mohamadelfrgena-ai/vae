# AddonStation — UI Spec: Email confirmation · Notifications prompt · Crash report · Profile daily reward · Member safety & moderation · Admin content editor · Language & theme pickers

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light and Arabic (RTL) are specified. These screens come from features that already exist in the latest build (strings and data models are there); only the design is new. Do not change any logic.
`reference/new_in_build_preview.html` is a clickable reference (Light/Dark, English/Arabic, state buttons). Tokens, fonts, chips, fields, sheets and dialogs: `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0 and `SPEC_CHAT_DETAILS_STATES.md`. All texts already exist in the app in 8 languages (`README_LANGUAGES.md`).

## 1. Email confirmation (after Create account)
No top bar, no bottom bar. Centered column, padding top 70:
- Mail circle 112 (ok@14% bg, mail icon 54 okText) with a **check badge** 34 (ok fill, 4dp `bg` border) at its bottom-end.
- Title `auth_confirm_title` 22sp/800 (margin 22) · text `auth_confirm_text` 14sp muted, line height 1.6, centered.
- **Email pill** (40 high, radius 20, surface, 1dp border, mail icon 16 + the address 14sp/800, margin 16).
- After resending: ok message (check icon + `auth_confirm_resent`, centered).
- Primary button `auth_confirm_retry` ("I confirmed — sign me in", 56 high, radius 16, margin 22). Outline button `auth_confirm_resend` (52 high, refresh icon 20, margin 10; add a 30-second cooldown with a counter).
- Hint: info icon 16 + `auth_confirm_hint` 12sp muted, centered (margin 20).

## 2. Notifications prompt
Bottom sheet over the Home screen (dim scrim `#000`@62%), shown once after the first sign-in (and not again for 7 days after "Later"); on Android 13+ "Turn on now" triggers the system permission. Sheet: barSurface, radius 24 top, padding 8/16/26, grab handle.
- Bell circle 72 (blue tint, bell icon 34) · title `notif_prompt_title` 20sp/800 · text `notif_prompt_text` 14sp muted, line height 1.6, centered.
- Category chips (centered, wrap, gap 8, 36 high, radius 18, surfaceHigh, 12sp/800, icon 18): chat, mentions, new content (`notif_cat_content`).
- Primary `notif_prompt_allow` (56 high, radius 16, margin 18) · text button `notif_prompt_later` (full width, 48 high, textMuted 15sp).

## 3. App crash report
Shown at the next launch after a crash. Full screen, centered, padding top 60:
- Circle 104 (error@14% bg, bug icon 52 errorText) · title `crash_report_title` 22sp/800 · body `crash_report_body` 14sp muted, line height 1.6.
- **Log box** (margin 20, radius 14, 1dp border, bg `#06090F` in both themes, text `#B9C6DC`): header row (padding 8×12, "LOG" 11sp/800 letter spacing 1 + a small copy button) and the report text in monospace 11sp, line height 1.6, always left-to-right, scrollable (max ~8 lines visible).
- Primary `crash_report_copy` (56 high, copy icon 20, margin 18) · outline `crash_report_continue` (52 high, margin 10). After copying: snackbar (ok border, check icon) `crash_report_copied`.

## 4. Profile — daily reward and account section
Add to the Profile screen (below the header/stats, above the tabs), with the existing bottom bar:
- **Daily reward card** (gradient 135° `#2A1F08` → `#121A2B`, 1dp `#8A6A22` border, radius 16, padding 14): gift tile 44 (gold) · column [`profile_daily_reward` 16sp/800; `profile_day_streak` 12sp muted] · **Claim** (`ac_claim`, 44 high, gold gradient, `#1B1405` text, padding 0/18) or **Claimed** (`profile_daily_claimed`, check icon, okText, no fill).
- **Streak bar** (margin top 14): 7 segments (flex, 8 high, radius 4, gap 6): done = gold, today = gold + 3dp gold@35% halo, upcoming = muted brown `#3A3220`, day 7 (bonus) = transparent with a 1.5dp gold outline.
- Section `settings_account_actions`: one card of rows (min 64, icon tile 40, title 15sp/800, chevron AutoMirrored): **AC wallet** (`profile_wallet_title`, coin tile, balance goldText 800 at the end) · **My orders** (`profile_orders`, receipt tile, red count badge) · **View as others** (`profile_view_as_others`, sub-line `profile_hidden_from_others`).
- Outlined danger button **`profile_logout`** (logout icon 20, errorText, border error@45%, margin 20).

## 5. Member profile — safety and moderation
Same cover, header (avatar 80, status dot, name, `@username · status`) as in `SPEC_PROFILE_WALLET.md` section 2, plus these states:
- **Friend request received:** card (surface, 1dp border, radius 16, padding 12×14): person tile 40 + `profile_friend_request` 15sp/800; buttons row (gap 10, 44 high): **Accept** (`profile_accept`, primary) · **Reject** (`profile_reject`, outlined). The Message button is dimmed until accepted.
- **Friends:** green **Friends** button (`profile_friends_state`) + Message; a "Remove friend" row in Safety opens the dialog (`profile_unfriend` title, `profile_unfriend_confirm` body, Cancel / **Remove friend** red).
- **Safety section** (`profile_safety`; one card of rows, min 64, tile 40): **Mute this user** (`chat_mute_user`) with a gold **Legendary** chip (`mute_member_locked`, crown icon 12) when the plan does not allow it — tapping shows the snackbar `mute_member_needs_plan` and opens Plans; when muted the row becomes **Unmute** (`chat_unmute_user`, ok tile) with the snackbar `profile_mute_done`. **Block user** (`block_user`, red text), **Report** (`chat_report`), and **Remove friend** (`profile_unfriend`, red) for friends. Results: `profile_action_done` / `profile_action_failed`.
- **Blocked:** warning message at the top (warning@14% bg, 1dp warning@40%, block icon 20, `profile_blocked_state`); Add friend and Message are disabled.
- **Moderation section** (staff only, `profile_moderation`): **Ban user** (`profile_ban_user`) and **Delete message** (`profile_delete_message`), red icon tiles; confirm destructive actions.

## 6. Admin content editor
Top bar title `admin_content`; when the item is published a status chip `admin_publish_content` (ok) at the end. Fields (label 12sp/700, field 48 high radius 12): Title (`creator_field_title`, required), type chips (Addons / Worlds), Description (`admin_content_description`, multiline 92), Required plan chips (Free / Epic / Legendary, `admin_required_plan`), Cover and File upload zones (dashed 2dp, radius 16, min height 96; the file is required).
- **Toggle card** (one card, rows min 56, switch 52×30): **Featured** (`admin_featured_content`, sub-line `home_featured_plain`), **Exclusive** (`admin_exclusive_content`, sub-line `home_exclusives_plain`), **Published** (`admin_publish_content`).
- **Validation:** empty title → error border + alert line `admin_content_title_required`; missing file → the file zone turns error (dashed error border, alert icon, `admin_content_file_required`). Buttons: **Delete** (`admin_delete_content_label`, outlined, errorText, confirm first) · **Save** (`admin_save`, primary).
- **Not found:** empty state (88 circle with a cube icon, `admin_content_not_found` 18sp/800, outline button).

## 7. Language and theme pickers (Settings)
Opened from the Settings rows `set_language` and `set_theme` (the row shows the current value at the end). Bottom sheet (barSurface, radius 24 top, padding 8/16/20, grab handle).
- **Language** (title `set_language` 18sp/800): 8 rows (min 56, radius 14, padding 6, gap 14): flag circle 40 (the language room icons `ic_room_lang_*`) · native name 16sp/800 + English name 12sp muted · radio 22 (selected = 6dp blue ring, row tinted blue@12%). Order: English, العربية, Français, Türkçe, Español, Русский, Português, 中文. Names are not translated. Selecting applies immediately (recreate the activity; Arabic switches to RTL) and is persisted.
- **Theme** (title `set_theme`): two preview cards side by side (gap 12, radius 16, 1dp border, padding 12; selected = 2dp blue): a 72-high swatch (dark gradient `#0A0F1C` → `#1A2438` / light `#F4F7FC` → `#FFFFFF` with a border) + label `set_theme_dark` / `set_theme_light`.

## 8. Light theme, Arabic (RTL), accessibility
- Light: use the light tokens; the log box stays dark; the daily reward card keeps its gold gradient.
- RTL: start/end everywhere; chevrons AutoMirrored; the check badge on the mail circle moves to the start corner; the code/log text stays left-to-right.
- Accessibility: targets ≥ 44dp; the status messages (resent, copied, mute done) use polite live regions; the check/streak segments have descriptions ("day 5 of 7, today"); destructive buttons are announced as such.
