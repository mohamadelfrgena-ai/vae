# Languages — New in this build

The app has **8 languages**: English (default), العربية `ar` (RTL), Français `fr`, Türkçe `tr`, Español `es`, Русский `ru`, Português `pt`, 中文 `zh`.

## Strings
This package needs **no new strings**: every text on these screens already exists in the app in all 8 languages. The language picker lists the languages by their own names (English, العربية, Français, Türkçe, Español, Русский, Português, 中文), which are not translated.

## Layout rules for all languages
- Only Arabic is RTL: use start/end everywhere, never left/right. Allow **30–40% longer text** (fr, es, pt, ru) — buttons grow, labels wrap, no fixed widths; Chinese is shorter.
- No uppercase transform or letter spacing for ar and zh. Turkish uppercase needs the Turkish locale (i → İ).
- **Fonts:** the pixel font covers Latin with fr/es/pt/tr accents but **not Cyrillic, Chinese or Arabic**: use Nunito ExtraBold for ru, the system CJK font (bold) for zh, Tajawal ExtraBold for ar. Keep the pixel font for Latin text and the brand name.
- Dates, numbers, plurals: locale formatters and plural resources only.
- Test: Dark/Light × en · ar · ru · zh, font scale 100% and 130%.
