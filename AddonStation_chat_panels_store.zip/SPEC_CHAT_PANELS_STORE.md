# AddonStation — UI Spec: Chat room (emoji & stickers panels) + Store

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified. This redesign is based on three screenshots of the **current build** (`reference/before/`): the chat room with the emoji panel, the stickers panel, and the Store with a network error. It **replaces** the chat room header/message styling and the emoji/stickers panels in `SPEC_CHAT_DETAILS_STATES.md`, and the Store screen of the early specs. Do not change chat or store logic (roles, hiding, pinning, sticker packs, sorting, search, pagination): only layout, icons and colors.
`reference/chat_store_redesign_preview.html` is a clickable before/after reference (screen selector Chat/Store, state buttons incl. *Before*, Light/Dark, English/Arabic). Open it in a browser. Tokens (dark/light), fonts, shapes, chips, status chips and sheets: same as `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0. The bottom bar is in `SPEC_WALLET_BOTTOMBAR.md`.

## 1. What was wrong in the current screens → what changes
| Current | Redesign |
|---|---|
| Emoji panel is ~45% of the screen and **covers the composer**: the user cannot see what they type | Panel is docked **under** the composer (height 300), composer stays visible |
| Selected tabs/chips use **green** outline; the rest of the app is blue | Selected = blue fill, white text (same as every other tab/chip) |
| Emoji/Stickers tabs are two tiny chips | Full-width segmented control (40 high) |
| Sticker pack chips (All, meme, Memes…) sit at the bottom and cover the last grid row | Pack chips move **above** the grid, horizontally scrollable |
| "This message was hidden" is large italic text | Small muted pill with an eye-off icon |
| Date separator = two long thin lines | Centered chip |
| Role chip "Manager ✦" in green outline | Role chip with a shield icon, tinted fill |
| Store: two tiny type chips + two rows of small green chips; the error is a lone red text + grey button | Full-width Addons/Worlds segmented control, one scrollable sort row, a proper error state with icon and primary Retry |

## 2. Chat room
Column: **header → messages (scroll, newest at bottom) → composer → panel (optional)**. When the panel opens, the message list shrinks (resize), it is never covered. No bottom navigation bar inside a room.
### 2.1 Header (top bar)
barSurface, 1dp bottom border, padding 10, gap 8. Back (44 circle, surface) · room avatar 40 circle (the room icon; language rooms use their flag) with a 2dp border · column [room name 16sp/800; subtitle 12sp muted — `chat_members_online_none` or "[N] online" in okText] weight 1 · actions, each a 44 circle (surface): **Pinned** (pin icon in gold, shown only when something is pinned, with a count badge: min 16 high, gold fill, `#1B1405` 10sp/800, 2dp border in barSurface, at the top-end) · **Members** (users icon) · **Room settings** (gear, `cd_room_settings`).
### 2.2 Messages
- **Date chip** (`[Date]` formatted by locale): centered, surfaceHigh, textMuted 12sp/800, padding 5×14, radius 14, margin 4/0.
- **Own message** (aligned to the end): bubble = primary gradient (135° `#2E7BEF` → `#4C9AFF`), white 15sp/700, radius 16/16/4/16 (mirrored in RTL), padding 10×12×8. Time (11sp/700, white@75%) + double-check icon 14 (`cd_message_delivered`) sit inline at the bubble's end, baseline-aligned.
- **Own image message:** image 230×150, radius 16/16/4/16, 1dp border; time chip overlay at the bottom-end (black@55%, white 11sp/700, radius 10, padding 2×8, check icon 14). Tap → image viewer.
- **Others' message:** avatar 36 circle (default avatar fallback) · column [name row: name 12sp/800 in the role color + role chip · bubble]. Bubble: surface, 1dp border, radius 16/16/16/4, 14sp, max width 250.
- **Role chip** (11sp/800, radius 9, padding 3×10, 12dp icon + label): Manager/Moderator `role_moderator_plain` = ok tint + shield icon; Admin = gold fill; Creator = blue; Epic = purple; Legendary = gold.
- **Hidden message:** inline pill (surfaceHigh, textMuted 12sp/700, padding 6×12, radius 12, gap 6) with an eye-off icon 16 + `chat_hidden_message_plain`; aligned to the sender's side. Staff get a "Show" action (see `SPEC_CHAT_DETAILS_STATES.md` 1).
### 2.3 Composer
barSurface, 1dp top border, padding 8/8/14, gap 8: **add photo** (44 circle, surface) · **emoji toggle** (44 circle; closed = smile icon on surface; **panel open = keyboard icon, blue@18% fill, 1dp blue@45% border**; content descriptions `cd_emoji_toggle_open` / `cd_emoji_toggle_keyboard`) · field (44 high pill, radius 22, surface, 1dp border, hint `chat_hint`) weight 1 · **send** (44 circle, primary gradient, disabled = surfaceHigh).
Toggle behavior: tapping the toggle swaps between the system keyboard and the panel without the layout jumping (keep the same height); the system Back button closes the panel first; the panel closes after sending.
### 2.4 Emoji panel (height 300)
Docked below the composer: barSurface, 1dp top border, top radius 20, padding 10/12/8.
- **Segmented tabs** (surface container, 1dp border, radius 14, padding 4; segments 40 high, radius 10, 13sp/800): **`chat_emoji`** (selected) | **`chat_stickers_tab`**. Selected = blue fill, white text.
- Label `chat_recent` (13sp/800 goldText) + one row of recently used emoji (8 columns, 1dp divider under it).
- **Grid:** 8 columns, row height 38, emoji 24sp, vertical scroll (keep the app's current emoji set).
- **Category strip** pinned at the bottom (border-top, padding 6/12/10): 5 buttons 44×36 radius 12 — Smileys, Gestures, Hearts, Objects, Symbols (`chat_emoji_cat_*` as content descriptions); selected = blue@18% fill, blueLink icon; tapping scrolls to that category.
### 2.5 Stickers panel (height 340)
Same container and tabs (Stickers selected). Below the tabs:
- **Pack chips** (horizontal scroll, gap 8, margin bottom 8): 36 high, radius 18, padding 0×14, 13sp/800; `common_all` first, then each pack name. Selected = blue fill, white; others surface + 1dp border.
- **Section header:** pack name uppercase (12sp/800 goldText, letter spacing .6sp) + count chip (surfaceHigh, textMuted, radius 10, padding 1×8, e.g. "47"; description `chat_stickers_count`) + a 1dp divider filling the rest.
- **Grid:** 4 columns, gap 8, square tiles radius 14, 1dp border, image/GIF cover-fit. Tap selects the sticker and shows the "sticker ready" card (see `SPEC_CHAT_DETAILS_STATES.md` 2). Load lazily; animate GIFs only while visible; pause them with reduced-motion. Empty pack/loading/error: use the general states.
### 2.6 Hidden/own-message details to keep
Timestamps, delivery marks, pinned messages and the member list keep their current behavior; the members list grouping is in `SPEC_PROFILE_WALLET.md` section 7.

## 3. Store
Bottom bar visible (Store tab selected). Column: scrollable content + bar.
1. **Header row** (padding 14/16/10, gap 10): app icon 40 radius 12 with a 2dp gold border · title `nav_store` (pixel 18sp; Arabic: Tajawal ExtraBold, no letter spacing) weight 1 · **AC pill** (36 high, radius 18, surfaceHigh, coin 24 + balance 800 goldText; shows "—" when the balance is unknown or offline) → AC wallet.
2. Subtitle `store_title` 13sp textMuted (padding 0/16/12).
3. **Search** `store_search_hint` (48 high, radius 14, surface, 1dp border, search icon 20, margin 0/16).
4. **Type control:** segmented container (surface, 1dp border, radius 14, padding 4) with **`store_tab_addons`** | **`store_tab_worlds`**, segments 40 high, radius 10, 14sp/800, selected = blue fill. Margin 12/16/8.
5. **Sort chips** (one horizontal scrollable row, padding 4/16/12, gap 8, 40 high, radius 20, 13sp/800): `store_sort_newest` (default) · `store_sort_downloads` · `store_sort_views` · `store_sort_rating`; selected = blue fill/white, others surface + 1dp border.
6. **Results grid:** 2 columns, gap 12, padding 0/16/24; item cards as in Addon details (thumbnail 100, tier badge, title, `item_by`); infinite scroll with a footer skeleton.
7. **States** (filters and search stay visible and usable in all of them):
   - **Loading:** 4–6 skeleton cards (thumbnail block 100 + two text bars), shimmer 1.4s (static when reduced motion).
   - **Network error:** centered, padding 36/24: 88 circle (surfaceHigh) with a Wi-Fi-off icon 40 · `msg_network_error` 18sp/800 · **Retry** (`common_retry`, 44 high, radius 12, primary gradient, padding 0×28). If cached results exist, keep showing them and show the error as a snackbar instead.
   - **No results:** search-off icon in the circle · `store_empty` 18sp/800 · `store_empty_hint` 14sp muted.

## 4. Light theme, Arabic (RTL), accessibility
- Light: use the light tokens; the image-message time chip and the viewer overlays stay dark.
- RTL: start/end everywhere; own messages align to the start side; bubble corner radii mirror; panel grids and chip rows flow from the right; the category strip order mirrors; arrows AutoMirrored. Arabic text uses Tajawal (no letter spacing); the room's Latin name stays as is.
- Accessibility: targets ≥ 44dp; icon-only buttons have content descriptions; emoji cells announce their name; the segmented controls use the tab role; the sticker grid items have a label (pack name + index); errors use a polite live region.

## 5. Strings
Existing keys used: `chat_emoji`, `chat_stickers_tab`, `chat_recent`, `chat_members_online_none`, `chat_hint`, `common_all`, `role_moderator` (use `role_moderator_plain`), `chat_hidden_message` (use `chat_hidden_message_plain`), `nav_store`, `store_title`, `store_search_hint`, `store_tab_addons`, `store_tab_worlds`, `store_sort_newest`, `store_sort_downloads`, `store_sort_views`, `store_sort_rating`, `store_empty`, `store_empty_hint`, `msg_network_error`, `common_retry`, `item_by`.
New / emoji-free keys are in `res/values/strings_chat_store.xml` and `res/values-ar/strings_chat_store.xml` (merge them): `chat_hidden_message_plain`, `role_moderator_plain`, `cd_room_settings`, `cd_emoji_toggle_open`, `cd_emoji_toggle_keyboard`, `cd_message_delivered`, `chat_emoji_cat_*` (5), `chat_stickers_count`.

## 6. Assets
```
assets/images/ic_default_profile.jpg  default avatar
assets/images/coin_ac.png             AC coin (AC pill)
assets/images/app_icon.png            Store header icon
assets/images/item_placeholder.jpg    fallback thumbnail
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/chat_store_redesign_preview.html   clickable before/after
reference/before/*.jpg                       the three current screenshots
```
Copy images to `res/drawable-nodpi/`, fonts to `res/font/`, merge the strings files. Icons: Material (ArrowBack, PushPin, Group, Settings, Image, EmojiEmotions, Keyboard, Send, DoneAll, Shield, VisibilityOff, FrontHand, Favorite, Lightbulb, Category/Tag, Search, WifiOff, SearchOff).
