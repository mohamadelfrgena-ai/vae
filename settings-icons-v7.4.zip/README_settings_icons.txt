AddonStation v7.4 - Settings icons (separate file)

src/screens.cpp  -> replace the project's file with this one.
It already contains ALL earlier v7.4 changes (focus glow, buttons, gem markers, mascot) + the new settings icons.

What changed in the settings icons (lineIconTile + lineIcon):
- colour-gradient glass tile, soft glow under it, gloss on top, accent rim
- white line icon with a small shadow
- focused row: the tile glows/pulses and the icon moves
    language = spins | appearance = spins | account = floats
    auto-launch = sways | about = sways | sign out = slides
- the settings detail panel icon is always animated
- the sign-out confirmation dialog icon stays still

No new images needed (icons are still drawn in code), so no ui.pak step.
