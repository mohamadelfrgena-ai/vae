# AddonStation — UI Spec: Chat details, chat warnings, dialogs, reset password, general states, my lists

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified for every screen.
`reference/more_screens_preview.html` is a clickable visual reference of every screen and state below (screen selector, Light/Dark, English/Arabic, state buttons). Open it in a browser and follow it for exact look; this spec gives numbers and rules.
All texts already exist in `strings.xml` (key table at the end). Emoji in existing strings are replaced by vector icons: use the emoji-free `*_plain` keys from `res/values*/strings_chat_states.xml`. **Do not change chat logic** (roles, mute/ban, slow mode, 3-minute delete window, upload limits, moderation): only layout, icons and colors.
Tokens (dark/light), fonts and shapes are the same as in `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0 — read it first. Extra tokens used here: **warning** `#F0A04B` (light `#B25E00`), **error** `#FF6B78` (text `#FF8791`, light `#B3262E`), **ok** `#3FBF6A` (text `#7FD99A`, light `#1E7A44`), scrim `#000`@62%.

| # | Screen | Opens from |
|---|---|---|
| 1 | Message menu | long-press a message in a chat room |
| 2 | Emoji & stickers panel | smile button in the composer |
| 3 | Pinned messages · Members | pin icon / members icon in the room header |
| 4 | Image viewer | tap a photo in a message |
| 5 | Dialogs: Report · Block · Delete account | menu actions / Settings |
| 6 | Chat warnings (composer states) | bottom of the room |
| 7 | Reset password | "Forgot password?" on Sign in |
| 8 | General states: loading · offline · error · empty | any list/screen |
| 9 | My lists: Favorites · Downloads · Content | Profile shortcuts |

## 0. Shared chat components
- **Room header** (top bar): barSurface, 1dp bottom border, padding 10 — back (44 circle, surface) · room avatar 40 circle · column [room name 16sp/800; "[N] online" 12sp okText] weight 1 · members button (44 circle, surface). Admin pin icon button next to it when something is pinned.
- **Message**: row gap 10, padding 8×14. Avatar 36 circle · column [sender name 12sp/800 blueLink · bubble]. Bubble: surface, 1dp border, radius 16/16/16/4 (mirrored in RTL), padding 10×12, 14sp, max width 250. **Own message:** right-aligned (start-aligned in RTL), blue gradient, white text, radius 16/16/4/16, no name/avatar.
- **Composer**: barSurface, 1dp top border, padding 8/8/14, gap 8 — add-photo button (44 circle, surface) · emoji/stickers button (44 circle, surface) · text field (44 high, radius 22, surface, 1dp border, padding 0/16, hint `chat_hint`) weight 1 · **Send** button (44 circle, primary gradient, white send icon 20; disabled = surfaceHigh).
- **Bottom sheet:** barSurface, radius 24/24/0/0, padding 8/16/22, 1dp top border, shadow; grab handle 40×4 radius 2 in border color, margin 4/12.
- **Dim scrim:** `#000`@62% over the room; the pressed message stays above the scrim.

## 1. Message menu (long-press)
Bottom sheet over the dimmed room, the target message lifted above the scrim.
1. **Reaction row** (margin bottom 8, space-between): five quick reactions in 46×46 circles (surfaceHigh, emoji 22sp) — 👍 ❤️ 😂 😮 😢 — and a **+** circle (`chat_add_reaction`, opens the emoji panel). Tap toggles the user's reaction.
2. **Action rows** (min height 48, gap 14): icon 22dp (textMuted) + label 15sp/700; danger rows use errorText for icon and label.
   | Variant | Rows (in order) |
   |---|---|
   | **Others' message** | Reply (`chat_reply`) · Copy text (`chat_copy_text`) · Pin (`chat_pin`) · View profile (`chat_view_profile`) · Report (`chat_report`) · Mute this user (`chat_mute_user`) · **Block user** (`block_user`, danger) |
   | **My message** | Reply · Copy text · Pin · **Delete my message** (`chat_delete_mine`, danger) with a second line `chat_delete_left` ("[N] min left to delete", 12sp muted). After 3 minutes the row is disabled and tapping shows `chat_delete_expired`. |
   | **Staff (admin/moderator)** | Reply · Copy text · Unpin/Pin (`chat_unpin`) · Hide message (`chat_hide_message`) · View profile · Report · Mute this user · Block user · **Delete message (moderation)** (`chat_delete_staff_plain`, danger) with the note `chat_delete_staff_note` (12sp muted) |
   Icons (Material): Reply, ContentCopy, PushPin, VisibilityOff, Person, Flag, VolumeOff, Block, Delete.
3. Results use snackbars: `chat_delete_done`, `chat_delete_failed`, `block_done`. Hidden messages show the placeholder `chat_hidden_message_plain` with a "Show" action (`chat_show`) for staff.
4. Rules: no Report/Mute/Block on your own message; Mute/Hide/moderation delete only for staff; read-only rooms hide Reply for non-staff.

## 2. Emoji & stickers panel
Replaces the keyboard under the composer (height ≈ 300).
- Segmented tabs (container surface, 1dp border, radius 14, padding 4): **`chat_emoji`** | **`chat_stickers_tab`** (segment height 40, radius 10, selected = blue fill, white 13sp/800).
- Section label `chat_recent` (13sp/800 goldText, margin 12/2/8).
- **Emoji grid:** 7 columns, cell 44 high, emoji 26sp.
- **Stickers grid:** 4 columns, gap 10, square tiles radius 16, bg = surfaceHigh tinted with the pack color; tap selects the sticker.
- **Sticker ready state:** the panel closes and a card appears above the composer (barSurface, 1dp top border, padding 12/12/16): sticker preview 72×72 radius 16 · text `chat_sticker_ready` 14sp/800 + button **Remove sticker** (`chat_remove_sticker`, 44 high, radius 12, 1dp border, errorText, ✕ icon 16) · below it the composer row with the Send button.

## 3. Pinned messages · Members
Two full screens with a standard top bar (back + pixel title).
- **Pinned** (`chat_pinned_plain`): one card (surface, 1dp border, radius 16) with rows (padding 14, gap 12, 1dp dividers): pin icon tile 40 (gold) · column [sender 15sp/800 + time 11sp muted at the end; message 12sp muted, 2 lines] · **Unpin** text button (`chat_unpin`, 44 high, blueLink 13sp/800; staff only). Tap a row → scroll the room to that message. **Empty:** centered 88 circle (surfaceHigh) with a pin-off icon 40 + `chat_no_pinned`.
- **Members** (`chat_members`): one card; row min height 64, padding 10×14, gap 12: avatar 44 with a status dot (14dp, 3dp border in surface; green when online, grey `#6B7A94` offline) · name 15sp/800 weight 1 · **role chip** (11sp/800, radius 9, padding 3×10): Admin = gold fill/dark text (`grp_admin`), Creator = blue/white (`role_creator_plain`), Epic = purple/white, Legendary = gold; members without a role have no chip. Order: online first, then by role. Tap → profile. **Nobody online:** `chat_members_online_none` as a centered empty state (users icon).

## 4. Image viewer
Full screen, black bg, edge-to-edge. Top overlay (gradient `#000`@70% → transparent, padding 12, gap 10): close button (44 circle, `#0A0F1C`@60%, white ✕) · sender avatar 36 + name 15sp/800 + time 12sp · download button · more button. The picture is centered and fits the screen (pinch-to-zoom, double-tap, swipe down to close). Bottom overlay (gradient transparent → `#000`@85%, padding 16/16/28): caption 14sp, line height 1.5, then the reaction row (left-aligned, gap 8).

## 5. Dialogs
Centered dialog over the dimmed room: margin 24, radius 24, padding 20, barSurface, 1dp border, shadow 0 20dp 50dp black@50%. Title 18sp/800, body 14sp/1.55 muted. Button row (margin top 18, gap 10): two equal buttons, 44 high, radius 12, 14sp/800 — **Cancel** (`common_cancel`, transparent, 1dp border, textMuted) and the confirm button.
- **Report** (`chat_report` title): label `chat_report_reason`, then radio rows (min 56, radius 14, surface, 1dp border; selected: 2dp blue border + blue radio): `chat_reason_inappropriate`, `chat_reason_insult`, `chat_reason_spam`, `chat_reason_other`. Confirm = **Send** (`chat_send`, primary gradient). Success dialog: 88 circle (ok@16%, check icon 44) + `chat_report_sent_plain` + **OK** (`common_ok`).
- **Block this user?** (`block_confirm_title` + `block_confirm_body`): top icon tile 56 circle (error@16%, Block icon 30). Confirm = **Block user** (`block_user`, fill error, white text). Success snackbar `block_done` with Undo (`block_user_undo`); failure `block_failed`.
- **Delete account** (`set_delete_account` + `set_delete_note`): same layout as Block (Delete icon). Confirm = **Delete** (`common_delete`, fill error). Keep the existing re-authentication step.

## 6. Chat warnings (composer states)
The composer area changes by state; the room above never moves. Bars use barSurface, 1dp top border, padding 16/16/26, icon 22 + text 14sp/800, line height 1.4.
| State | UI |
|---|---|
| **Muted** | Bar, warning color, VolumeOff icon, `chat_muted_until` ("You are muted until [time]"); composer hidden |
| **Banned** | Bar, error color, Block icon, `chat_banned`; composer hidden |
| **Read-only room** (non-staff) | Bar, textMuted, Lock icon, `chat_read_only` |
| **Slow mode** | Toast chip above the composer (margin 0/16/8, surfaceHigh, 1dp border, radius 14, padding 10×14, warning color 13sp/800, Schedule icon 18): `chat_slowmode` ("Wait 12s"). The Send button becomes a countdown text ("12s", warning color) until it ends. Under the composer, from 450 characters: `chat_limit_500` + "487/500" (12sp muted, padding 0/20/14) |
| **Links / personal data** | Error toast chip (same as slow mode, error color, Alert icon): `chat_no_links`; the message is not sent |
| **Attachment ready** | Card above the composer (padding 12/12/16): thumbnail 64×64 radius 12 · column [`chat_attachment_ready` 14sp/800; `chat_image_formats` · `chat_image_max` 12sp muted] · remove button (36 circle). While uploading: `chat_uploading` with a progress bar; on failure `chat_upload_failed` + `chat_tap_to_retry`; a failed message shows `chat_send_failed` with a retry tap. Media limits: `chat_media_admin_only`, `chat_media_max` as snackbars |
| **Guest** | Gate bar: Lock icon + `chat_login_required` (14sp muted, weight 1) + **Sign in** button (`common_sign_in`, 44 high, radius 12, primary gradient) |

## 7. Reset password
Top bar title `auth_recovery_title`. Content padding 16.
- **Request:** key icon tile 72 circle (blue tint) centered · text `auth_recovery_text` 13sp, line height 1.6, centered, muted · label `auth_email` (12sp muted) + field (48 high, radius 12, surface, 1dp border) · button `auth_send_recovery` (56 high, radius 16, primary gradient, margin top 20). Sending state: `msg_sending`.
- **Error:** field border error color and a line below (Alert icon 16 + `msg_enter_email_first` / `msg_invalid_email` 12sp/800 errorText).
- **Sent:** 104 circle (ok@14%, mail icon 52) · `msg_check_email_plain` 18sp/800 centered · the email address (muted) · outline button `auth_sign_in`.
- The next step (after tapping the e-mail link) uses the **Create new password** screen: same fields and style as Create account — `auth_reset_title_plain`, `auth_new_password`, `auth_confirm_password`, button `auth_save_password`, validation `msg_password_too_short` / `msg_passwords_no_match`, success `msg_password_saved_plain`.

## 8. General states
Reusable for any list screen (header/search stays visible).
- **Loading:** label `common_loading` (12sp muted) + 5 skeleton rows (surface cards, radius 14, padding 10: 64×64 block radius 14, two text bars 14 and 12 high at 70% / 45% width, 44×44 block radius 12). Shimmer: linear gradient surfaceHigh → surface → surfaceHigh, 1.4s linear loop; respect reduced-motion (static).
- **Offline:** 88 circle (surfaceHigh) with WifiOff icon 40, `msg_network_error` 18sp/800, button **Retry** (`common_retry`, 44 high, radius 12, primary gradient, padding 18).
- **Server/generic error:** Alert icon (errorText) in the circle, `msg_generic_error` 18sp/800, `chat_tap_to_retry` 14sp muted, Retry button. (`msg_server_error` uses the same layout.)
- **No results:** SearchOff icon, `store_empty` 18sp/800, `store_empty_hint` 14sp muted.
- **No favorites:** star icon (goldText), `profile_favorites_empty_plain` 14sp muted, centered, padding 24.

## 9. My lists
Top bar title = the selected tab. Under it, a 3-segment control (Favorites · Downloads · Content): `profile_tab_favorites`, `profile_stats_downloads`, `profile_tab_content`.
- **Favorites:** grid, 2 columns, gap 12: item card as in Addon details (thumbnail 100, tier badge top-start, title, `item_by`) with a **star button** (30 circle, `#0A0F1C`@60%, filled gold star) at the thumbnail's bottom-end; tap removes from favorites (snackbar `item_removed_fav`). Empty state: section 8.
- **Downloads:** one card with rows (padding 12×14, gap 12, 1dp dividers): thumb 64×64 radius 12 · column [title 15sp/800; date 12sp muted] · link `item_view_plain` (blueLink 13sp/800, 44 high) → Addon details.
- **Content** (creators/admin): empty state `profile_my_content_empty_plain` (cube icon, 14sp muted). When the user has content, list it like Downloads with a status chip.

## 10. Light theme, Arabic (RTL), accessibility
- **Light:** use the light tokens; the image viewer, hero overlays and scrim stay dark.
- **RTL:** `android:supportsRtl="true"`, start/end everywhere. Message alignment mirrors (own messages align to the start side), bubble corner radii mirror, reaction row and sheets mirror, status dots sit at the end corner. Use AutoMirrored icons for back, reply and send (they must flip in RTL); do not mirror pin, flag, lock, mail, star, download. Arabic uses Tajawal (no letter spacing); allow ~30% longer text.
- **Numbers:** follow the app-wide digit convention (see `SPEC_HOME_V2.md`); counters like "487/500" and "[N] min" use `NumberFormat`.
- **Accessibility:** targets ≥ 44dp; icon-only buttons have content descriptions; destructive actions are announced as such; toasts/snackbars use polite live regions; the sheet's first row gets initial focus.

## 11. Assets
```
assets/images/ic_default_profile.jpg  default avatar
assets/images/item_placeholder.jpg    fallback thumbnail
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/more_screens_preview.html   clickable visual reference
```
Copy images to `res/drawable-nodpi/`, fonts to `res/font/`, merge the two strings files into the project. Icons are Material Icons (ArrowBack, Reply, ContentCopy, PushPin, VisibilityOff, Person, Flag, VolumeOff, Block, Delete, Add, EmojiEmotions, Send, Image, Close, Check, Lock, Group, Mail, VpnKey, WifiOff, ErrorOutline, SearchOff, Star, Download, MoreVert, Schedule, ViewInAr).

## 12. String keys used
| Key | English | Arabic |
|---|---|---|
| `chat_add_reaction` | Add reaction | إضافة تفاعل |
| `chat_reply` | Reply | رد |
| `chat_copy_text` | Copy text | نسخ النص |
| `chat_pin` | Pin | تثبيت |
| `chat_unpin` | Unpin | إلغاء التثبيت |
| `chat_hide_message` | Hide message | إخفاء الرسالة |
| `chat_view_profile` | View profile | عرض الملف الشخصي |
| `chat_report` | Report | إبلاغ |
| `chat_mute_user` | Mute this user | كتم هذا المستخدم |
| `block_user` | Block user | حظر المستخدم |
| `chat_delete_mine` | Delete my message | حذف رسالتي |
| `chat_delete_left` | %1$d min left to delete | متبقٍ %1$d دقيقة للحذف |
| `chat_delete_staff_plain` | Delete message (moderation) | حذف الرسالة (إشراف) |
| `chat_delete_staff_note` | Any message, however old — the 3-minute limit applies to the author only. | أي رسالة مهما كان عمرها — مدة الثلاث دقائق على صاحبها فقط. |
| `chat_delete_expired` | Delete window ended: messages can only be deleted within 3 minutes of sending. | انتهت مدة الحذف: يمكن حذف الرسالة خلال ٣ دقائق فقط من إرسالها. |
| `chat_delete_done` | Message deleted. | تم حذف الرسالة. |
| `chat_delete_failed` | The message could not be deleted. | تعذّر حذف الرسالة. |
| `chat_emoji` | Emoji | إيموجي |
| `chat_stickers` | Stickers | الملصقات |
| `chat_stickers_tab` | Stickers | ملصقات |
| `chat_recent` | Recent | الأحدث |
| `chat_sticker_ready` | Add a message with the sticker if you like, then send | اكتب نصاً مع الملصق إن أردت، ثم اضغط إرسال |
| `chat_remove_sticker` | Remove sticker | إلغاء الملصق |
| `chat_pinned_plain` | Pinned messages | الرسائل المثبتة |
| `chat_no_pinned` | No pinned messages | لا توجد رسائل مثبتة |
| `chat_members` | Members | الأعضاء |
| `chat_members_online_none` | Nobody is online right now | لا أحد متصل الآن |
| `chat_report_reason` | Reason | السبب |
| `chat_reason_inappropriate` | Inappropriate content | محتوى غير لائق |
| `chat_reason_insult` | Insult | إهانة |
| `chat_reason_spam` | Spam | إزعاج |
| `chat_reason_other` | Other | أخرى |
| `chat_report_sent_plain` | Report sent | تم إرسال البلاغ |
| `chat_send` | Send | إرسال |
| `block_confirm_title` | Block this user? | حظر هذا المستخدم؟ |
| `block_confirm_body` | You will no longer see %1$s's messages and they will not see yours, and they cannot send you a friend request. You can unblock at any time from their profile. | لن ترى رسائل %1$s ولن يرى رسائلك، ولن يستطيع إرسال طلب صداقة إليك. يمكنك إلغاء الحظر في أي وقت من ملفه الشخصي. |
| `block_done` | User blocked — their messages are now hidden. | تم الحظر — لن تظهر رسائله بعد الآن. |
| `block_failed` | Couldn't block — please try again. | تعذّر الحظر — حاول مرة أخرى. |
| `block_user_undo` | Unblock | إلغاء الحظر |
| `unblock_done` | User unblocked. | تم إلغاء الحظر. |
| `set_delete_account` | Delete account | حذف الحساب |
| `set_delete_note` | Deleting your account removes your profile permanently. This cannot be undone. | حذف حسابك يزيل ملفك الشخصي نهائياً. لا يمكن التراجع عن هذا الإجراء. |
| `common_cancel` | Cancel | إلغاء |
| `common_delete` | Delete | حذف |
| `common_ok` | OK | حسناً |
| `common_retry` | Retry | إعادة المحاولة |
| `common_loading` | Loading... | جارٍ التحميل... |
| `common_save` | Save | حفظ |
| `common_sign_in` | Sign in | تسجيل الدخول |
| `chat_muted_until` | You are muted until %1$s | أنت مكتوم حتى %1$s |
| `chat_banned` | You are banned from the chat. | أنت محظور من الشات. |
| `chat_read_only` | Read-only room — only the admin can post | غرفة للقراءة فقط — الإدارة وحدها تنشر هنا |
| `chat_slowmode` | Wait %1$ss | انتظر %1$s ثانية |
| `chat_limit_500` | Max 500 characters | الحد الأقصى 500 حرف |
| `chat_no_links` | Links and personal data are not allowed | الروابط والبيانات الشخصية غير مسموحة |
| `chat_attachment_ready` | Ready to send — write a caption if you like | جاهز للإرسال — اكتب تعليقاً إن أحببت |
| `chat_image_formats` | Only JPG / PNG / WEBP are allowed | يسمح فقط بـ JPG / PNG / WEBP |
| `chat_image_max` | The maximum image size is 4MB | الحد الأقصى 4MB |
| `chat_login_required` | Chat is for members only — sign in to enter the rooms | الشات للمسجّلين فقط — سجّل الدخول لتفتح الغرف |
| `chat_media_admin_only` | Video clips, audio files and voice recordings can only be sent by the admin. | مقاطع الفيديو والملفات الصوتية والتسجيلات الصوتية يرسلها الأدمن فقط. |
| `chat_media_max` | The maximum media size is 100 MB. | الحد الأقصى للملفات 100 MB. |
| `chat_uploading` | Uploading… | جارٍ الرفع… |
| `chat_upload_failed` | Upload failed | فشل الرفع |
| `chat_send_failed` | Not sent | لم تُرسل |
| `chat_tap_to_retry` | Tap to retry | اضغط لإعادة المحاولة |
| `chat_hint` | Message %1$s | اكتب في %1$s |
| `chat_typing` | %1$s is typing… | %1$s يكتب… |
| `chat_new_messages_plain` | New messages | رسائل جديدة |
| `chat_today` | Today | اليوم |
| `chat_yesterday` | Yesterday | أمس |
| `chat_you` | You | أنت |
| `chat_hidden_message_plain` | This message was hidden | تم إخفاء هذه الرسالة |
| `chat_no_messages_plain` | No messages — be the first to send in this channel! | لا توجد رسائل — كن أول من يرسل في هذه القناة! |
| `chat_audio_label_plain` | Audio | صوت |
| `chat_video_label_plain` | Video | فيديو |
| `chat_play_video` | Play video | تشغيل الفيديو |
| `chat_replying_to` | ↩ Replying to %1$s | ↩ الرد على %1$s |
| `auth_recovery_title` | Reset password | إعادة ضبط كلمة المرور |
| `auth_recovery_text` | Enter your email and we will send you a link to create a new password. | أدخل بريدك الإلكتروني وسنرسل لك رابطاً لإنشاء كلمة مرور جديدة. |
| `auth_email` | Email | البريد الإلكتروني |
| `auth_send_recovery` | Send recovery link | إرسال رابط الاستعادة |
| `auth_sign_in` | Sign in | تسجيل الدخول |
| `msg_enter_email_first` | Enter your email first. | أدخل بريدك الإلكتروني أولا. |
| `msg_check_email_plain` | Check your email and open the link. | تحقق من بريدك الإلكتروني وافتح الرابط. |
| `msg_invalid_email` | Invalid email | بريد إلكتروني غير صالح |
| `msg_sending` | Sending... | إرسال... |
| `msg_network_error` | Network error | خطأ في الشبكة |
| `msg_generic_error` | Something went wrong | حدث خطأ ما |
| `msg_server_error` | Server error | خطأ في الخادم |
| `store_search_hint` | Search the library... | ابحث في المكتبة... |
| `store_empty` | No results | لا توجد نتائج |
| `store_empty_hint` | Try a different search word or browse the categories. | جرّب كلمة بحث مختلفة أو تصفح الأقسام. |
| `profile_favorites_empty_plain` | No favorites yet — tap on any content to save it here | لا توجد مفضلة بعد — اضغط على أي محتوى لحفظه هنا |
| `profile_my_content_empty_plain` | No content yet — create your addons and worlds from the admin panel | لا يوجد محتوى بعد — أنشئ إضافاتك وعوالمك من لوحة الإدارة |
| `profile_tab_favorites` | Favorites | مفضلتي |
| `profile_tab_content` | My content | محتواي |
| `profile_stats_downloads` | Downloads | تحميلاتي |
| `item_view_plain` | View | عرض |
| `item_by` | By %1$s | بواسطة %1$s |
| `item_removed_fav` | Removed from favorites | أُزيل من المفضلة |
| `item_added_fav_plain` | Added to favorites | أُضيف إلى المفضلة |
| `auth_reset_title_plain` | Create new password | إنشاء كلمة مرور جديدة |
| `auth_new_password` | New password | كلمة مرور جديدة |
| `auth_confirm_password` | Confirm password | كرر كلمة المرور |
| `auth_save_password` | Save password | حفظ كلمة المرور |
| `msg_password_saved_plain` | Password saved. Signing you in... | تم حفظ كلمة المرور. تسجيل الدخول... |
| `msg_password_too_short` | Password must be at least 6 characters. | يجب أن تكون كلمة المرور على الأقل 6 أحرف. |
| `msg_passwords_no_match` | Passwords do not match. | كلمات المرور لا تتطابق. |
| `grp_admin` | Admin | الإدارة |
| `role_creator_plain` | Creator | Creator |