# أيقونات الشريط الجانبي — AddonStation PS4

7 أيقونات: الرئيسية، العروض، المتجر، تنزيلاتي، الخطط، الحساب، الإعدادات.
المعاينة: `sidebar-icons-preview.html`. ملفات SVG الجاهزة في `icons/`.

- شبكة 48×48، خط 2.8، أطراف وزوايا مدورة، بدون ألوان فاقعة.
- كل أيقونة: خط + تعبئة خفيفة (20%) بنفس اللون.
- غير مفعّلة: لون `kMU`. مفعّلة: مربع أزرق متدرج 76×76 بزوايا 22، والأيقونة بيضاء 40×40.
- الألوان من `kTX / kMU / ink()` عشان يشتغل الفاتح والداكن.

## نص للوكيل
```
In the PS4 side rail (drawTopNav, screens.cpp) replace the glyph icons with icons/*.svg
(48x48 grid, 2.8 stroke, round caps/joins, light 20% fill). Order: home, offers, store,
downloads, plans, account, and settings at the bottom. Tile 76x76 radius 22; icon 40x40 centered.
Inactive: kMU. Active: blue gradient tile, white icon. If paths can't be drawn, bake each SVG to
PNG at 80x80 (2x) and load like the other rail assets. Keep RTL mirroring.
```
