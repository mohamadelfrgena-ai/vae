# AddonStation — UI Spec: Edit profile (2 tabs)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait, dark theme (use the light/dark token table in `SPEC_HOME_V2.md` for the Light theme; same roles). Design width **390 dp**; sizes are dp/sp. **No bottom navigation bar** on this screen (it is a detail screen).
Placeholders in brackets (`[Display name]`, `[username]`, `[Custom status]`) are data-bound. All texts use **existing string keys** (section 7). Do not rename or remove any existing profile feature: avatar, item, banner, custom status, bio.

This screen replaces the old "Edit profile" screen. Entry points: the "Edit profile" button on My profile.

## 1. Tokens
Colors: bg `#0A0F1C` · surface `#121A2B` · surfaceHigh `#1A2438` · barSurface `#0E1526` · border `#223049` · text `#EAF0FA` · textMuted `#9DB0CF` (labels `#C4D1E8`) · blue `#2E7BEF` / `#4C9AFF` · gold `#F0C25E` (dark text `#1B1405`) · goldBorder `#8A6A22` · epic `#9B6BFF` · green `#3FBF6A` (text `#7FD99A`) · danger text `#FF8791`, danger border `#5A2830`.
Fonts: pixel font `assets/fonts/pixel_regular.ttf` for the screen title and uppercase section labels (title 15sp, label 11sp, letter spacing 1sp; **Latin only** — in Arabic use Tajawal ExtraBold and no letter spacing). Body Nunito (Arabic: Tajawal).
Shapes: cards radius 16–20, fields radius 14, buttons radius 12–16. Min touch target 44dp. Screen horizontal margin 16.

## 2. Structure
Column: **top bar → scrollable content → fixed save bar**.
- **Top bar:** bg barSurface, bottom border 1dp border, padding 10; back button 44×44 circle bg surface (ArrowBack, AutoMirrored); title = `profile_edit_plain` uppercase, pixel 15sp, weight 1.
- **Content:** vertical scroll, bottom padding 16.
- **Save bar:** bg barSurface, top border 1dp border, padding 12/16/20 (+ system inset). One button **Save** (`common_save`): full width, height 56, radius 16, gradient 135° `#2E7BEF` → `#4C9AFF`, white 17sp/800, shadow 0 8dp 22dp blue@40%. Disabled (no changes): bg surfaceHigh, text muted. While saving: spinner + `msg_saving`.

## 3. Live preview card (top of the content, both tabs)
Margin 16/16/0, radius 20, bg surface, 1dp border, clipped.
- **Banner area** height 96: selected banner image (center-crop) or, when none, gradient 135° `#1A2438` → `#121A2B`. Overlay gradient transparent (40%) → surface@90%. Chip at top-start (12/10): `edit_profile_preview` 11sp/800, bg `#0A0F1C`@65%, radius 8, padding 4×10.
- **Identity row** (padding 0/14/14, gap 12, overlaps the banner by 34): avatar 76×76 circle with 4dp border in surface color; status dot 22×22 at bottom-end (green radial gradient `#8CF2AD` → `#2FB35C`, 4dp border in surface). Column: `[Display name]` 18sp/800; `@[username]` 12sp/700 muted + " · " + `profile_online` in `#7FD99A` (or `profile_offline_suffix` when hidden).
- **Custom status box:** margin 0/14/14, bg barSurface, radius 12, padding 10×12, 13sp `#C4D1E8`; hide when empty.
The preview updates immediately when the user picks an avatar/banner/item or types a status.

## 4. Tabs
Segmented control, margin 14/16/0: container bg surface, 1dp border, radius 16, padding 4, gap 4. Two segments, height 44, radius 12, 14sp/800: **`profile_avatar_item`** and **`profile_banner_section`**. Selected: bg `#2E7BEF`, white. Unselected: transparent, `#9DB0CF`. Switching keeps unsaved changes from both tabs. In RTL the segments mirror automatically.

## 5. Tab 1 — Avatar / item
Order (each section label = accent bar 6×14 radius 2 + pixel label, padding 22/20/10):
1. **AVATAR** (accent `#4C9AFF`)
   - Search field: margin 0/16, height 48, radius 14, bg surface, 1dp border, padding 14, search icon 20 + hint `profile_assets_search`.
   - Count: margin 10/20/10, 12sp muted, `profile_assets_count` ("8 of 24 pictures"). Loading: `profile_assets_loading` + skeleton tiles.
   - **Grid:** 4 columns, gap 10, margin 0/16, tiles square (aspect 1:1), radius 18, picture center-crop.
     - *Unlocked:* 1dp border.
     - *Selected:* 3dp ring `#2E7BEF` + check badge (24×24 circle, blue, 2dp border in bg color, white check 14dp) at top-end offset (−6, −6).
     - *Locked:* overlay `#0A0F1C`@62%, lock icon 20dp white + plan chip (10sp/800, radius 7, padding 1×7): **Epic** → bg `#9B6BFF` white text; **Legendary** → bg gold, text `#1B1405`.
     - Tap on a locked tile: do not select; show the upgrade prompt (snackbar/sheet) with `plan_locked_avatars_plain` and an Upgrade action.
     - Accessibility: `cd_avatar_selected` / `cd_avatar_locked`.
   - **Upgrade card** (only for plans with locked items; margin 14/16/0): gradient 135° `#3A2A0B` → `#1B1405`, 1dp goldBorder, radius 16, padding 14, row gap 12: lock icon 22 gold · text `plan_locked_avatars_plain` 12sp `#E8D5A3` weight 1 · button `item_upgrade` (44h, radius 12, gold fill, dark text 13sp/800, padding 16).
2. **ITEM NEXT TO YOUR NAME IN CHAT** (gold) — label text = `plan_item_section`. Row of 3 equal cards (gap 10, margin 6/16/0): height 92, radius 16, centered column (gap 6): icon circle 34 + label 12sp/800.
   - Cards: **None** (`profile_item_none`, icon: circle-slash on surfaceHigh, muted) · **Epic item** (purple star icon on `#9B6BFF`) · **Golden item** (gold star on gold; included with Legendary — see `plan_current_legendary`).
   - *Selected/equipped:* bg `#102244`, 2dp border `#2E7BEF`, tag `profile_item_equipped` (10sp/800 white on blue, radius 7, padding 2×8) at top, −8 offset, end 8.
   - *Locked:* 60% opacity; tap → upgrade prompt.
3. **CUSTOM STATUS** (green `#3FBF6A`, label `profile_custom_status`) — field: label row [name 12sp/700 `#C4D1E8` weight 1, counter `edit_profile_counter` 11sp muted], then box min height 44, radius 14, bg surface, 1dp border, padding 12×14, 14sp, hint `edit_profile_status_hint`. Suggested max **60** characters (use the app's existing limit if different). Single line.
4. **ABOUT ME** (purple `#9B6BFF`, label `profile_about_me`) — multiline field, min height 96 (grows up to 6 lines), same style as above, hint/default `profile_about_default`, counter suggested max **160** (use the existing limit).

## 6. Tab 2 — Banners
1. Section label **BANNERS** (purple), text `profile_banner_section`.
2. **Remove banner** button (`profile_banner_clear`): margin 0/16/12, full width, height 44, radius 12, transparent, 1dp danger border, text danger 13sp/800. Disabled when no banner is selected.
3. **Grid:** 2 columns, gap 10, margin 0/16; tiles aspect **16:7**, radius 14, 1dp border, image center-crop.
   - *Selected:* 3dp ring blue + check badge top-end.
   - *Locked:* overlay + lock icon + plan chip (Epic / Legendary) as for avatars.
   - Banners are loaded from the same picture library (search not needed here).
4. **Upgrade card** with `plan_locked_banners` (same style as above).
5. **Free plan state:** when the user has no banner and every banner is locked, show a card (bg surface, 1dp border, radius 16, padding 14, 13sp `#C4D1E8`): `profile_banner_none_plain` and, below it in 12sp muted, `plan_locked_banner_note_plain`. The preview then shows the gradient placeholder.

## 7. Behavior & states
- **Dirty tracking:** Save enabled only when something changed. Back/close with unsaved changes → dialog: title `edit_profile_discard_title`, text `edit_profile_discard_body`, buttons `edit_profile_discard` (danger) and `edit_profile_keep_editing`.
- **Saving:** disable the screen, show `msg_saving`; success → close the screen and show `edit_profile_saved` snackbar; error → keep the screen and show the existing error string.
- **Plans:** Free = only free avatars/items/no banners. Epic = premium avatars + the plan's items/banners (`plan_current_epic`). Legendary = everything + golden item (`plan_current_legendary`). Locked items always show the chip of the plan that unlocks them.
- **Offline / error:** use the app's existing offline and retry strings; keep the preview and fields editable.
- **RTL (Arabic):** layout mirrors automatically (grid fills from the right, check badge at top-end, tabs and bars mirrored). Use `AutoMirrored` for the back arrow. Section labels in Tajawal ExtraBold, no letter spacing. Counters keep the same digit convention as the rest of the app (see the number-format note in `SPEC_HOME_V2.md`).
- **Light theme:** use the Light token table in `SPEC_HOME_V2.md`; the gradient upgrade card keeps its dark gold gradient in both themes.

### Existing string keys used
| Where | Key | English | Arabic (existing) |
|---|---|---|---|
| Title | `profile_edit_plain` (new, emoji-free) | Edit profile | تعديل الملف |
| Tabs | `profile_avatar_item` / `profile_banner_section` | Avatar / item / Banners | الأفاتار / الأداة / الأغلفة |
| Preview chip | `edit_profile_preview` (new) | Preview | معاينة |
| Search / count / loading | `profile_assets_search` / `profile_assets_count` / `profile_assets_loading` | Search pictures by name… / %1$d of %2$d pictures / Loading pictures… | ابحث في الصور بالاسم… / %1$d من %2$d صورة / جارٍ تحميل الصور… |
| Locked note | `plan_locked_avatars_plain` (new, emoji-free) | Locked avatars unlock with Epic or Legendary. | الأفاتارات المقفلة تفتح مع Epic أو Legendary. |
| Upgrade button | `item_upgrade` | Upgrade | ترقية |
| Item section | `plan_item_section` | Item next to your name in chat | الأداة بجانب الاسم في الشات |
| Item states | `profile_item_none` / `profile_item_equipped` | None / Equipped | لا شيء / مُجهَّز |
| Status | `profile_custom_status` | Custom status | حالة مخصصة |
| Bio | `profile_about_me` / `profile_about_default` | About me / This member has not added a bio yet. | عني / هذا العضو لم يضف نبذة بعد. |
| Banner | `profile_banner_clear` / `plan_locked_banners` | Remove banner / Locked banners need the right plan. | إزالة الغلاف / الأغلفة المقفلة تحتاج الخطة المناسبة. |
| Free banner state | `profile_banner_none_plain`, `plan_locked_banner_note_plain` (new, emoji-free) | No banner yet — pick one from the sections below / All banners are locked — unlock with an Epic or Legendary subscription. | ما في غلاف — اختر واحداً من الفقرات تحت / الأغلفة كلها مقفولة — لا تُفتح إلا باشتراك Epic أو Legendary. |
| Save / saving | `common_save` / `msg_saving` | Save / Saving... | حفظ / حفظ... |
| Online | `profile_online` | Online | عبر الإنترنت |

The `*_plain` and `edit_profile_*` keys are in `res/values/strings_edit_profile.xml` and `res/values-ar/strings_edit_profile.xml` (merge them into the project; do not overwrite existing files). The existing strings that start with an emoji in the app are not used here: icons replace the emoji.

## 8. Assets
```
assets/images/ic_default_profile.jpg     default avatar (fallback)
assets/images/profile_banner_default.jpg fallback banner image
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
```
Avatars, banners and items come from the existing picture library; this spec adds no new pictures. Copy images to `res/drawable-nodpi/`, fonts to `res/font/`. Material icons: ArrowBack, Search, Lock, Check, Star, Block (circle-slash).
