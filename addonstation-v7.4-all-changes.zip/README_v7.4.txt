AddonStation v7.4 - changed files only (same folders as the project)

src/screens.cpp            -> living focus glow + light sweep + gentle lift (focusRing)
                              glossy buttons (button)
                              glowing gem marker for section titles (sectionMark)
                              AC mascot (Allay + coin): wallet title, "moves with your account", all empty states
assets/bg_app_*_gradient.jpg -> the previous soft-gradient backgrounds (optional, not needed)
assets/icon_allay.png      -> mascot for the dark theme (with glow)
assets/icon_allay_light.png-> mascot for the light theme (no glow)

After copying, put the images inside ui.pak (run from the project folder):
python3 tools/pak_set.py assets/ui.pak icon_allay=assets/icon_allay.png icon_allay_light=assets/icon_allay_light.png

If the mascot images are missing from the pak, the app falls back to the old icons (nothing breaks).

Switches at the top of focusRing() in screens.cpp:
  kGlowAccent  true = green glow | false = neutral white/black
  kShine       light sweep on focused buttons
  kLift        focused item grows 0..3 px with the breathing
