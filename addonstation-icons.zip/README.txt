AddonStation app icon — new design: an isometric Minecraft-style block
blue top, blue side with a pixel "A", gold side with a pixel download arrow, on a deep navy background
(same colours as the app: blue #2E7BEF, gold #F0C25E, navy)

phone/   Android: play_store_icon_512.png, adaptive icon layers (background / foreground / monochrome, 432x432),
         mipmap-mdpi..xxxhdpi/ic_launcher.png and ic_launcher_round.png
pc/      app_icon_1024/512/256/128/64/48/32/24/16.png (rounded square, transparent corners) + app.ico
ps4/     sce_sys/icon0.png   512x512, opaque
ps5/     sce_sys/icon0.png   1024x1024, opaque
master/  addonstation_icon_1024.png
preview.png
