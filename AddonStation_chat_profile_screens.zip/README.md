# AddonStation – Chat + Edit Profile screens

Languages: en, ar, fr, tr, es, ru, pt, zh (ar = RTL)

## Files
- preview.html – interactive preview (8 screens, dark/light, EN/AR)
- strings/<lang>.json – all UI strings, one file per language
- strings/all_languages.csv – same strings in one sheet
- android/res/values*/strings_chat_profile.xml – ready for Android (Kotlin/Compose)

## Screens
Chat
1. rooms – Community: Main rooms + Language rooms, online count, unread badge, "Locked (read only)", Cash room, bottom bar
2. attach – Attach sheet: Photo, Audio / Video file (Video/Audio admin only for members)
3. media – Audio (waveform + play), Video (thumbnail + play + duration), Announcement card, "Uploading…" bar, "Not sent · Tap to retry"
4. composer – "Replying to", "[Name] is typing…", "New messages" + NEW divider, empty room, loading skeleton

Edit profile (tabs: Avatar | Banners | Item | About, live preview on top)
5. pe_avatar – pack chips (All, A, B, C locked, D locked), grid, locked = dimmed + lock + Epic badge + Upgrade card, search, "No matching pictures."
6. pe_item – chat-style preview, None card, Epic items grid, Golden items grid, "Equipped", locked sections, empty section text
7. pe_banner – pack chips, Remove banner, locked banners
8. pe_about – Custom status, About me (counters), Online status toggle (Legendary only)

## Notes
- Pack names and item names are [Placeholder]; replace with real data.
- 8 item icons are examples.
- "Item" tab label is a new string.
- Room settings (gear) screen not designed.
- fr/tr/es/ru/pt/zh translations are mine; have a native speaker review them.
