import { useEffect, useState } from "react";

export const useOrigin = () => {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
        return () => {
            setMounted(false);
        };
    }, []);

    const origin = typeof window !== "undefined" ? window.location.origin : "";

    if (!mounted) {
        return "";
    }

    return origin;
}