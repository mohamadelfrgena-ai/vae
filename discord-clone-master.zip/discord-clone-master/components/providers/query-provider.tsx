"use client"

import {
  QueryClient,
  QueryClientProvider
} from "@tanstack/react-query";

import React, { useState } from "react";

export const QueryProvider = ({
  children
}: {
  children: React.ReactNode
}) => {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 30 * 1000,
        refetchOnWindowFocus: false,
      },
    },
  }));

  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  )
}