"use client";

import { Member, Profile, MemberRole } from "@prisma/client";
import { ShieldAlert, ShieldCheck } from "lucide-react";
import { useRouter } from "next/navigation";
import { useParams } from "next/navigation";
import { UserAvatar } from "../user-avatar";
import { cn } from "@/lib/utils";

interface ServerMemberProps {
  member: Member & { profile: Profile };
}

const roleIconMap = {
  [MemberRole.GUEST]: null,
  [MemberRole.MODERATOR]: <ShieldCheck className="h-4 w-4 ml-2 text-indigo-500" />,
  [MemberRole.ADMIN]: <ShieldAlert className="h-4 w-4 ml-2 text-rose-500" />,
}

export const ServerMember = ({ member }: ServerMemberProps) => {
  const params = useParams();
  const router = useRouter();

  const icon = roleIconMap[member.role];

  const onClick = () => {
    router.push(`/servers/${params?.serverId}/conversations/${member.id}`);
  }

  return (
    <button
      onClick={onClick}
      className="group px-2 py-2 rounded-md flex items-center text-sm gap-x-2 w-full hover:bg-zinc-700/10 dark:hover:bg-zinc-700/50 transition mb-1"
    >
      <UserAvatar
        src={member.profile.imageUrl}
        className="h-5 w-5 md:h-5 md:w-5"
      />
      <p className={cn(
        "font-medium text-sm text-zinc-500 group-hover:text-zinc-600 dark:text-zinc-400 dark:group-hover:text-zinc-300 transition",
        params?.memberId === member.id && "text-primary dark:text-zinc-200 dark:group-hover:text-white"
      )}>
        {member.profile.name}
      </p>
      {icon}
    </button>
  )
}
