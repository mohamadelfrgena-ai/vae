# AddonStation — UI Spec: Home sections · Creators · Creator profile & tips · Become a Creator · Creator Dashboard · Privacy/Terms · About

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the base; Light theme and Arabic (RTL) are specified for every screen.
`reference/creators_pages_preview.html` is a clickable visual reference (screen selector, Light/Dark, English/Arabic, state buttons). Open it in a browser and follow it for the exact look; this spec gives the numbers and rules.
Tokens (dark/light), fonts, shapes, icon tiles, status chips, top bar and action bar are the same as in `SPEC_ITEM_PLANS_ORDERS_ALERTS.md` section 0, and the chat bits (dialogs, sheets, fields) as in `SPEC_CHAT_DETAILS_STATES.md` — read those first.
All texts already exist in `strings.xml` (key table at the end). Emoji in existing strings are replaced by vector icons: use the emoji-free `*_plain` keys in `res/values*/strings_creators_pages.xml`. **Do not change creator, tip or upload logic**: only layout, icons and colors.

| # | Screen | Opens from |
|---|---|---|
| 1 | Home — extra sections | Home (insert into `SPEC_HOME_V2.md` layout, see 1.1) |
| 2 | Creators | "View all" on Featured creators |
| 3 | Creator profile · Support this creator | tap a creator anywhere |
| 4 | Become a Creator (application) | Creator program card on Home |
| 5 | Creator Dashboard (publish content) | same card when the user is a creator |
| 6 | Privacy policy · Terms of use | Settings → About |
| 7 | About the app | Settings → About the app |
Help center, Contact us and Report a problem have **no screen**: they open the mail app with the prefilled templates (`set_support_mail_*`). Keep the explanatory notes `set_support_note_*` under those Settings rows.

## 1. Home — extra sections
The existing Home v2 omitted sections that exist in the app. **New Home order:** top bar → greeting+search → hero → plan strip → **Quick actions** → chips → Latest addons → **Recommended for you** → **Exclusives** → Most downloaded → Featured creators → **Creator program card**. Each new section uses the Home v2 section header (title + optional "View all").
1. **Quick actions** (`home_quick_actions_plain`, margin 16/16): 4 equal tiles (gap 8), min height 84, radius 16, surface, 1dp border, centered column (gap 8): icon tile 40 (radius 12) + label 12sp/800, max 2 lines. Tiles: **My favorites** (`home_qa_favorites`, heart, error tint → My lists/Favorites) · **My downloads** (`home_qa_downloads`, download, blue → My lists/Downloads) · **Upgrade** (`home_qa_upgrade`, crown, gold → Plans) · **Device** (`home_qa_device`, phone, ok → the existing action).
2. **Recommended for you** (`home_recommended_plain`): horizontal item cards, same as "Latest addons" (150 wide, thumbnail 100, tier badge, title, `item_by`).
3. **Exclusives** (`home_exclusives_plain`, sub-line `home_exclusives_sub` 13sp muted, margin −4/0/10): horizontal **wide cards** 260×150, radius 18, cover center-crop, overlay gradient transparent (30%) → `#0A0F1C`@88%, tier badge top-start 10, title 16sp/800 white and `item_by` 12sp `#C4D1E8` at the bottom (inset 12/14).
4. **Featured creators** (`home_creators`, link `view_all` → Creators): row of avatars 64 with a 2dp rank ring (gold, purple, blue, border) and a 12sp/700 name below (item width 72, gap 14).
5. **Creator program card** (end of the list, margin 22/16/30): radius 20, padding 16, gradient 135° `#102244` → `#121A2B` (light: `#E6EEFF` → `#FFFFFF`), 1dp blue border.
   - **Not a creator:** kicker `home_creator_kicker` (pixel 11sp, goldText, letter spacing 1sp; Arabic Tajawal 800) · title `home_creator_title` 20sp/800 · text `home_creator_text` 13sp muted, line height 1.55 · button `home_creator_cta` (44 high, radius 12, primary gradient, full width) → Become a Creator.
   - **Creator:** same card; title `home_creator_dashboard`; button `home_creator_open` (gold gradient) → Creator Dashboard.

## 2. Creators
Top bar title `creators_title` (new). Scroll content padding 16.
- Subtitle `creator_subtitle` 13sp muted · search field `creator_search` (48 high, radius 14, surface, 1dp border, search icon 20, margin top 12).
- **Featured creators** (`creator_featured`): horizontal cards 150 wide, radius 16, surface, 1dp border: cover strip 64 high, avatar 48 circle with 3dp surface border overlapping −24, name 14sp/800, `creator_addons_count` plural 12sp muted.
- **Popular creators** (`creator_popular`) and **New creators** (`creator_new`): one card per section, rows (padding 12×14, gap 12, 1dp dividers): avatar 44 · column [name 15sp/800; "[N] addons · [N] downloads" 12sp muted] · chip `role_creator_plain` (blue, 11sp/800, radius 9). Tap → Creator profile.
- Filtering happens on typing (name or specialty). No results: `creator_empty` in the empty-state layout (88 circle, search icon).

## 3. Creator profile · Support this creator
- **Cover** 130 high (creator cover, fallback gradient) with a gradient to `bg`; back button 44 (translucent dark). **Header** (padding 16, avatar overlaps the cover by 38): avatar 80 with 4dp border in `bg`, name 20sp/800 + chip `role_creator_plain`.
- Bio 14sp muted-ish (chipText), line height 1.6 · stat chips (28 high): downloads count (download icon 14 + `profile_stats_downloads`) and addons count (`creator_addons_count`).
- **Support button** (margin top 16): full width, 56 high, radius 16, gold gradient, `#1B1405` text 16sp/800, filled heart icon 22 + `creator_tip_title`.
- **Latest addons** (`home_latest_plain`): horizontal item cards of this creator.
- **Support sheet** (opens over a dimmed profile; sheet top at 96dp, radius 24 top, barSurface, padding 8/16/20): grab handle, title `creator_tip_title` 18sp/800, then labelled fields (label 12sp/700 chipText, margin top 14):
  - `creator_tip_amount` ("Amount (LYD)"): field 48 high showing the number 18sp/800 + quick chips 5 · 10 · 20 · 50 (44 high, radius 12; selected: 2dp gold border, goldText).
  - `creator_tip_method`: radio rows like Checkout (min 56, radius 14; selected 2dp blue border), followed by the creator's wallet details (`creator_field_wallets`) with a Copy button as in Checkout.
  - `creator_tip_upload_receipt`: dashed upload zone (2dp dashed border, radius 16, min height 96, upload icon 26, "PNG · JPEG · WEBP" 13sp muted).
  - `creator_tip_message`: multiline field, min height 92.
  - Button `creator_tip_send_plain`: gold gradient, 56 high, heart icon.
- **Success:** centered dialog (radius 24) with an 88 circle (ok@16%, check 44) and `creator_tip_sent`, button OK (`common_ok`). Keep existing validation (amount > 0, method, receipt).

## 4. Become a Creator (application)
Top bar title `creator_title` (long: allow two lines). Content padding 16.
- Info card (radius 20, padding 14, same gradient/border as the Home card): kicker + `home_creator_text`.
- Fields in this order, each with a label above (12sp/700 chipText): Country (`creator_field_country`) · Experience (`creator_field_experience`) · Content types (`creator_field_content_types`, multi-select chips 40 high, radius 20: `creator_type_addons`, `creator_type_worlds`, `creator_type_maps`; selected = blue fill) · Why AddonStation? (`creator_field_motivation`, multiline 92) · Portfolio links (`creator_field_portfolio`) · Previous work link (`creator_field_previous_work`) · What will you publish? (`creator_field_publish_plan`, multiline) · Wallet links (`creator_field_wallets`).
  Field: min height 48, radius 12, surface, 1dp border, padding 0/14 (multiline: padding 12/14, min 92); invalid = 1dp error border + error line.
- Two checkboxes (24×24, radius 7, selected = blue fill + white check; row min height 48): `creator_own_work` and `creator_guidelines_ok_plain`. Both required.
- Submit `home_creator_cta` (56 high, radius 16, primary gradient, margin 12/0/30). After sending, show the request status using the existing request states from the admin side.

## 5. Creator Dashboard (publish content)
Top bar title `home_creator_dashboard`. Fields as in section 4: Title (`creator_field_title`), Version (`creator_field_version`), Content types (chips: Addons / Worlds), **Cover** (`creator_cover_label`: dashed zone with image icon + `creator_cover_choose`; when the upload fails the zone gets a 2dp dashed error border, alert icon and `creator_cover_failed` in errorText), **File** (`creator_file_label`: dashed zone, accepted types shown under the icon — use the real types the app accepts), the two checkboxes, button `common_save` (56 high, primary gradient). Keep the existing upload and validation logic.

## 6. Privacy policy · Terms of use
Top bar title `set_privacy` / `set_terms`. Content padding 16.
- **Last updated chip:** the **last paragraph** of the text ("Last updated: 30 September 2026") shown as a chip above the card — 32 high, radius 16, surfaceHigh, chipText 12sp/800, Schedule icon 14.
- **Body card** (surface, 1dp border, radius 16, margin 12/0/30): split `set_privacy_text` / `set_terms_text` on blank lines (everything except the last paragraph); each paragraph is a row (padding 14, gap 12, 1dp divider): number badge 26 circle (blue@16%, blueLink 12sp/800) + text 14sp, line height 1.65, chipText. Do not edit the legal text.

## 7. About the app
Top bar title `set_about`. Centered content, padding top 30: app icon 96×96 radius 24 with 3dp gold border and a soft gold glow · wordmark `brand_wordmark` (pixel 20sp; Arabic Latin brand stays pixel) · `brand_platform` 14sp muted · chip `brand_tagline` ("AddonStation Mobile · v1.2", 32 high, radius 16, surfaceHigh).
Info card (margin top 24, rows min 56, 1dp dividers): Version `set_version` + the value (muted) · Privacy policy (`set_privacy`) · Terms of use (`set_terms`) · Contact us (`set_contact`) — link rows with a 36 icon tile (radius 10), a label and a chevron (AutoMirrored). Footer `brand_rights` 12sp muted, padding 26/0/30.

## 8. Light theme, Arabic (RTL), accessibility
- Light: use the light tokens; the Home card and creator cover overlays keep dark text-safe gradients; legal pages are plain on `bg`.
- RTL: `android:supportsRtl="true"`, start/end everywhere; lists and chips flow from the right; chevrons AutoMirrored; Arabic uses Tajawal (no letter spacing, no uppercase); long titles wrap.
- Numbers (counts, amounts, version) follow the app-wide digit convention (see `SPEC_HOME_V2.md`) and are formatted with `NumberFormat`; wrap mixed Latin/number runs with Unicode isolates if they reorder.
- Accessibility: targets ≥ 44dp, content descriptions on icon-only buttons and avatars, checkboxes announce their state, error lines are linked to their fields, upload zones are buttons with a clear label.

## 9. Assets
```
assets/images/app_icon.png            About screen icon
assets/images/ic_default_profile.jpg  default avatar
assets/images/item_placeholder.jpg    fallback cover/thumbnail
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/creators_pages_preview.html clickable visual reference
```
Copy images to `res/drawable-nodpi/`, fonts to `res/font/`, merge the two strings files into the project. Icons are Material Icons (Favorite, Download, WorkspacePremium, PhoneAndroid, Search, Image, FileUpload, Check, Warning, Schedule, Shield/PrivacyTip, Description, Mail, ChevronRight, ArrowBack, ContentCopy).

## 10. String keys used
| Key | English | Arabic |
|---|---|---|
| `home_quick_actions_plain` | Quick actions | إجراءات سريعة |
| `home_qa_favorites` | My favorites | مفضلتي |
| `home_qa_downloads` | My downloads | تحميلاتي |
| `home_qa_upgrade` | Upgrade | الترقية |
| `home_qa_device` | Device | الجهاز |
| `home_recommended_plain` | Recommended for you | موصى به لك |
| `home_exclusives_plain` | Exclusives | الحصريات |
| `home_exclusives_sub` | Creator specials selected by AddonStation | عروض خاصة من المبدعين اختارتها AddonStation |
| `home_featured_plain` | Featured | المميزة |
| `home_creators` | Featured creators | المبدعون المميزون |
| `home_latest_plain` | Latest addons | أحدث الإضافات |
| `home_creator_kicker` | CREATOR PROGRAM | برنامج المبدعين |
| `home_creator_title` | Become a Creator | كن مبدعاً |
| `home_creator_text` | Share your addons and worlds with the AddonStation community and open the door to creator earnings. | شارك إضافاتك وعوالمك مع مجتمع AddonStation وافتح طريقاً لتحقيق أرباح المبدعين. |
| `home_creator_cta` | Become a Creator | كن مبدعاً |
| `home_creator_dashboard` | Creator Dashboard | لوحة المبدع |
| `home_creator_open` | Open Dashboard | افتح اللوحة |
| `creator_title` | AddonStation creator program | برنامج منشئي AddonStation |
| `creator_subtitle` | Discover the people building your next Minecraft adventure. | اكتشف الأشخاص الذين يبنون مغامرتك القادمة في ماينكرافت. |
| `creator_search` | Search creators... | ابحث عن منشئين... |
| `creator_featured` | Featured creators | المبدعون المميزون |
| `creator_popular` | Popular creators | الأكثر شهرة |
| `creator_new` | New creators | المبدعون الجدد |
| `creator_empty` | No creators — try another name or specialty. | لا يوجد مبدعون — جرّب اسماً أو تخصصاً آخر. |
| `creator_tip_title` | Support this creator | دعم منشئ المحتوى |
| `creator_tip_amount` | Amount (LYD) | المبلغ (د.ل) |
| `creator_tip_method` | Payment method | طريقة الدفع |
| `creator_tip_upload_receipt` | Upload the reference receipt | ارفع رمز المرجع والإيصال |
| `creator_tip_message` | Optional message | رسالة اختيارية |
| `creator_tip_send_plain` | Send support | إرسال الدعم |
| `creator_tip_sent` | Tip sent successfully | تم إرسال الدعم بنجاح |
| `creator_field_country` | Country | الدولة |
| `creator_field_experience` | Experience | الخبرة |
| `creator_field_content_types` | Content types (addons, worlds…) | أنواع المحتوى (إضافات، عوالم…) |
| `creator_field_motivation` | Why AddonStation? | لماذا AddonStation؟ |
| `creator_field_portfolio` | Portfolio links | روابط الأعمال |
| `creator_field_previous_work` | Previous work link | رابط عمل سابق |
| `creator_field_publish_plan` | What will you publish? | ماذا ستنشر؟ |
| `creator_field_wallets` | Wallet links | روابط المحفظة |
| `creator_field_title` | Title | العنوان |
| `creator_field_version` | Version | الإصدار |
| `creator_own_work` | Own work / permission | عمل خاص / بإذن |
| `creator_guidelines_ok_plain` | Guidelines | الإرشادات |
| `creator_cover_failed` | Couldn't upload the cover — please try again. | تعذّر رفع الغلاف — حاول مرة أخرى. |
| `role_creator_plain` | Creator | Creator |
| `item_by` | By %1$s | بواسطة %1$s |
| `profile_stats_downloads` | Downloads | تحميلاتي |
| `common_ok` | OK | حسناً |
| `common_save` | Save | حفظ |
| `set_privacy` | Privacy policy | سياسة الخصوصية |
| `set_privacy_text` | We respect your privacy and are committed to protecting your data. We … (full text, paragraphs split on blank lines) | نحترم خصوصيتك ونلتزم بحماية بياناتك. قد … |
| `set_terms` | Terms of use | شروط وأحكام الاستخدام |
| `set_terms_text` | By using AddonStation, you agree to these terms and undertake to use t… (full text, paragraphs split on blank lines) | باستخدام AddonStation، فإنك توافق على هذ… |
| `set_about` | About the app | حول التطبيق |
| `set_version` | App version | إصدار التطبيق |
| `set_contact` | Contact us | تواصل معنا |
| `set_help` | Help center | مركز المساعدة |
| `set_report_problem` | Report a problem | الإبلاغ عن مشكلة |
| `set_support_note_help` | Tap this option and your mail app opens with a ready message to the support team. | لأي سؤال عن التحميل أو الخطط أو الشات اضغط هذا الخيار وسيُفتح بريدك برسالة جاهزة إلى فريق الدعم. |
| `set_support_note_contact` | Your mail app opens straight to silverfoxinteractive@gmail.com — we reply within 24 hours. | سيُفتح بريدك فوراً على silverfoxinteractive@gmail.com — نرد خلال 24 ساعة. |
| `set_support_note_report` | Describe the problem (screen, steps, device) — your mail app opens with your device details filled in. | اشرح المشكلة (الشاشة، الخطوات، نوع جهازك) — سيُفتح بريدك برسالة جاهزة تتضمن بيانات جهازك تلقائياً. |
| `brand_wordmark` | AddonStation | AddonStation |
| `brand_platform` | Minecraft Bedrock addons & worlds platform | منصة إضافات وعوالم Minecraft Bedrock |
| `brand_tagline` | AddonStation Mobile · v1.2 | AddonStation Mobile · الإصدار 1.2 |
| `brand_rights` | © 2026 AddonStation — All rights reserved | © 2026 AddonStation — جميع الحقوق محفوظة |
| `view_all` | View all | عرض الكل |
| `creators_title` (NEW) | Creators | المبدعون |
| `creator_cover_label` (NEW) | Cover | الغلاف |
| `creator_cover_choose` (NEW) | Choose a cover image | اختر صورة الغلاف |
| `creator_file_label` (NEW) | File | الملف |
| `creator_type_addons` (NEW) | Addons | إضافات |
| `creator_type_worlds` (NEW) | Worlds | عوالم |
| `creator_type_maps` (NEW) | Maps | خرائط |
| `creator_addons_count` (NEW plurals) | %d addon(s) | Arabic with 6 plural forms |