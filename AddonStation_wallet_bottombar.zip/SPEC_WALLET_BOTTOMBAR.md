# AddonStation — UI Spec: AC Wallet + Bottom Navigation Bar

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait, dark theme. Design width **390 dp**; sizes are dp/sp.
Placeholders in brackets (`[N]`, `[Date]`) are data-bound values. All texts already exist in the app's `strings.xml` (the AC wallet strings are in the current app): reuse the existing string resources and wording. Do not change any wallet logic (AC is an internal reward currency; there is no AC purchase or cash-out).

Contents: **1. Tokens · 2. AC Wallet screen · 3. Compact wallet card (for Profile) · 4. Bottom navigation bar · 5. Assets**

---

## 1. Tokens
Colors: bg `#0A0F1C` · surface `#121A2B` · surfaceHigh `#1A2438` · barSurface `#0E1526` · border `#223049` · divider `#1D2940` · text `#EAF0FA` · textMuted `#9DB0CF` (labels `#C4D1E8`) · blue `#2E7BEF` · blueLight `#6FA8FF` · accent blue `#4C9AFF` · gold `#F0C25E` · goldDark `#1B1405` · goldBorder `#8A6A22` · goldText `#E8D5A3` · goldLine `#5A4416` · green `#3FBF6A` (text `#7FD99A`) · purple `#9B6BFF` · red `#FF6B78` (text `#FF8791`).
Approximated from the app icon; keep every color in one `AppColors` object.
Fonts: pixel font `assets/fonts/pixel_regular.ttf` for the screen title and uppercase section labels (title 15sp, section label 11sp, letter spacing 1sp). Body: Nunito 500/700/800 (Arabic: Tajawal or the system font). Balance/number text may use `roboto_medium_numbers.ttf`.
Shapes: cards radius 16–24 · buttons radius 12–14 · icon tiles 44×44 radius 12. Min touch target 44dp. Horizontal margin 16dp.

**Icon tile** (used across the screen): 44×44, radius 12, bg = accent @15% alpha, 1dp border = accent @33% alpha, Material Outlined icon 22dp tinted with the accent.
**Section label:** row with a 6×14 accent bar (radius 2) + pixel 11sp label in the accent color, padding 24/20/10.

---

## 2. Screen: AC Wallet
Column, bg `bg`, vertical scroll. No bottom bar content overlap: add bottom padding for the bottom navigation bar (section 4).

**Top bar:** bg `barSurface`, bottom border 1dp `border`, padding 10; back button 44×44 circle bg `surface` (ArrowBack); title "AC WALLET" pixel 15sp, margin start 6.

### 2.1 Balance + Daily reward card (hero)
Margin 16/16/0, radius 24, 1dp `goldBorder`, padding 20, clipped. Background: gradient 145° `#3E2D0C` → `#1B1405` at 62%. Decorative soft glow: 160×160 radial gradient `gold`@28% → transparent, top-right, offset (−40, −40).
1. **Balance row** (gap 16): `coin_ac.png` 72×72 with a soft gold glow (shadow 14dp, gold @55%); column: label "AC wallet · Current balance" 12sp/700 `goldText`; below it the balance: number 44sp/800 `gold` (line height 1.1) + " AC" 16sp/800 `goldText`, baseline aligned.
2. Divider: 1dp `goldLine`, margin 18/0/16.
3. **Daily reward row:** title "Daily reward" 16sp/800 (weight 1) + streak chip: bg `#2A2210`, 1dp `goldBorder`, radius 14, padding 4×10, flame icon 16dp (gold) + "[N] day streak" 12sp/800 `gold`.
4. **7-day tracker** (margin top 14, space-between), each day a 38×38 circle:
   - completed: fill `gold`, white-on-gold check icon (goldDark, 16dp);
   - today: transparent, 2dp `gold` border, day number 13sp/800 `gold`;
   - upcoming: bg `#1A1710`, 1dp `#4A3A18`, number 13sp/700 `#8A7A52`;
   - day 7: bg `#2A2210`, 1dp **dashed** `goldBorder`, gift icon `gold` 16dp.
   Under it, right-aligned: "Streak reward" 11sp/800 `gold` (margin top 6).
5. **Claim button:** full width, height 52, radius 14, bg `gold`, text "Claim" `goldDark` 16sp/800, margin top 16. After claiming: disabled (bg `#3A3220`, text `goldText`@60%), label "Claimed". On success show the snackbar "Added [N] AC to your balance." and update the balance with a count-up animation.

### 2.2 Quick actions
Row of 3 equal tiles (margin 12/16/0, gap 10): min height 96, radius 16, bg `surface`, 1dp `border`, padding 12×8, centered column: icon tile (44) + label 12sp/800 (line height 1.25, max 2 lines).
- **Redeem code** — gift icon, purple → scrolls to the Gift code card (2.3).
- **How to earn AC** — sparkle icon, green → opens the existing "How to earn AC" screen/sheet.
- **Transaction history** — history icon, accent blue → opens the full transaction list.

### 2.3 Gift code card
Section label "GIFT CODE" (purple). Card margin 0/16: bg `surface`, 1dp `border`, radius 18, padding 14.
- Row: icon tile (gift, purple) + column ["Gift code" 15sp/800; "Each code works once per member." 12sp muted].
- Input row (margin top 12, gap 10): text field height 48, radius 12, bg `bg`, 1dp `border`, padding 14, hint "Code" (uppercase input, no spaces); button "Redeem code" (height 48, radius 12, bg `blue`, white 13sp/800, padding 16).
- States/messages (inline under the field, 12sp, red for errors, green for success): success "Added [N] AC to your balance."; errors: "This code is not valid. Check the letters and digits." · "This code has expired." · "This code is currently disabled." · "This code reached its usage limit." · "You have already redeemed this code." Signed-out: "Sign in first to redeem a code."

### 2.4 Latest AC operations
Section header row: label "LATEST AC OPERATIONS" (accent blue, weight 1) + right link "Transaction history" 12sp/800 `blueLight` (44dp touch).
Card margin 0/16: bg `surface`, 1dp `border`, radius 18, clipped. Row: min height 64, padding 10×14, gap 12: icon tile · column [title 14sp/800; "balance [N] · [Date]" 12sp muted] weight 1 · amount 15sp/800 (`#7FD99A` for +, `#FF8791` for −). Dividers 1dp `divider` inset at 70dp.
Row types (icon / accent): Daily reward (calendar / gold, +) · AC task (check / accent blue, +) · Content unlock (lock / red, **−**) · Streak reward (gift / gold, +) · Event reward (star / purple, +) · Admin reward (shield / gold, +). Amount text format: "+[N] AC" / "−[N] AC" (use the real minus sign).
Show the last 5; empty state: "No AC operations yet".

### 2.5 Info card
Margin 14/16/24: bg `barSurface`, 1dp `border`, radius 16, padding 14, info icon 22dp `blueLight` + text 12sp, line height 1.5, `#C4D1E8`: "AC is an internal reward currency. Earn it through activity and use it to unlock eligible addons and worlds. There is no AC purchase or cash-out."

### 2.6 Other states
Loading: skeleton blocks in `surface`. When unlocking content with insufficient balance elsewhere in the app, show "Not enough AC" and offer to open this wallet.

---

## 3. Compact wallet card (use in Profile instead of the old wallet card)
Margin 16, radius 22, 1dp `goldBorder`, padding 16, gradient 145° `#3E2D0C` → `#1B1405` at 65%, glow 120×120 top-right (gold@25%).
- Row (gap 14): `coin_ac.png` 56×56 with glow · column ["AC wallet · Current balance" 12sp/700 `goldText`; balance 30sp/800 `gold` + " AC" 13sp/800 `goldText`] weight 1 · chevron (18dp, `goldText`). The whole card (except the button) opens the AC Wallet screen.
- Row (margin top 14, gap 10): streak chip (height 44, bg `#2A2210`, 1dp `goldBorder`, radius 14, padding 0×10, flame 18dp + "[N] day streak" 12sp/800 gold) + button "Daily reward" (weight 1, height 44, radius 12, bg `gold`, `goldDark` 14sp/800; same claim behavior as 2.1).

---

## 4. Bottom navigation bar
Used by the main screens (not by Settings sub-screens, Notification settings, Sign in, Create account, AC Wallet, Chat room, or any detail screen).

### 4.1 Tabs and order
Five tabs. **Logical order (start → end): Settings · Chat · Home · Store · Profile.** In left-to-right languages this is left → right; with an RTL language (Arabic) Android mirrors it automatically so it reads **Profile · Store · Home · Chat · Settings** from left to right. Home is always the center tab. Declare `android:supportsRtl="true"` and do not hard-code left/right.
Labels: English — Settings, Chat, Home, Store, Profile. Arabic — الإعدادات، الشات، الرئيسية، المتجر، البروفايل. Use string resources.
Icons (Material, 24dp; Outlined when inactive, Filled when active): Settings (Settings), Chat (ChatBubble), Home (Home), Store (ShoppingBag), Profile (Person).

### 4.2 Bar container
Floating bar: horizontal margin 12 (plus `navigationBarsPadding` for the bottom inset + 8), height **72**, radius 26, bg `barSurface` @96% alpha, 1dp `border`, shadow 30dp / `#000` @50% (offset y 10), inner padding 0×6. Tabs share the width equally. Reserve space at the top for Home's overflow (20dp) and give the screen content a bottom padding of 72 + 12 + inset, so nothing is hidden behind the bar.

### 4.3 Regular tab (Settings, Chat, Store, Profile)
Column centered, height 64, gap 3, min touch width 48:
- Indicator pill 52×34, radius 17:
  - **Active:** gradient 135° `blue` → `accent blue`, soft shadow (14dp, blue@45%), icon Filled white.
  - **Inactive:** transparent, icon Outlined `#8EA0BF`.
- Label 11sp: active `blueLight` weight 800; inactive `#8EA0BF` weight 700. Labels are always visible.

### 4.4 Home tab (center, raised)
Circle 60×60, **raised 20dp above the bar** (offset y −20), 3dp border in `bg` color to cut it out of the bar:
- **Active:** gradient 135° `blue` → `accent blue`, glow shadow (22dp, blue@55%, offset y 8), icon Filled white 28dp.
- **Inactive:** bg `surfaceHigh`, shadow (18dp, black@50%), icon Outlined `#C4D1E8` 28dp.
Label under the circle, 11sp, same active/inactive colors as 4.3 (gap 2).

### 4.5 Badges
- **Chat unread badge:** on the top-right of the icon pill (top −4, end −2): min size 18, radius 9, padding 0×5, bg `red`, 2dp border `barSurface`, white 10sp/800 count (cap at "99+"; hide at 0).
- **Profile dot:** 10×10 circle `red` with 2dp `barSurface` border at top −1, end 6 (e.g. a pending friend request).

### 4.6 Behavior
Tapping a tab navigates with `launchSingleTop` and state restore; tapping the active tab scrolls its screen to the top. Hide the bar on detail screens and while the keyboard is open. Add content descriptions to all tabs (the label text).

---

## 5. Assets
```
assets/images/coin_ac.png            AC coin (wallet hero + compact card)
assets/fonts/pixel_regular.ttf       pixel font
assets/fonts/roboto_medium_numbers.ttf
```
Copy `coin_ac.png` to `res/drawable-nodpi/` and the fonts to `res/font/`. Everything else (flame, gift, check, calendar, history, chat, store, home, person, settings icons) uses Material Icons — no extra files.
