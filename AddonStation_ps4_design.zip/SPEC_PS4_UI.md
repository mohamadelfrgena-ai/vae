# AddonStation: PS4 app UI spec (TV / controller) — with the offer banner

Design of the PS4 app. It is independent of the code package (`AddonStation_ps4_app_code.zip`; the code currently implements the simpler first version, see section 11) and reads the **same database** as the Android, iOS and PC apps (`SHARED_BACKEND.md`). The offer banner content comes from the database and is edited by the owner (`SPEC_OFFER_BANNERS.md`).
`reference/ps4_store_design_preview.html` is the clickable preview (English / Arabic, 4 screens, banner variants). `reference/design_png/` has full-size captures. `reference/banner_admin_preview.html` is the admin editor.

## 1. Canvas, safe area, tokens
- **1920 × 1080 px**, dark only. **Title-safe area: 96 px left/right, 54 px top/bottom.**
- Colors: bg `#0A0F1C`, surface `#121A2B`, surfaceHigh `#1A2438`, border `#223049`, text `#EAF0FA`, muted `#9DB0CF`, chip `#C4D1E8`, blue `#2E7BEF`/`#4C9AFF`, blueLight `#6FA8FF`, focus ring `#9CC1FF`, gold `#F0C25E`, ok `#3FBF6A`, discount red `#FF5C7A → #FF3D6B`.
- Type (px): body 28, small 22 (the minimum), tabs 30, section titles 38–40, banner title (F77 Minecraft) up to 100, legend 24. Fonts: **F77 Minecraft** (`assets/fonts/F77-Minecraft.ttf`, see `FONT_LICENSE.txt`) for the **main names**: brand name, banner title, countdown digits, discount badge, section titles (Recommended for you...), exclusive tile titles, card/item names and the item page title; **Nunito** for everything else (body, chips, buttons, legend); **Tajawal** for Arabic (the pixel font is not used in Arabic layouts); system CJK for Chinese. F77 has no letter spacing (banner title 1 px).
- Radius: hero 34, exclusive tiles 28, cards 22, buttons 22–26, chips 31.

## 2. Controller map and focus
| Button | Action |
|---|---|
| D-pad / left stick | Move focus |
| ✕ | Select |
| ○ | Back |
| □ | Search / Filter / Write |
| △ | Menu / Sort |
| L1 / R1 | Previous / next main tab |
| **L2 / R2** | **Previous / next offer in the banner** (works from anywhere on Home) |
- **Focus style:** 5 px ring `#9CC1FF` (offset 4) + 14 px glow `#2E7BEF`@35% + shadow 0 28 60 black@60%; cards also scale 1.05. 120 ms transition (none with reduced motion).
- **Home focus order:** banner button **primary** (initial focus) → banner secondary button → (Right) exclusive tiles (big → small left → small right) → (Down) filter chips → recommended row cards. Up/Left return the same way. The focused tile is always fully visible.

## 3. Top bar (solid on Home/Store, transparent over the art on Deals)
Height 120. Brand tile 60 (3 px gold border, soft gold glow) + "ADDONSTATION" (F77 Minecraft); tabs **Home · ❄ Deals · Store · Chat · Settings** (30px) with **L1/R1** glyphs; active = white + 5 px blueLight underline; **Deals** is tinted ice blue with a snowflake icon (the icon/tint follows the current campaign theme). Right: AC pill (58 high, glass fill, coin 40 + balance 28px gold) + avatar 58.

## 4. Home (Microsoft-Store-style layout)
Content block at **y = 126, height 520**, margins 96, two columns with a 28 px gap:
### 4.1 Left: the offer banner (1040 × 520, radius 34)
- Full-bleed art (cover) + left-to-right dark gradient (`#050A18`@94% → 78% at 40% → transparent at 100%) + a themed light glow at the top right (winter: ice blue; sunset: amber; night: violet).
- Content column at x = 56, y = 44 (max width 760): **label chip** (height 40, radius 20, glass + 1.5 px themed border, 19px, snowflake icon for winter) → **title** (F77 Minecraft, auto-sized to fit one line: size = min(100, 800 ÷ (characters × 0.7)); winter = white → ice-blue gradient with blue shadow) → **subtitle** 30px/700 → **row**: discount badge (height 78, radius 20, red gradient, 46px/800, rotated −3°) + optional **countdown** (3 glass tiles 88 × 78: F77 digits 34px + DAYS/HRS/MIN 13px) → **buttons** (height 76, radius 22, 28px/800): primary (blue gradient) + secondary (glass).
- The banner has **no floating card**: the right 45% of the art stays clear.
- **Pager** under the banner (y = 664, centered): 5 dots (10 px; active 16 px white). L2/R2 change the slide; auto-advance every **7 s**, paused while any element of the banner has focus; wraps around.
### 4.2 Right: Exclusives (three tiles, 660 wide)
Grid 2 columns, rows 300 + 192, gap 28, radius 28, art cover + dark gradient.
- **Big tile** (660 × 300): left column text: **EXCLUSIVE chip** (gold `#F0C25E`, star icon, 19px/800, radius 10 on the start side) joined to the **AC price chip** (dark glass, coin 26 + price 22px/800, radius 10 on the end side) → title 40px/800 → "By [Creator]" 21px.
- **Two small tiles** (316 × 192 each): chips at the bottom-start, title 26px/800 under them.
- The three tiles are content items flagged as exclusive and chosen by the owner (see `SPEC_OFFER_BANNERS.md` section 4). Tapping opens the item details.
### 4.3 Below
- **Filter chips** (y = 700, height 62, radius 31, 24px/700): **All · Addons · Worlds · Free · Epic · Legendary · New**; selected = blue@30% fill + blueLight border. ✕ applies the filter to the row below. Free / Epic / Legendary filter by the plan an item requires (`required_plan`); **New** = published in the last 14 days; Addons / Worlds filter by type; only one chip is active at a time.
- **Recommended for you** (title 38px/800 + prev/next circle buttons 52) then a row of cards **318 × ~330**: cover 178 (16:9) + discount tag (top-start) or tier badge + title 28px/800 + "By [Creator]" 21px + **price row** (coin 26 + price 30px gold + old price struck 22px muted). Only the top of the row is visible on the first screen; it fades into the legend (mask 55% → transparent) and scrolls into view when focus moves down.

## 5. Deals page (tab ❄ Deals — the landing page of the banner)
- Header band (height 430, full-bleed): campaign art + left gradient; label chip, title (pixel 80px), subtitle 32px, countdown tiles. The tab bar floats over it.
- Filter chips (y = 480): All · Addons · Worlds · Under 100 AC · Biggest discount; grid **5 columns** (cards 318 × ~330, gap 34 × 30) with discount tags and price rows; the grid fades under the legend; □ Filter, △ Sort.
- The page shows the items of the collection chosen in the banner (`promo_collections`).
## 6. Store
Solid top bar → **promo strip** (y = 130, height 210, radius 30, art + gradient: label chip, pixel title 56px, subtitle 26px, discount badge, **Shop the sale** button) → filter row (Addons | Worlds segmented control 62 high, sort chips) → grid of 5 columns. The strip shows only when a store-strip banner is active.
## 7. Addon details (on sale)
Left: cover 1000 × 560 (radius 32) with a **campaign ribbon** (top-start, glass pill, snowflake + "Winter Sale") and the tier badge (top-end); description below. Right (width ≈ 560): title 54px/800, creator 28px, stats; **price box** (radius 26, red/blue tinted gradient, 2 px red@40% border): discount tag 76 high + coin 44 + new price 64px gold + old price struck 34px + "Sale ends in 3d 12h" 23px ice-blue; platform tags (PS4/PC ✓); buttons (height 96): **Unlock with AC** (gold gradient, dark text, initial focus), Save, Share. Owned items show **Download**; not enough AC → the button opens the AC wallet.
## 8. Chat and Settings
As in the first version (see the code package and the other specs): room list + room view, polling every 3 s, □ Write; Settings with language and account.

## 9. States
Loading: skeleton frame, then content. Banner image fails: show the themed gradient with the text only. No active banner: the left card is replaced by the first exclusive/featured item (same layout). Offline: `msg_network_error` + Retry with initial focus. Signed out: browsing allowed; AC prices shown, Unlock asks to sign in.

## 10. Languages and RTL
8 languages; banner texts come per language from the database (fallback English). **Arabic mirrors everything**: banner left↔right (art gradient flips), exclusives column on the start side, dots/tabs/legend order, discount tag corner. Title font switches to Tajawal ExtraBold 66 px (F77 is not used in Arabic layouts).

## 11. Relation to the code package
The code (`src/core/app.cpp`) implements the first version: top bar, a simple hero (first item), recommended row, Store grid, item page, chat, settings. **Not yet in code:** the banner carousel, the Exclusives tiles, the Deals tab, promo strip, sale price box. The data side (`promo_banners` etc.) is described in `SPEC_OFFER_BANNERS.md`.
