# AddonStation — UI Spec: Splash animation (the design in `reference/`)

Native Android app (Kotlin, Jetpack Compose). Portrait, dark only. Design width **390 × 844 dp**; sizes are dp/sp. This replaces the current `SplashScreen` (`ui/splash/SplashScreen`). It keeps the app's existing splash assets (scene photo, Minecraft logo) and its three headline strings; only layout and animation change.
`reference/splash_boards_preview.html` is the exact animation (English and Arabic loop every 7 s, plus the timeline) — open it in a browser and match it. `reference/*-html/` are the three boards exactly as exported.
Fonts: pixel font `assets/fonts/pixel_regular.ttf` (Latin only) for the English headline and the brand name; **Tajawal ExtraBold** (bundle it) for the Arabic headline and tagline; Nunito for other text.

## 1. Layout (all positions in dp from the top of a 390×844 screen)
Layers, bottom to top, inside one full-screen `Box` with background `#0A0F1C`:
1. **Scene photo** (`assets/images/splash_bg_original.jpg`, the app's splash image): top-aligned, full width, **height 600**, crop `Crop`, alignment top-center.
2. **Gradient overlay:** vertical, from `#0A0F1C`@25% (0%) → @15% (25%) → @80% (50%) → solid `#0A0F1C` (66%). It darkens the lower half so the text is readable and the screen ends in the app background.
3. **Minecraft logo** (`splash_logo.png`): width **230**, height auto (≈ 45), centered, **top 84**, drop shadow 0 8dp 14dp black@60%. It is the existing logo — do not redraw it.
4. **Headline** — three centered lines, **top 330**:
   - English: pixel font **30sp**, line height 1.4, letter spacing 2sp. Text `splash_dream_it`, `splash_build_it`, `splash_create_it`.
   - Arabic: Tajawal ExtraBold **38sp**, line height 1.3, no letter spacing.
   - Colors: line 1 `#EAF0FA`, line 2 `#6FA8FF`, line 3 `#F0C25E`.
   - A gold ✦ sparkle (30 dp, `#F0C25E`) sits after line 3, offset top −10 and end −34.
5. **Brand block** — centered column, **top 610**: app icon `app_icon.png` **72×72**, radius 18, 2dp `#F0C25E` border, gold glow (shadow 24dp, `#F0C25E`@35%); wordmark **"ADDONSTATION"** pixel 15sp, letter spacing 2sp, color `#EAF0FA`, margin top 10 (stays Latin in Arabic too).
6. **Tagline** — centered, **top 722**: `home_guest_card_title_plain`, 13sp/700, `#C4D1E8` (Arabic: Tajawal).
7. **Pixel loader** — centered, **bottom 56**: 10 segments **22 × 10 dp**, radius 2, gap 4, gold `#F0C25E`; inactive segments are the same gold at alpha .18.
Use the status-bar/cutout insets to push the logo and headline down on devices with a cutout; keep the brand block and loader anchored as above.

## 2. Timeline (7 s, plays once in the app)
All easings are ease-out unless noted. Times are from the start of the animation.
| Time | Element | Animation |
|---|---|---|
| 0 – 0.7 s | Scene photo | Opacity 0 → 1; scale **1.15 → 1.0** over 4 s (center-top origin) |
| 0.3 – 1.25 s | Minecraft logo | Falls from −100 dp with a bounce: opacity 0 → 1 and Y −100 → **+10** (0.3–0.8 s) → −4 (1.05 s) → 0 (1.25 s) — like a block landing |
| 1.2 – 1.65 s | Line 1 (DREAM IT.) | Slides in from the **start** side (−30 dp → 0) with opacity 0 → 1 |
| 1.9 – 2.35 s | Line 2 (BUILD IT.) | Slides in from the **end** side (+30 dp → 0), opacity 0 → 1 |
| 2.6 – 3.5 s | Line 3 (CREATE IT.) | Scale .85 → 1.04 → 1 with opacity 0 → 1 (2.6–3.05 s), then a **gold glow** (text shadow 0 → 22 dp → 10 dp, `#F0C25E`@90% → 40%) |
| 3.0 – 4.0 s | Sparkle ✦ | Scale 0 → 1.2 → .6 and rotation 0 → 45° → 90°; opacity 0 → 1 → 0 |
| 3.5 – 4.25 s | Brand block | Scale .6 → **1.08** → 1 (overshoot) with opacity 0 → 1 |
| 4.2 – 4.7 s | Tagline | Opacity 0 → 1 and rises from +8 dp |
| 4.3 – 5.9 s | Loader | Segment *i* lights up at 4.3 + 0.17·i s: alpha .18 → 1 and scaleY 1 → 1.35 → 1 (over 0.28 s). **Drive it with real loading progress** when available (see section 4) |
| 6.0 – 6.6 s | Hold | Everything stays visible |
| 6.6 – 7.0 s | Exit | Cross-fade to the next screen |

## 3. Compose implementation notes
- One `Animatable<Float>` for time (`0f → 7f`, `LinearEasing`) and derive each element's progress with small helpers (`progress(t, start, end, easing)`); apply with `graphicsLayer { alpha = …; translationY = …; scaleX = …; scaleY = … }` — no recomposition per frame.
- Glow on line 3: `Text(style = TextStyle(shadow = Shadow(color, blurRadius = …)))` driven by the same time value.
- Scene photo: decode once (≤ 1080 px height), `Image(contentScale = Crop, alignment = TopCenter)`; the zoom is a `graphicsLayer` scale, not a re-layout.
- Loader: `Row` of 10 `Box`es, alpha/scale from progress; `remember` the segment count from real progress (`floor(progress × 10)`) and use the time-based fill only as the minimum.
- RTL: set `LayoutDirection` from the app language; "start"/"end" for lines 1 and 2 follow it (in Arabic line 1 enters from the right). The logo, wordmark and app icon are not mirrored.

## 4. Behavior
- **Android 12+ system splash:** set `windowSplashScreenBackground=#0A0F1C` and the app icon so the hand-off to this screen has no white flash.
- **Do not block the app on the animation.** Load the session/profile in parallel; leave the splash when the animation has reached 6.0 s **and** the data is ready (for the loader to be honest, hold the last segments until the data is ready).
- **First launch after install/update:** full 7 s intro. **Every other launch:** short intro — logo, icon + wordmark and the loader only, ≈ 1.5 s (skip the headline). Allow **tap to skip** after 1 s.
- **Routing:** signed-in → Home; signed-out → the Welcome / Sign-in screen.
- **Reduced motion** (`ANIMATOR_DURATION_SCALE = 0` or the system setting): show the final frame (all text and the full loader) immediately and move on after the data is ready.
- Keep it light: one bitmap, no per-frame allocations, 60 fps on mid-range devices.

## 5. Strings
| Where | Key | English | Arabic |
|---|---|---|---|
| Line 1 | `splash_dream_it` | DREAM IT. | احلم بها. |
| Line 2 | `splash_build_it` | BUILD IT. | ابنِها. |
| Line 3 | `splash_create_it` | CREATE IT. | أبدعها. |
| Tagline | `home_guest_card_title_plain` (new, emoji-free copy of `home_guest_card_title`) | Minecraft addons & worlds store | متجر إضافات وعوالم ماينكرافت |
"ADDONSTATION" is the brand name (not translated).

## 6. Assets
```
assets/images/splash_bg_original.jpg  scene photo (540×750 crop of the app's splash_bg)
assets/images/splash_logo.png         Minecraft logo (the app's own resource)
assets/images/app_icon.png            app icon
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
reference/splash_boards_preview.html  the animation (EN / AR / timeline)
reference/*-html/                      the three exported boards
```
Copy images to `res/drawable-nodpi/` (the scene and logo already exist in the app as `splash_bg` / `splash_logo` — keep the app's own files if they are higher quality), fonts to `res/font/` (add Tajawal), and merge the strings files. The scene photo and logo are Minecraft promotional/trademark material already used by the app's current splash.

## 7. Related designs (separate package)
A refined version of this splash with a new scene photo, fireflies and a Splash → Welcome transition is in `AddonStation_splash_welcome.zip`. Implement only one: this spec is the baseline design.
