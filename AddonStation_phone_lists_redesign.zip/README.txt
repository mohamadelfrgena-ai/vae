AddonStation phone app: Notifications, My content, My favorites, My downloads, My orders

AddonStation_phone_lists_design.html   open in a browser (opens in Arabic; all states, Dark/Light)
SPEC_PHONE_LISTS.md                    the specification (give this to the Android Studio agent)
captures/sheet_01..04.jpg              every state (Arabic, dark)
