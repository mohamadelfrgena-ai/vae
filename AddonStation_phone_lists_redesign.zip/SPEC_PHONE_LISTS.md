# AddonStation phone app: Notifications, My content, My favorites, My downloads, My orders

Open `AddonStation_phone_lists_design.html` (pick a screen and a state; Dark/Light; Arabic/English: it opens in Arabic). `captures/` has every state (Arabic, dark).

> **For the AI agent in Android Studio:** redo these five screens with the layouts below, keep the existing data and repositories, the app tokens, fonts and the pixel font for titles. Reuse one shared header, one shared empty-state component and one shared chip row. Do not change anything not listed.

## 1. What was wrong (from the screenshots)
- **No shared header:** each screen had a different top bar (logo + star icon, or a back arrow only); some had no back button.
- **Empty states were plain grey text with emoji** and no action. **"My downloads" showed the wrong text** ("no content yet, create your addons from the admin panel"). That text also told normal users to use an "admin panel".
- **Notifications showed raw English server messages** inside the Arabic app ("You received 100 AC", "A deduction of 1000 AC was applied") and the user's own cartoon avatar on every row; there was no way to tell the types apart, no grouping, no filter.
- **My orders** showed one word "بدون" ("none") as the empty state and flat filter chips without counts.

## 2. Shared pieces
- **Header:** back button (44 dp, radius 14, surface) · title (pixel font 21 sp; Tajawal in Arabic) · count chip (blue, 26 dp high) · spacer · optional action buttons (44 dp square, radius 14). Never use the app logo or a star in the header.
- **Chip row:** horizontal scroll, chips 38 dp high with an optional **count bubble** (20 dp); selected = blue fill.
- **Group label:** 12 sp/800, gold, e.g. Today / Yesterday / Earlier.
- **Icon tile:** 46 dp, radius 15, background = the icon color at 18%.
- **Empty state (all screens):** illustration (176 dp: glow, dashed ring, 104 dp icon tile in the screen's color, 4 small squares) + title (pixel font 22 sp) + one-sentence help (14 sp muted) + **one action button** (full width, max 290 dp, 52 dp high). Same component as the new error page.
- **Status chips:** 22 dp high, radius 11: green = active/published, blue = in review, orange = pending, red = rejected.

## 3. Notifications
Header: back · "Notifications" · chip "2 new" · **mark all as read** button · **settings** button (opens notification settings).
Chips with counts: **All · Account · Chat · Content · Social** (the push categories the app already has).
Rows (card radius 18): icon tile by **type** (AC received = coin on green; AC deducted = minus on red; friend request = person on blue; mention = @ on purple; new content = the cover thumbnail; plan activated = gem on gold), **title** (14.5 sp/800), **subtitle** (12 sp muted), **time** at the end (relative: "2h", "Yesterday", date), **amount pill** for AC rows (+green / −red, with the coin), **unread** = blue accent bar, blue dot next to the time and a light blue tint. Friend request rows carry **Accept / Decline** buttons. Mention rows show a one-line quote of the message. Grouped by **Today / Yesterday / Earlier**.
**Swipe:** swipe a row to reveal **Read** (blue) and **Delete** (red); a hint line explains it the first time.
**Empty:** bell-off illustration, "No notifications yet", "We will tell you about AC, friend requests, mentions and new addons and worlds.", button **Notification settings**.
**Important:** build the title and subtitle in the app, in the user's language, from the notification **type and its numbers** (amount, name, room…); do not display the English text that comes from the server.

## 4. My content (creators)
Header: back · "My content" · count · **+ New** (opens the creator dashboard).
Top: three **mini stat tiles** (Published, Downloads, Views). Chips: All · Published · In review · Rejected (with counts).
Row: cover 76 × 62, title, **type chip** (Addon / World), **status chip**, stats (downloads, views, rating), **edit** button; rejected rows show a red box "Reason: …".
**Empty (creator):** cube illustration, "No content yet", "Publish your first addon or world from the Creator Dashboard.", button **Open dashboard**.
**Empty (not a creator):** gold illustration, "My content is for creators", "Apply to become a creator, then publish your own addons and worlds.", button **Become a creator** (opens the creator application). Never mention an "admin panel" to normal users.

## 5. My favorites
Header: back · "My favorites" · count. Segmented control **Addons | Worlds** with counts. 2-column grid with the **same cards as the Store** (badge, filled pink heart, title, creator, stats icons).
**Removing:** tapping the heart fades the card and shows a **snackbar** "Removed from favorites · Undo" (undo for 5 s, then the card disappears).
**Empty:** pink heart illustration, "No favorites yet", "Tap the heart on any addon or world to keep it here.", button **Browse the store**.

## 6. My downloads
Header: back · "My downloads" · count.
**Usage card** at the top: "Downloads this month 8 / 20" with a progress bar (uses the plan's download limit). When the limit is reached the card turns orange/red, shows "You reached your download limit for this plan", "The limit resets in 3 days." and an **Upgrade** link.
Rows grouped by **This week / Earlier**: cover 76 × 62, title, **plan badge** + type chip, "downloaded {date} · {size}", and a **download-again** button. (Opening the file depends on the file still being on the phone; keep the app's current behaviour for that.)
**Empty:** tray illustration (this screen must **not** reuse the My content text), "No downloads yet", "Addons and worlds you download will show up here.", button **Browse the store**.

## 7. My orders
Header: back · "My orders" · count. Chips with counts: **All · Pending · In review · Active · Rejected** (the app's existing order statuses).
Order card: plan tile (Epic = gem on purple, Legendary = crown on gold), plan name and duration, **amount** (large, in LYD) at the end, **order number** chip (copy on tap), **status chip**, date and payment method, then a footer that depends on the status:
| Status | Footer |
|---|---|
| Pending | "Transfer the amount, then upload the receipt." + **Upload receipt** (blue) |
| In review | "We are checking your receipt." (no button) |
| Active | "Active until {date}" (green) + **View plan** |
| Rejected | red box "Reason: …" + **Try again** |
**Order details** (tap a card): summary card (plan, order number, status), key/value list (amount, method, transaction reference, created date), a **progress timeline** (Order created → Receipt uploaded → Under review → Plan activated; done = green check, current = blue ring) and a **receipt** row with a View button.
**Empty:** purple receipt illustration, "No orders yet", "When you subscribe to a plan, your orders and their status appear here.", button **See plans**.

## 8. New texts (English / Arabic)
Existing app keys are reused for: notifications title/new/accept/decline/categories, "My favorites", "My downloads", "My content", "My orders", order number, order statuses, the download-limit message, Addons/Worlds, All.
| English | Arabic |
|---|---|
| 2 new | ٢ جديد |
| Read / Delete | مقروء / حذف |
| Swipe a notification to mark it as read or delete it. | اسحب التنبيه لتعليمه كمقروء أو حذفه. |
| Today / Yesterday / Earlier / This week | اليوم / أمس / سابقاً / هذا الأسبوع |
| You received {n} AC | حصلت على {n} AC |
| {n} AC were deducted | تم خصم {n} AC من رصيدك |
| A gift from the AddonStation team | هدية من فريق AddonStation |
| Adjusted by the team | تعديل من الإدارة |
| [Name] sent you a friend request | [الاسم] أرسل لك طلب صداقة |
| Accept to chat and share content | اقبل لتتحدثا وتشاركا المحتوى |
| [Name] mentioned you in [Room] | [الاسم] أشار إليك في [الغرفة] |
| [Addon] was just published | تم نشر [الإضافة] للتو |
| Your Epic plan is active | خطتك Epic مفعّلة |
| No notifications yet | لا توجد تنبيهات بعد |
| We will tell you about AC, friend requests, mentions and new addons and worlds. | سنخبرك عن AC وطلبات الصداقة والإشارات والإضافات والعوالم الجديدة. |
| Published | منشور |
| New | جديد |
| Reason: … | السبب: … |
| No content yet | لا يوجد محتوى بعد |
| Publish your first addon or world from the Creator Dashboard. | انشر أول إضافة أو عالم من لوحة المبدع. |
| Open dashboard | فتح لوحة المبدع |
| My content is for creators | محتواي مخصص للمبدعين |
| Apply to become a creator, then publish your own addons and worlds. | قدّم لتصبح مبدعاً ثم انشر إضافاتك وعوالمك. |
| Become a creator | كن مبدعاً |
| Removed from favorites / Undo | أُزيل من المفضلة / تراجع |
| No favorites yet | لا توجد مفضلة بعد |
| Tap the heart on any addon or world to keep it here. | اضغط على القلب في أي إضافة أو عالم لحفظه هنا. |
| Browse the store | تصفح المتجر |
| Downloads this month | تحميلات هذا الشهر |
| Upgrade | ترقية |
| No downloads yet | لا توجد تحميلات بعد |
| Addons and worlds you download will show up here. | الإضافات والعوالم التي تحمّلها ستظهر هنا. |
| Transfer the amount, then upload the receipt. | حوّل المبلغ ثم ارفع الإيصال. |
| Upload receipt | رفع الإيصال |
| We are checking your receipt. | نراجع إيصالك الآن. |
| Active until {date} | مفعّلة حتى {date} |
| View plan / Try again / View | عرض الخطة / حاول مرة أخرى / عرض |
| Progress | التقدم |
| Order created / Receipt uploaded / Under review / Plan activated | تم إنشاء الطلب / تم رفع الإيصال / قيد المراجعة / تفعيل الخطة |
| Usually within a few hours | عادةً خلال ساعات |
| Amount / Method / Transaction reference / Created | المبلغ / الطريقة / مرجع التحويل / أُنشئ |
| Receipt | الإيصال |
| No orders yet | لا توجد طلبات بعد |
| When you subscribe to a plan, your orders and their status appear here. | عند اشتراكك في خطة ستظهر طلباتك وحالتها هنا. |
| See plans | عرض الخطط |
(Texts in the other six languages follow once these are approved.)

## 9. Open points
1. Which notification types exist on the server (the design covers AC received/deducted, friend request, mention, new content, plan activated); any other type needs an icon, a color and a localized text.
2. Whether a downloaded file can be opened again from the app, or only downloaded again.
3. Whether order details should show the receipt image inside the app.
