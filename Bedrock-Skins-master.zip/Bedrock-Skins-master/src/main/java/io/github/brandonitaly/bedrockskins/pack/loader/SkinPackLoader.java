package io.github.brandonitaly.bedrockskins.pack.loader;

import io.github.brandonitaly.bedrockskins.client.appearance.skin.AnimatedSkinTextures;
import io.github.brandonitaly.bedrockskins.pack.model.AssetSource;
import io.github.brandonitaly.bedrockskins.pack.model.LoadedSkin;
import io.github.brandonitaly.bedrockskins.pack.model.SkinEntry;
import io.github.brandonitaly.bedrockskins.pack.model.SkinId;
import io.github.brandonitaly.bedrockskins.pack.model.SkinPackManifest;
import io.github.brandonitaly.bedrockskins.pack.pck.PckImporter;
import io.github.brandonitaly.bedrockskins.pack.persona.PersonaImages;
import io.github.brandonitaly.bedrockskins.pack.persona.PersonaTexturePayload;
import io.github.brandonitaly.bedrockskins.pack.StringUtils;
import io.github.brandonitaly.bedrockskins.pack.TranslationLookup;

import io.github.brandonitaly.bedrockskins.util.ExternalAssetUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.blaze3d.platform.NativeImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.function.Function;
import net.minecraft.client.Minecraft;
import io.github.brandonitaly.bedrockskins.client.render.texture.SkinTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import org.slf4j.Logger;

public final class SkinPackLoader {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static final Map<String, String> packTypesByPackId = new ConcurrentHashMap<>();
    public static final Map<String, Identifier> packIconsByPackId = new ConcurrentHashMap<>();
    private static final Map<SkinId, LoadedSkin> loadedSkins = Collections.synchronizedMap(new LinkedHashMap<>());
    public static volatile List<String> packOrder = List.of();

    private static final Codec<List<String>> PACK_ORDER_CODEC = Codec.list(Codec.STRING);
    private static final Map<String, Map<String, String>> translations = new ConcurrentHashMap<>();
    private static final Set<Identifier> dynamicPackIcons = ConcurrentHashMap.newKeySet();
    public static JsonObject vanillaGeometryJson = null;

    private SkinPackLoader() {}

    private static Identifier createIdentifier(String namespace, String path) {
        return Identifier.fromNamespaceAndPath(namespace, path);
    }

    private static Identifier parseAssetPath(String path) {
        if (path == null || path.isEmpty()) return null;
        int colonIndex = path.indexOf(':');
        if (colonIndex > 0 && colonIndex < path.length() - 1) {
            try {
                return createIdentifier(path.substring(0, colonIndex), path.substring(colonIndex + 1));
            } catch (Exception e) {
                LOGGER.debug("Ignoring invalid asset identifier {}", path, e);
            }
        }
        return null;
    }

    // --- Public API ---

    public static String getTranslation(String key) {
        String normalizedKey = StringUtils.cleanLocalizationText(key).toLowerCase(Locale.ROOT);
        return TranslationLookup.find(translations, normalizedKey, getClientLanguage());
    }

    public static void loadPacks() {
        synchronized (loadedSkins) {
            loadedSkins.entrySet().removeIf(entry -> {
                if (!(entry.getValue().texture instanceof AssetSource.Remote)) {
                    releaseSkinAssets(entry.getKey());
                    return true;
                }
                return false;
            });
        }
        translations.clear();
        packTypesByPackId.clear();
        clearPackIcons();

        ResourceManager manager = Minecraft.getInstance().getResourceManager();
        loadVanillaGeometry(manager);

        File currentSkinPacksDir = getSkinPacksDir();
        if (currentSkinPacksDir.exists()) {
            File[] children = currentSkinPacksDir.listFiles();
            if (children != null) {
                // Convert .pck files to standard folders
                for (File f : children) {
                    if (f.isFile() && f.getName().toLowerCase(Locale.ROOT).endsWith(".pck")) {
                        File outputDir = new File(currentSkinPacksDir, StringUtils.stripExtension(f.getName()));
                        if (PckImporter.importPck(f, outputDir)) f.delete();
                    }
                }
                for (File f : Objects.requireNonNull(currentSkinPacksDir.listFiles())) {
                    if (f.isDirectory()) loadExternalPack(f);
                }
            }
        }

        loadInternalPacks(manager);
        loadPackOrder(manager);
    }

    public static void releaseSkinAssets(SkinId id) {
        LoadedSkin skin = getLoadedSkin(id);
        if (skin == null) return;
        
        var tm = Minecraft.getInstance().getTextureManager();
        if (skin.identifier != null) {
            io.github.brandonitaly.bedrockskins.client.appearance.skin.HeadIconTextures.remove(skin.identifier);
            AnimatedSkinTextures.remove(skin.identifier);
            SkinTexture.release(tm, skin.identifier);
            skin.identifier = null;
        }
        if (skin.capeIdentifier != null) {
            SkinTexture.release(tm, skin.capeIdentifier);
            skin.capeIdentifier = null;
        }
    }

    public static void registerTextureFor(SkinId id) {
        LoadedSkin skin = getLoadedSkin(id);
        if (skin != null && skin.identifier == null) registerSkinAssets(skin);
    }

    public static LoadedSkin getLoadedSkin(SkinId id) { 
        return id == null ? null : loadedSkins.get(id); 
    }

    public static List<LoadedSkin> loadedSkinsSnapshot() {
        synchronized (loadedSkins) {
            return List.copyOf(loadedSkins.values());
        }
    }

    public static LoadedSkin getLoadedSkinByTexture(Identifier texture) {
        if (texture == null) return null;
        synchronized (loadedSkins) {
            for (LoadedSkin skin : loadedSkins.values()) {
                if (texture.equals(skin.identifier)) return skin;
            }
        }
        return null;
    }

    public static int loadedSkinCount() {
        return loadedSkins.size();
    }

    public static boolean hasLoadedSkins() {
        return !loadedSkins.isEmpty();
    }

    public static void registerLoadedSkin(LoadedSkin skin) {
        if (skin != null && skin.skinId != null) loadedSkins.put(skin.skinId, skin);
    }

    public static void removeLoadedSkin(SkinId id) {
        if (id == null) return;
        releaseSkinAssets(id);
        loadedSkins.remove(id);
    }

    public static int removeLoadedSkins(Predicate<LoadedSkin> predicate) {
        List<SkinId> removedIds = new ArrayList<>();
        synchronized (loadedSkins) {
            loadedSkins.entrySet().removeIf(entry -> {
                if (!predicate.test(entry.getValue())) return false;
                releaseSkinAssets(entry.getKey());
                removedIds.add(entry.getKey());
                return true;
            });
        }

        return removedIds.size();
    }

    public static void registerRemoteSkin(String key, String geometryJson, byte[] textureData, byte[] capeData) {
        registerRemoteSkin(key, geometryJson, textureData, capeData, null);
    }

    public static void registerRemoteSkin(String key, String geometryJson, byte[] textureData, byte[] capeData, String hash) {
        SkinId idKey = SkinId.parse(key);
        if (!validateRemoteData(textureData, geometryJson)) return;
        String contentHash = (hash == null || hash.isEmpty())
            ? io.github.brandonitaly.bedrockskins.network.BedrockSkinsNetworking.computeHash(geometryJson, textureData, capeData) : hash;
        LoadedSkin previous = loadedSkins.get(idKey);
        if (previous != null && (!(previous.texture instanceof AssetSource.Remote) || previous.hasAvailableContent(contentHash))) return;
        
        try {
            // Parse geometry JSON first to fail fast before any native allocations
            JsonObject geometryObject = JsonParser.parseString(geometryJson).getAsJsonObject();

            PersonaTexturePayload payload = PersonaTexturePayload.decode(textureData);
            NativeImage img = NativeImage.read(new ByteArrayInputStream(payload.baseTexture()));
            SkinTexture texture = null;
            Identifier id = null;
            
            NativeImage capeImg = (capeData != null && capeData.length > 0) ? NativeImage.read(new ByteArrayInputStream(capeData)) : null;
            SkinTexture capeTexture = null;
            Identifier capeId = null;
            
            boolean success = false;
            try {
                texture = new SkinTexture(() -> "bedrock_skin_remote", img);
                id = createIdentifier("bedrockskins", "skins/remote/" + StringUtils.sanitize(key) + "/" + contentHash);
                texture.register(Minecraft.getInstance().getTextureManager(), id);

                if (capeImg != null) {
                    capeTexture = new SkinTexture(() -> "bedrock_cape_remote", capeImg);
                    capeId = createIdentifier("bedrockskins", "capes/remote/" + StringUtils.sanitize(key) + "/" + contentHash);
                    capeTexture.register(Minecraft.getInstance().getTextureManager(), capeId);
                }

                // The object's ID must match its registry key: GUI previews and head
                // portraits resolve geometry through LoadedSkin.skinId as well.
                LoadedSkin ls = new LoadedSkin(idKey, "Remote", "Remote", key,
                    geometryObject, AssetSource.Remote.INSTANCE,
                    capeId != null ? AssetSource.Remote.INSTANCE : null,
                    false);
                ls.identifier = id;
                ls.capeIdentifier = capeId;
                ls.hash = contentHash;
                AnimatedSkinTextures.register(id, texture, payload);
                loadedSkins.put(idKey, ls);
                if (previous != null) {
                    var manager = Minecraft.getInstance().getTextureManager();
                    if (previous.identifier != null) {
                        io.github.brandonitaly.bedrockskins.client.appearance.skin.HeadIconTextures.remove(previous.identifier);
                        AnimatedSkinTextures.remove(previous.identifier);
                        SkinTexture.release(manager, previous.identifier);
                    }
                    if (previous.capeIdentifier != null) SkinTexture.release(manager, previous.capeIdentifier);
                    io.github.brandonitaly.bedrockskins.client.render.model.BedrockModelManager.invalidate(idKey);
                }
                success = true;
            } finally {
                if (!success) {
                    if (texture != null) {
                        texture.close();
                    } else {
                        img.close();
                    }
                    if (id != null) {
                        AnimatedSkinTextures.remove(id);
                        SkinTexture.release(Minecraft.getInstance().getTextureManager(), id);
                    }
                    if (capeTexture != null) {
                        capeTexture.close();
                    } else if (capeImg != null) {
                        capeImg.close();
                    }
                    if (capeId != null) {
                        SkinTexture.release(Minecraft.getInstance().getTextureManager(), capeId);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to register remote skin {}", key, e);
        }
    }

    // --- Loading Logic ---

    private static void loadVanillaGeometry(ResourceManager manager) {
        manager.getResource(createIdentifier("bedrockskins", "skin_packs/vanilla/geometry.json")).ifPresent(res -> {
            try (Reader r = new InputStreamReader(res.open(), StandardCharsets.UTF_8)) {
                vanillaGeometryJson = JsonParser.parseReader(r).getAsJsonObject();
            } catch (Exception e) { 
                LOGGER.warn("Failed to load vanilla geometry", e);
            }
        });
    }

    private static void loadExternalPack(File packDir) {
        File skinsFile = new File(packDir, "skins.json");
        if (!skinsFile.exists()) return;

        try {
            JsonObject geometryJson = loadJsonOrNull(new File(packDir, "geometry.json"));
            SkinPackManifest manifest;
            try (Reader reader = new InputStreamReader(new FileInputStream(skinsFile), StandardCharsets.UTF_8)) {
                manifest = decodeManifest(reader, skinsFile.getAbsolutePath());
            }
            if (manifest == null) return;

            loadExternalTranslations(packDir);
            registerPackType(manifest);
            registerDynamicPackIcon(packIdFor(manifest.serializeName()), findPackIconFile(packDir));

            registerPackSkins(manifest, geometryJson, path -> resolveExternalAsset(path, packDir));
        } catch (Exception e) {
            LOGGER.warn("Failed to load external pack from {}", packDir.getName(), e);
        }
    }

    private static void loadInternalPacks(ResourceManager manager) {
        manager.listResources("skin_packs", idt -> idt.getPath().endsWith("skins.json")).forEach((id, resource) -> {
            try {
                String packPath = id.getPath().substring(0, id.getPath().lastIndexOf('/'));
                Identifier geoId = createIdentifier(id.getNamespace(), packPath + "/geometry.json");
                
                JsonObject geoJson = manager.getResource(geoId).map(res -> {
                    try (Reader r = new InputStreamReader(res.open(), StandardCharsets.UTF_8)) {
                        return JsonParser.parseReader(r).getAsJsonObject();
                    } catch (Exception e) {
                        LOGGER.warn("Failed to load geometry for internal pack {}", id, e);
                        return null;
                    }
                }).orElse(null);

                SkinPackManifest manifest;
                try (Reader rr = new InputStreamReader(resource.open(), StandardCharsets.UTF_8)) {
                    manifest = decodeManifest(rr, id.toString());
                }
                if (manifest == null) return;
                
                registerPackType(manifest);
                loadInternalTranslations(manager, id.getNamespace(), packPath);
                registerResourcePackIcon(packIdFor(manifest.serializeName()), findResourcePackIcon(id.getNamespace(), packPath, manager));

                registerPackSkins(manifest, geoJson, path -> {
                    Identifier asset = resolveInternalAsset(path, id.getNamespace(), packPath, manager);
                    return asset != null ? new AssetSource.Resource(asset) : null;
                });
            } catch (Exception e) {
                LOGGER.warn("Failed to load internal pack {}", id, e);
            }
        });
    }

    // --- Helpers: Geometry & Assets ---

    private static void registerPackSkins(SkinPackManifest manifest, JsonObject geometryJson,
                                         Function<String, AssetSource> resolveAsset) {
        for (SkinEntry entry : manifest.skins()) {
            registerLoadedSkin(loadPackSkin(manifest, entry, geometryJson, resolveAsset));
        }
    }

    static LoadedSkin loadPackSkin(SkinPackManifest manifest, SkinEntry entry, JsonObject geometryJson,
                                   Function<String, AssetSource> resolveAsset) {
        JsonObject geometry = resolveGeometry(entry.geometry(), geometryJson);
        if (geometry == null || entry.texture() == null) return null;
        AssetSource texture = resolveAsset.apply(entry.texture());
        if (texture == null) return null;

        AssetSource cape = entry.cape() != null ? resolveAsset.apply(entry.cape()) : null;
        LoadedSkin skin = new LoadedSkin(
            manifest.serializeName(), manifest.localizationName(), entry.localizationName(),
            geometry, texture, cape, hasUpsideDownAnimation(entry));
        skin.unfair = entry.unfair();
        return skin;
    }

    private static AssetSource resolveExternalAsset(String path, File packDir) {
        if (path == null) return null;
        Identifier resourceId = parseAssetPath(path);
        if (resourceId != null) return new AssetSource.Resource(resourceId);
        
        File file = new File(packDir, path.toLowerCase(Locale.ROOT));
        return file.exists() ? new AssetSource.File(file.getAbsolutePath()) : null;
    }

    private static Identifier resolveInternalAsset(String path, String namespace, String packPath, ResourceManager manager) {
        if (path == null) return null;
        Identifier id = parseAssetPath(path);
        if (id == null) id = createIdentifier(namespace, (packPath + "/" + path).toLowerCase(Locale.ROOT));
        return manager.getResource(id).isPresent() ? id : null;
    }

    public static JsonObject resolveGeometry(String name, JsonObject localGeo) {
        JsonObject raw = findGeometryNode(localGeo, name);
        if (raw == null) raw = findGeometryNode(vanillaGeometryJson, name);
        return raw != null ? wrapGeometry(raw.deepCopy(), name) : null;
    }

    private static JsonObject findGeometryNode(JsonObject json, String name) {
        if (json == null) return null;
        if (json.has(name)) return json.getAsJsonObject(name);

        JsonArray arr = json.getAsJsonArray("minecraft:geometry");
        if (arr != null) {
            for (JsonElement el : arr) {
                if (el.isJsonObject()) {
                    JsonObject geo = el.getAsJsonObject();
                    if (geo.has("description") && geo.getAsJsonObject("description").has("identifier")) {
                        if (name.equals(geo.getAsJsonObject("description").get("identifier").getAsString())) return geo;
                    }
                }
            }
        }
        return null;
    }

    private static JsonObject wrapGeometry(JsonObject content, String name) {
        JsonObject wrapper = new JsonObject();
        wrapper.addProperty("format_version", "1.12.0");

        if (!content.has("description")) {
            JsonObject desc = new JsonObject();
            desc.addProperty("identifier", name);
            desc.addProperty("texture_width", content.has("texturewidth") ? content.get("texturewidth").getAsInt() : content.has("texture_width") ? content.get("texture_width").getAsInt() : 64);
            desc.addProperty("texture_height", content.has("textureheight") ? content.get("textureheight").getAsInt() : content.has("texture_height") ? content.get("texture_height").getAsInt() : 64);
            content.add("description", desc);
        }

        JsonArray arr = new JsonArray();
        arr.add(content);
        wrapper.add("minecraft:geometry", arr);
        return wrapper;
    }

    private static void registerSkinAssets(LoadedSkin skin) {
        if (skin.identifier != null) return;
        var tm = Minecraft.getInstance().getTextureManager();

        NativeImage img = loadNativeImage(skin.texture);
        if (img != null) {
            SkinTexture texture = null;
            try {
                skin.identifier = createIdentifier("bedrockskins", "skins/" + skin.safePackName + "/" + skin.safeSkinName);
                texture = new SkinTexture(() -> "bedrock_skin", img);
                texture.register(tm, skin.identifier);
            } catch (Exception e) {
                LOGGER.warn("Failed to register skin texture for {}:{}", skin.serializeName, skin.skinDisplayName, e);
                skin.identifier = null;
                if (texture != null) {
                    texture.close();
                } else {
                    img.close();
                }
            }
        }

        if (skin.capeIdentifier == null && skin.cape != null) {
            NativeImage capeImg = loadNativeImage(skin.cape);
            if (capeImg != null) {
                SkinTexture texture = null;
                try {
                    skin.capeIdentifier = createIdentifier("bedrockskins", "capes/" + skin.safePackName + "/" + skin.safeSkinName);
                    texture = new SkinTexture(() -> "bedrock_cape", capeImg);
                    texture.register(tm, skin.capeIdentifier);
                } catch (Exception e) {
                    LOGGER.warn("Failed to register cape texture for {}:{}", skin.serializeName, skin.skinDisplayName, e);
                    skin.capeIdentifier = null;
                    if (texture != null) {
                        texture.close();
                    } else {
                        capeImg.close();
                    }
                }
            }
        }
    }

    private static NativeImage loadNativeImage(AssetSource source) {
        byte[] data = ExternalAssetUtil.loadTextureData(source, Minecraft.getInstance());
        try {
            return data.length > 0 ? NativeImage.read(new ByteArrayInputStream(data)) : null;
        } catch (IOException e) {
            LOGGER.warn("Failed to load native image from {}", source, e);
            return null;
        }
    }

    // --- Helpers: Translations & Misc ---

    private static void loadExternalTranslations(File packDir) {
        File[] files = new File(packDir, "texts").listFiles((dir, name) -> name.endsWith(".lang"));
        if (files != null) {
            for (File file : files) {
                try (InputStream is = new FileInputStream(file)) {
                    String lang = StringUtils.stripExtension(file.getName()).toLowerCase(Locale.ROOT);
                    parseTranslationStream(is, translations.computeIfAbsent(lang, k -> new ConcurrentHashMap<>()));
                } catch (Exception e) {
                    LOGGER.warn("Failed to load translations from {}", file, e);
                }
            }
        }
    }

    private static void loadInternalTranslations(ResourceManager manager, String namespace, String packPath) {
        for (String lang : new LinkedHashSet<>(Arrays.asList(getClientLanguage(), "en_us"))) {
            manager.getResource(createIdentifier(namespace, packPath + "/texts/" + lang + ".lang")).ifPresent(res -> {
                try (InputStream is = res.open()) {
                    parseTranslationStream(is, translations.computeIfAbsent(lang, k -> new ConcurrentHashMap<>()));
                } catch (Exception e) {
                    LOGGER.warn("Failed to load {} translations for {}", lang, packPath, e);
                }
            });
        }
    }

    private static void parseTranslationStream(InputStream input, Map<String, String> map) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            reader.mark(1);
            if (reader.read() != 0xFEFF) reader.reset();

            reader.lines()
                    .map(line -> line.split("=", 2))
                    .filter(parts -> parts.length == 2)
                    .forEach(parts -> map.put(parts[0].trim().toLowerCase(Locale.ROOT), parts[1].split("\\t#")[0].trim()));
        } catch (Exception e) {
            LOGGER.warn("Failed to parse translation stream", e);
        }
    }

    private static void loadPackOrder(ResourceManager manager) {
        manager.getResource(createIdentifier("bedrockskins", "order_overrides.json")).ifPresent(res -> {
            try (Reader r = new InputStreamReader(res.open(), StandardCharsets.UTF_8)) {
                packOrder = PACK_ORDER_CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(r))
                    .resultOrPartial(msg -> LOGGER.warn("Failed to decode pack order: {}", msg))
                    .orElse(List.of());
            } catch (Exception e) {
                LOGGER.warn("Failed to load pack order", e);
            }
        });
    }

    private static SkinPackManifest decodeManifest(Reader reader, String source) {
        try {
            return SkinPackManifest.CODEC.parse(JsonOps.INSTANCE, JsonParser.parseReader(reader))
                .resultOrPartial(msg -> LOGGER.warn("Failed decoding manifest {}: {}", source, msg))
                .orElse(null);
        } catch (Exception e) {
            LOGGER.warn("Failed to read manifest {}", source, e);
            return null;
        }
    }
    
    private static void registerPackType(SkinPackManifest manifest) {
        String serializeName = manifest.serializeName();
        if (serializeName == null) return;

        String packType = manifest.packType();
        if ((packType == null || packType.isEmpty()) && !"Favorites".equals(serializeName) && !"Standard".equals(serializeName)) {
            packType = "skin_pack";
        }
        
        if (packType != null && !packType.isEmpty()) {
            packTypesByPackId.put(packIdFor(serializeName), packType);
        }
    }

    private static String packIdFor(String serializeName) {
        return serializeName == null ? null : "skinpack." + serializeName;
    }

    private static void clearPackIcons() {
        var tm = Minecraft.getInstance().getTextureManager();
        dynamicPackIcons.forEach(id -> SkinTexture.release(tm, id));
        dynamicPackIcons.clear();
        packIconsByPackId.clear();
    }

    private static void registerResourcePackIcon(String packId, Identifier icon) {
        if (packId != null && icon != null) packIconsByPackId.putIfAbsent(packId, icon);
    }

    private static void registerDynamicPackIcon(String packId, File file) {
        if (packId != null && file != null && file.exists() && !packIconsByPackId.containsKey(packId)) {
            registerDynamicPackIcon(packId, new AssetSource.File(file.getAbsolutePath()));
        }
    }

    private static File findPackIconFile(File packDir) {
        if (packDir == null) return null;
        File icon = new File(packDir, "pack.png");
        return icon.exists() ? icon : (icon = new File(packDir, "pack_icon.png")).exists() ? icon : null;
    }

    private static Identifier findResourcePackIcon(String namespace, String packPath, ResourceManager manager) {
        Identifier icon = createIdentifier(namespace, packPath + "/pack.png");
        if (manager.getResource(icon).isPresent()) return icon;
        icon = createIdentifier(namespace, packPath + "/pack_icon.png");
        return manager.getResource(icon).isPresent() ? icon : null;
    }

    private static void registerDynamicPackIcon(String packId, AssetSource source) {
        NativeImage image = loadNativeImage(source);
        if (image == null) return;

        Identifier id = createIdentifier("bedrockskins", "pack_icons/" + StringUtils.sanitize(packId));
        new SkinTexture(() -> "bedrock_pack_icon", image).register(Minecraft.getInstance().getTextureManager(), id);
        dynamicPackIcons.add(id);
        packIconsByPackId.put(packId, id);
    }

    public static File getSkinPacksDir() {
        return new File(Minecraft.getInstance().gameDirectory, "skin_packs"); 
    }

    private static String getClientLanguage() {
        try {
            return Minecraft.getInstance().getLanguageManager().getSelected().toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            LOGGER.debug("Failed to resolve client language; using en_us", e);
            return "en_us";
        }
    }

    private static boolean validateRemoteData(byte[] data, String geo) {
        if (data == null || data.length > 1_048_576 || geo == null || geo.length() > 1_048_576) return false;
        try {
            PersonaImages.read(PersonaTexturePayload.decode(data).baseTexture());
            return true;
        } catch (java.io.IOException | RuntimeException exception) { return false; }
    }

    private static boolean hasUpsideDownAnimation(SkinEntry entry) {
        return entry != null && entry.animations() != null 
            && "animation.player.base_pose.upside_down".equals(entry.animations().get("humanoid_base_pose"));
    }

    private static JsonObject loadJsonOrNull(File file) {
        if (!file.exists()) return null;
        try (Reader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            return JsonParser.parseReader(reader).getAsJsonObject();
        } catch (Exception e) {
            LOGGER.warn("Failed to load JSON from {}", file, e);
            return null;
        }
    }
}
