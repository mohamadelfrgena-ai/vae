package io.github.brandonitaly.bedrockskins.gui.widget;

import io.github.brandonitaly.bedrockskins.gui.preview.*;
import io.github.brandonitaly.bedrockskins.gui.screen.*;
import io.github.brandonitaly.bedrockskins.gui.WidgetVisibility;

import io.github.brandonitaly.bedrockskins.client.BedrockSkinsClient;
import io.github.brandonitaly.bedrockskins.client.persistence.BedrockSkinsConfig;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.FavoritesManager;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.MojangSkinManager;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.AccountProfileRefresh;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.SkinManager;
import io.github.brandonitaly.bedrockskins.client.appearance.cape.CapeManager;
import io.github.brandonitaly.bedrockskins.client.appearance.cape.CapeManager.MinecraftCape;
import io.github.brandonitaly.bedrockskins.client.appearance.persona.PersonaManager;
import io.github.brandonitaly.bedrockskins.client.appearance.persona.PersonaTypeNames;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.ClientSkinSync;
import io.github.brandonitaly.bedrockskins.util.BedrockSkinsSprites;
import io.github.brandonitaly.bedrockskins.util.ExternalAssetUtil;
import io.github.brandonitaly.bedrockskins.pack.model.LoadedSkin;
import io.github.brandonitaly.bedrockskins.pack.model.LoadedCosmetic;
import io.github.brandonitaly.bedrockskins.pack.model.LoadedEmote;
import io.github.brandonitaly.bedrockskins.client.appearance.emote.EmoteManager;
import io.github.brandonitaly.bedrockskins.pack.model.SkinId;
import io.github.brandonitaly.bedrockskins.pack.loader.SkinPackLoader;
import com.mojang.logging.LogUtils;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import org.slf4j.Logger;

public class SkinPreviewPanel {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int INFO_PANEL_HEIGHT = 58;
    private static final int FLOATING_CONTROL_GAP = 2;

    private final Minecraft minecraft;
    private final Font font;
    private final Runnable onFavoritesChanged;
    
    // State
    private int x, y, width, height;
    private FavoriteHeartButton favoriteButton;
    private Button selectButton;
    private Button replayEmoteButton;
    private SpriteIconButton previewButton;
    private SpriteIconButton uploadSkinButton;
    private SpriteIconButton deleteSkinButton;
    private boolean isUploadingSkin = false;
    private boolean isDeletingSkin = false;
    private String uploadStatusMessage = null;
    private boolean uploadStatusIsError = false;
    private long uploadStatusTime = 0L;

    private LoadedSkin selectedSkin;
    private boolean skinSelectedFromGrid;
    private MinecraftCape selectedCape;
    private LoadedCosmetic selectedCosmetic;
    private LoadedEmote selectedEmote;
    private SkinId currentSkinId;
    private Screen parentScreen;
    private PreviewPlayer dummyPlayer;
    private float rotationX = 0;
    private int lastMouseX = 0;
    private boolean isDraggingPreview = false;
    private int previewLeft, previewRight, previewTop, previewBottom;
    private int infoPanelY;

    public SkinPreviewPanel(Minecraft minecraft, Font font, Runnable onFavoritesChanged) {
        this.minecraft = minecraft;
        this.font = font;
        this.onFavoritesChanged = onFavoritesChanged;
    }
    
    public LoadedSkin getSelectedSkin() { return selectedSkin; }
    public MinecraftCape getSelectedCape() { return selectedCape; }
    public LoadedCosmetic getSelectedCosmetic() { return selectedCosmetic; }
    public LoadedEmote getSelectedEmote() { return selectedEmote; }

    private AppearanceTab activeTab() {
        return parentScreen instanceof SkinSelectionScreen selectionScreen
            ? selectionScreen.getActiveTab() : AppearanceTab.SKINS;
    }

    public void setSelectedEmote(LoadedEmote emote) {
        this.selectedEmote = emote;
        if (dummyPlayer != null) {
            if (emote == null) EmoteManager.stop(dummyPlayer.getUuid());
            else EmoteManager.play(dummyPlayer.getUuid(), emote);
        }
        updateFavoriteButton();
    }

    public void setSelectedCosmetic(LoadedCosmetic cosmetic) {
        this.selectedCosmetic = cosmetic;
        if (dummyPlayer != null) {
            PersonaManager.setPreviewWithEquipped(dummyPlayer.getUuid(), cosmetic);
            if (cosmetic != null) EmoteManager.playDressingRoom(dummyPlayer.getUuid(), cosmetic.type);
        }
        updateFavoriteButton();
    }

    public void refreshSelectedCosmeticPreview() {
        if (dummyPlayer != null) PersonaManager.setPreviewWithEquipped(dummyPlayer.getUuid(), selectedCosmetic);
        updateFavoriteButton();
    }

    public void setSelectedCape(MinecraftCape cape) {
        this.selectedCape = cape;
        if (dummyPlayer != null) {
            if (cape == null) {
                dummyPlayer.clearForcedCape();
                rotationX = 0.0F;
            } else {
                applySelectedCapePreview();
            }
        }
        updateFavoriteButton();
    }

    public void playCapeSelectionAnimation() {
        if (dummyPlayer != null) EmoteManager.playDressingRoom(dummyPlayer.getUuid(), "persona_back");
    }

    public void init(int x, int y, int w, int h, Screen parentScreen, Consumer<AbstractWidget> widgetAdder) {
        this.parentScreen = parentScreen;
        selectButton = Button.builder(Component.translatable("bedrockskins.button.equip"), b -> applySkin()).bounds(0, 0, 10, 20).build();
        widgetAdder.accept(selectButton);

        replayEmoteButton = Button.builder(Component.translatable("bedrockskins.button.play_again"),
            b -> replaySelectedEmote()).bounds(0, 0, 10, 20).build();
        WidgetVisibility.setVisible(replayEmoteButton, false);
        widgetAdder.accept(replayEmoteButton);

        favoriteButton = new FavoriteHeartButton(20, BedrockSkinsSprites.HEART_CONTAINER, BedrockSkinsSprites.HEART_FULL, b -> toggleFavorite());
        widgetAdder.accept(favoriteButton.getButton());

        previewButton = SpriteIconButton.builder(Component.empty(), b -> openFullScreenPreview(), true)
            .size(20, 20).sprite(BedrockSkinsSprites.PREVIEW_ICON, 16, 16).build();
        previewButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.preview")));
        widgetAdder.accept(previewButton);

        uploadSkinButton = SpriteIconButton.builder(Component.empty(), b -> uploadSkinToMojang(), true)
            .size(20, 20)
            .sprite(BedrockSkinsSprites.UPLOAD_ICON, 16, 16)
            .build();
        uploadSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.upload_skin")));
        widgetAdder.accept(uploadSkinButton);

        deleteSkinButton = SpriteIconButton.builder(Component.empty(), b -> deleteSelectedSkin(), true)
            .size(20, 20).sprite(BedrockSkinsSprites.TRASH_ICON, 16, 16).build();
        deleteSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.delete")));
        widgetAdder.accept(deleteSkinButton);
        
        reposition(x, y, w, h);
        initPreviewState();
    }

    public void reposition(int x, int y, int w, int h) {
        this.x = x; this.y = y; this.width = w; this.height = h;

        infoPanelY = Math.max(y, y + h - INFO_PANEL_HEIGHT);
        previewLeft = x;
        previewRight = x + w;
        previewTop = y + 4;
        previewBottom = Math.max(previewTop + 20, infoPanelY - 26);

        int btnH = 20;
        int actionX = x + 8;
        int actionW = Math.max(10, w - 16);
        int actionY = infoPanelY + INFO_PANEL_HEIGHT - btnH - 8;
        int floatingY = infoPanelY - btnH - FLOATING_CONTROL_GAP;

        if (selectButton != null) {
            selectButton.setX(actionX); selectButton.setY(actionY); selectButton.setWidth(actionW);
        }
        if (replayEmoteButton != null) {
            replayEmoteButton.setX(actionX);
            replayEmoteButton.setY(actionY);
            replayEmoteButton.setWidth(actionW);
        }
        if (favoriteButton != null) {
            favoriteButton.getButton().setX(x); favoriteButton.getButton().setY(floatingY);
        }
        positionFloatingActionButtons();
    }

    private void positionFloatingActionButtons() {
        int buttonX = x + width - 22;
        int buttonY = floatingControlY();

        if (previewButton != null) {
            previewButton.setPosition(buttonX, buttonY);
            buttonX -= 22;
        }
        if (deleteSkinButton != null) {
            deleteSkinButton.setPosition(buttonX, buttonY);
            if (WidgetVisibility.isVisible(deleteSkinButton)) buttonX -= 22;
        }
        if (uploadSkinButton != null) {
            uploadSkinButton.setPosition(buttonX, buttonY);
        }
    }

    public int floatingControlX() {
        return x;
    }

    public int floatingControlY() {
        return infoPanelY - 20 - FLOATING_CONTROL_GAP;
    }

    private void openFullScreenPreview() {
        if (parentScreen == null) return;
        minecraft.gui.setScreen(new FullScreenPreviewScreen(parentScreen, selectedSkin,
            selectedCosmetic, selectedCape, selectedEmote, rotationX));
    }

    /** Rebuilds the transient preview entity after a child screen has removed this screen. */
    public void restoreAfterFullScreen(float restoredRotation) {
        initPreviewState();
        this.rotationX = restoredRotation;
    }

    public void initPreviewState() {
        if (this.selectedSkin != null) {
            updatePreviewModel(MinecraftAccountSkin.is(this.selectedSkin) ? null : this.selectedSkin.skinId);
            updateFavoriteButton();
            return;
        }

        SkinId currentKey = SkinManager.getLocalSelectedKey();
        if (currentKey != null) {
            this.currentSkinId = currentKey;
            this.selectedSkin = SkinPackLoader.getLoadedSkin(currentKey);
            updatePreviewModel(currentKey);
        } else {
            this.currentSkinId = null;
            updatePreviewModel(null);
        }
        updateFavoriteButton();
    }

    public void setSelectedSkin(LoadedSkin skin) {
        this.selectedSkin = skin;
        this.skinSelectedFromGrid = skin != null;
        this.currentSkinId = skin != null && !MinecraftAccountSkin.is(skin) ? skin.skinId : null;
        updateFavoriteButton();
        if (skin != null) updatePreviewModel(MinecraftAccountSkin.is(skin) ? null : skin.skinId);
    }

    private void updatePreviewModel(SkinId skinId) {
        if (dummyPlayer != null) dummyPlayer.close();
        String name = minecraft.player != null ? minecraft.player.getName().getString() : "Preview";
        dummyPlayer = new PreviewPlayer(name);

        if (skinId == null) {
            applyAutoSelectedSkinBehavior();
        } else {
            GuiSkinUtils.applyLoadedSkinPreview(dummyPlayer, selectedSkin, false);
        }
        restorePreviewAppearance();
    }

    private void restorePreviewAppearance() {
        if (dummyPlayer == null) return;

        if (selectedCosmetic != null) PersonaManager.setPreviewWithEquipped(dummyPlayer.getUuid(), selectedCosmetic);
        else PersonaManager.setPreviewFromLocal(dummyPlayer.getUuid());
        applySelectedCapePreview();

        if (selectedEmote != null) {
            EmoteManager.play(dummyPlayer.getUuid(), selectedEmote);
        } else if (selectedCosmetic != null
                && parentScreen instanceof SkinSelectionScreen screen
                && screen.getActiveTab() == AppearanceTab.COSMETICS) {
            EmoteManager.playDressingRoom(dummyPlayer.getUuid(), selectedCosmetic.type);
        } else if (selectedCape != null
                && parentScreen instanceof SkinSelectionScreen screen
                && screen.getActiveTab() == AppearanceTab.CAPES) {
            EmoteManager.playDressingRoom(dummyPlayer.getUuid(), "persona_back");
        }
    }

    private void applySelectedCapePreview() {
        if (dummyPlayer == null || selectedCape == null) return;
        if ("none".equals(selectedCape.id)) {
            if (parentScreen instanceof SkinSelectionScreen selectionScreen
                    && "skinpack".equals(selectionScreen.getSelectedCapesCategory())) {
                dummyPlayer.clearForcedCape();
            } else {
                dummyPlayer.setForcedCape(null);
            }
            rotationX = 0.0F;
        } else {
            dummyPlayer.setForcedCape(selectedCape.textureIdentifier);
            rotationX = -220.0F / 3.0F;
        }
    }

    private void applyAutoSelectedSkinBehavior() {
        GuiSkinUtils.applyAutoSelectedPreview(minecraft, dummyPlayer);
    }

    private void applySkin() {
        AppearanceTab activeTab = activeTab();
        if (activeTab == AppearanceTab.COSMETICS) {
            applyCosmetic();
            return;
        }
        if (activeTab == AppearanceTab.CAPES) {
            applyCape();
            return;
        }
        if (activeTab == AppearanceTab.EMOTES) {
            applyEmote();
            return;
        }

        if (selectedSkin == null) return;
        if (ImportSkinAction.is(selectedSkin)) {
            if (parentScreen instanceof SkinSelectionScreen selectionScreen) {
                minecraft.gui.setScreen(new ImportSkinChoiceScreen(selectionScreen));
            }
            return;
        }
        if (MinecraftAccountSkin.is(selectedSkin) || GuiSkinUtils.isSkinCurrentlyEquipped(selectedSkin)) {
            currentSkinId = null;
            GuiSkinUtils.resetSelectedSkin(minecraft);
            selectedSkin = MinecraftAccountSkin.INSTANCE;
            updatePreviewModel(null);
            updateFavoriteButton();
            return;
        }
        SkinManager.setSkin(dummyPlayer.getUuid(), selectedSkin.skinId);
        try {
            GuiSkinUtils.applySelectedSkin(minecraft, selectedSkin);
        } catch (Exception e) {
            LOGGER.error("Failed to apply selected skin", e);
        }
        currentSkinId = selectedSkin.skinId;
        updateFavoriteButton();

    }

    private void applyCosmetic() {
        if (selectedCosmetic == null) return;
        PersonaManager.toggleLocal(selectedCosmetic);
        PersonaManager.setPreviewFromLocal(dummyPlayer.getUuid());
        updateFavoriteButton();
    }

    private void applyEmote() {
        if (selectedEmote == null) return;
        if (parentScreen instanceof SkinSelectionScreen selectionScreen) {
            selectionScreen.openEmoteSlotPicker(selectedEmote);
        }
    }

    private void replaySelectedEmote() {
        if (selectedEmote != null && dummyPlayer != null) {
            EmoteManager.play(dummyPlayer.getUuid(), selectedEmote);
        }
    }

    private void applyCape() {
        if (selectedCape == null) return;

        if (parentScreen instanceof SkinSelectionScreen selectionScreen && "skinpack".equals(selectionScreen.getSelectedCapesCategory())) {
            if (selectedCape.id.equals("none")) {
                SkinManager.setLocalCapeOverride(SkinManager.CAPE_NONE_SKIN_ID);
            } else {
                String prefix = "skinpack:";
                if (selectedCape.id.startsWith(prefix)) {
                    SkinId capeSkinId = SkinId.parse(selectedCape.id.substring(prefix.length()));
                    SkinManager.setLocalCapeOverride(capeSkinId);
                }
            }
            SkinManager.setLocalAccountCapeOverride(null); // Clear account override
            BedrockSessionSkin.clearCache();
            selectionScreen.onCapeChanged(selectedCape.id);
            ClientSkinSync.syncCurrentSkin(minecraft);
            return;
        }

        String token = minecraft.getUser().getAccessToken();
        if (token == null || token.isEmpty() || "0".equals(token) || token.length() < 10) {
            return;
        }

        if (selectButton != null) {
            selectButton.active = false;
            selectButton.setMessage(Component.literal("Equipping..."));
        }

        MinecraftCape capeToEquip = selectedCape;
        CompletableFuture<Void> future;
        if (capeToEquip.id.equals("none")) {
            future = CapeManager.unequipCape(token);
        } else {
            future = CapeManager.equipCape(token, capeToEquip.id);
        }

        future.thenComposeAsync(ignored -> AccountProfileRefresh.refresh(token), minecraft)
            .thenRun(() -> minecraft.execute(() -> {
            SkinManager.setLocalCapeOverride(SkinManager.CAPE_NONE_SKIN_ID);
            if (selectButton != null) {
                selectButton.active = true;
                selectButton.setMessage(Component.translatable("bedrockskins.button.equip"));
            }
            if (capeToEquip.id.equals("none")) {
                SkinManager.setLocalAccountCapeOverride(SkinManager.CAPE_NONE);
            } else {
                SkinManager.setLocalAccountCapeOverride(capeToEquip.textureIdentifier);
            }
            BedrockSessionSkin.clearCache();
            if (parentScreen instanceof SkinSelectionScreen selectionScreen) {
                selectionScreen.onCapeChanged(capeToEquip.id);
            }
            ClientSkinSync.syncCurrentSkin(minecraft);
        })).exceptionally(e -> {
            minecraft.execute(() -> {
                if (selectButton != null) {
                    selectButton.active = true;
                    selectButton.setMessage(Component.translatable("bedrockskins.button.equip"));
                }
                LOGGER.error("Failed to equip cape", e);
            });
            return null;
        });
    }

    private void uploadSkinToMojang() {
        if (!BedrockSkinsConfig.isAccountSkinUploadAllowed() || selectedSkin == null || isUploadingSkin) return;

        String token = minecraft.getUser().getAccessToken();
        if (token == null || token.isEmpty() || "0".equals(token) || token.length() < 10) {
            setUploadStatus(Component.translatable("bedrockskins.status.upload_skin_offline").getString(), true);
            return;
        }

        byte[] textureBytes = ExternalAssetUtil.loadTextureData(selectedSkin, minecraft);
        if (textureBytes.length == 0) {
            setUploadStatus("Failed to read skin texture data.", true);
            return;
        }

        String variant = MojangSkinManager.isSkinSlim(selectedSkin) ? "slim" : "classic";

        isUploadingSkin = true;
        if (uploadSkinButton != null) {
            uploadSkinButton.active = false;
            uploadSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.status.uploading_skin")));
        }
        setUploadStatus(Component.translatable("bedrockskins.status.uploading_skin").getString(), false);

        MojangSkinManager.uploadSkin(token, textureBytes, variant)
            .thenComposeAsync(ignored -> AccountProfileRefresh.refresh(token), minecraft).thenRun(() -> minecraft.execute(() -> {
            isUploadingSkin = false;
            if (uploadSkinButton != null) {
                uploadSkinButton.active = true;
                uploadSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.upload_skin")));
            }
            setUploadStatus(Component.translatable("bedrockskins.status.upload_skin_success").getString(), false);

            GuiSkinUtils.resetSelectedSkin(minecraft);
            selectedSkin = MinecraftAccountSkin.INSTANCE;
            currentSkinId = null;
            updatePreviewModel(null);
            updateActionButtons();
        })).exceptionally(e -> {
            minecraft.execute(() -> {
                isUploadingSkin = false;
                if (uploadSkinButton != null) {
                    uploadSkinButton.active = true;
                    uploadSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.upload_skin")));
                }
                String errorMsg = e.getCause() != null ? e.getCause().getMessage() : e.getMessage();
                setUploadStatus(Component.translatable("bedrockskins.status.upload_skin_failed", errorMsg).getString(), true);
                LOGGER.error("Failed to upload skin to Mojang", e);
            });
            return null;
        });
    }

    private void deleteSelectedSkin() {
        if (!isSelectedImportedSkin() || isDeletingSkin) return;

        LoadedSkin skinToDelete = selectedSkin;
        SkinId deletedId = skinToDelete.skinId;
        isDeletingSkin = true;
        updateActionButtons();

        CompletableFuture.supplyAsync(() -> ExternalAssetUtil.deleteImportedSkinFiles(skinToDelete))
            .thenAccept(deleted -> minecraft.execute(() -> {
                isDeletingSkin = false;
                if (!deleted) {
                    updateActionButtons();
                    return;
                }

                SkinPackLoader.removeLoadedSkin(deletedId);
                if (deletedId.equals(SkinManager.getLocalSelectedKey())) {
                    GuiSkinUtils.resetSelectedSkin(minecraft);
                }
                selectedSkin = null;
                skinSelectedFromGrid = false;
                currentSkinId = null;
                updatePreviewModel(null);
                updateFavoriteButton();
                if (parentScreen instanceof SkinSelectionScreen selectionScreen) {
                    selectionScreen.onResourcesReloaded();
                }
            }))
            .exceptionally(error -> {
                minecraft.execute(() -> {
                    isDeletingSkin = false;
                    updateActionButtons();
                    LOGGER.error("Failed to delete imported skin {}", deletedId, error);
                });
                return null;
            });
    }

    private void setUploadStatus(String message, boolean isError) {
        this.uploadStatusMessage = message;
        this.uploadStatusIsError = isError;
        this.uploadStatusTime = System.currentTimeMillis();
    }

    private void toggleFavorite() {
        if (selectedSkin == null || ImportSkinAction.is(selectedSkin)) return;
        if (FavoritesManager.isFavorite(selectedSkin)) FavoritesManager.removeFavorite(selectedSkin);
        else FavoritesManager.addFavorite(selectedSkin);
        
        updateFavoriteButton();
        if (onFavoritesChanged != null) onFavoritesChanged.run();
    }

    private void updateActionButtons() {
        boolean skinsTab = activeTab() == AppearanceTab.SKINS;
        if (uploadSkinButton != null) {
            boolean uploadable = selectedSkin != null && !MinecraftAccountSkin.is(selectedSkin)
                && !ImportSkinAction.is(selectedSkin);
            uploadSkinButton.active = !isUploadingSkin && uploadable;
            WidgetVisibility.setVisible(uploadSkinButton, skinsTab
                && BedrockSkinsConfig.isAccountSkinUploadAllowed() && uploadable);
        }
        if (deleteSkinButton != null) {
            WidgetVisibility.setVisible(deleteSkinButton, skinsTab && isSelectedImportedSkin());
            deleteSkinButton.active = !isDeletingSkin;
        }
        positionFloatingActionButtons();
    }

    private boolean isSelectedImportedSkin() {
        return skinSelectedFromGrid
            && selectedSkin != null
            && MinecraftAccountSkin.PACK_ID.equals(selectedSkin.packId)
            && !MinecraftAccountSkin.is(selectedSkin)
            && !ImportSkinAction.is(selectedSkin);
    }

    private void updateFavoriteButton() {
        updateActionButtons();
        AppearanceTab activeTab = activeTab();
        if (activeTab == AppearanceTab.COSMETICS) {
            if (selectButton != null) {
                selectButton.active = selectedCosmetic != null;
                boolean equipped = PersonaManager.isLocallyEquipped(selectedCosmetic);
                selectButton.setMessage(Component.translatable(equipped
                    ? "bedrockskins.button.unequip" : "bedrockskins.button.equip"));
            }
            return;
        }
        if (activeTab == AppearanceTab.CAPES) {
            if (selectButton != null) selectButton.active = selectedCape != null;
            return;
        }
        if (activeTab == AppearanceTab.EMOTES) {
            if (selectButton != null) {
                selectButton.active = selectedEmote != null;
                selectButton.setMessage(Component.translatable("bedrockskins.button.equip"));
            }
            if (replayEmoteButton != null) replayEmoteButton.active = selectedEmote != null;
            return;
        }

        if (favoriteButton == null) return;

        boolean virtualSkin = ImportSkinAction.is(selectedSkin);
        boolean isFav = !virtualSkin && FavoritesManager.isFavorite(selectedSkin);
        favoriteButton.setSelected(isFav);
        favoriteButton.setActive(!virtualSkin && selectedSkin != null);
        favoriteButton.setTooltip(Component.translatable(isFav ? "bedrockskins.button.unfavorite" : "bedrockskins.button.favorite"));

        if (selectButton != null) {
            boolean enabled = selectedSkin != null;
            boolean unequip = selectedSkin != null && !MinecraftAccountSkin.is(selectedSkin)
                && !ImportSkinAction.is(selectedSkin) && GuiSkinUtils.isSkinCurrentlyEquipped(selectedSkin);
            if (enabled && !unequip && BedrockSkinsClient.blockUnfairSkins && selectedSkin.unfair) enabled = false;
            selectButton.active = enabled;
            selectButton.setMessage(Component.translatable(ImportSkinAction.is(selectedSkin)
                ? "bedrockskins.button.add_custom_skin"
                : unequip ? "bedrockskins.button.unequip" : "bedrockskins.button.equip"));
        }
    }

    public void renderPreview(GuiGraphicsExtractor gui, int mouseX) {
        int contentTop = previewTop;
        int contentBottom = previewBottom;
        int centerX = x + width / 2;
        AppearanceTab activeTab = activeTab();

        int rotateW = Math.clamp((int)(width * 0.3f), 30, 90);
        int rotateH = (int)Math.ceil(rotateW * (7.0f / 45.0f));

        if (dummyPlayer != null) {
            if (currentSkinId == null && (selectedSkin == null || MinecraftAccountSkin.is(selectedSkin))) {
                applyAutoSelectedSkinBehavior();
            }
            if (selectedCape != null) {
                if (selectedCape.id.equals("none")) {
                    if (parentScreen instanceof SkinSelectionScreen selectionScreen && "skinpack".equals(selectionScreen.getSelectedCapesCategory())) {
                        dummyPlayer.clearForcedCape();
                    } else {
                        dummyPlayer.setForcedCape(null);
                    }
                } else {
                    dummyPlayer.setForcedCape(selectedCape.textureIdentifier);
                }
            }
            if (isDraggingPreview) {
                rotationX -= (mouseX - lastMouseX) * 0.5f;
            }
            lastMouseX = mouseX;

            String nameToRender = null;
            String descToRender = null;

            if (activeTab == AppearanceTab.COSMETICS) {
                if (selectedCosmetic != null) {
                    nameToRender = selectedCosmetic.displayName;
                    descToRender = PersonaTypeNames.displayName(selectedCosmetic.type).getString();
                }
            } else if (activeTab == AppearanceTab.CAPES) {
                if (selectedCape != null) {
                    nameToRender = Component.translatable(selectedCape.alias).getString();
                    descToRender = Component.translatable("bedrockskins.capes.description").getString();
                }
            } else if (activeTab == AppearanceTab.EMOTES) {
                if (selectedEmote != null) {
                    nameToRender = selectedEmote.displayName();
                    descToRender = Component.translatable("bedrockskins.emotes.description").getString();
                }
            } else {
                if (selectedSkin != null) {
                    nameToRender = GuiSkinUtils.getSkinDisplayNameText(selectedSkin);
                    descToRender = GuiSkinUtils.getSkinDescriptionText(selectedSkin).orElse(null);
                }
            }

            int modelAreaHeight = Math.max(0, contentBottom - contentTop);
            int scale = Math.max((int)(modelAreaHeight * 0.48f), 20);
            int centerY = contentTop + (modelAreaHeight / 2) - (rotateH / 2);

            renderRotatableEntity(gui, centerX, centerY, width - 16, modelAreaHeight, scale, dummyPlayer);

            int rotateY = Math.min((int)(centerY + (scale * 0.95f)), contentBottom - rotateH - 2);
            gui.blitSprite(RenderPipelines.GUI_TEXTURED, BedrockSkinsSprites.ROTATE_SPRITE, centerX - (rotateW / 2), rotateY, rotateW, rotateH);

            if (uploadStatusMessage != null && System.currentTimeMillis() - uploadStatusTime < 4500) {
                int statusColor = uploadStatusIsError ? 0xFFFF5555 : 0xFF55FF55;
                gui.centeredText(font, Component.literal(uploadStatusMessage), centerX, contentTop + 4, statusColor);
            }

            renderInfoPanel(gui, nameToRender, descToRender);
        }
    }

    private void renderInfoPanel(GuiGraphicsExtractor gui, String name, String description) {
        GuiUtils.drawPanelChrome(gui, x, infoPanelY, width, INFO_PANEL_HEIGHT, Component.empty(), font);

        int textY = infoPanelY
            + Math.max(0, (GuiUtils.PANEL_HEADER_HEIGHT - font.lineHeight) / 2);
        int availableWidth = Math.max(0, width - 16);
        boolean hasName = name != null && !name.isEmpty();
        boolean hasDescription = description != null && !description.isEmpty();
        int descriptionWidth = hasName && hasDescription
            ? Math.min(font.width(description), Math.max(0, (availableWidth - 8) / 2))
            : availableWidth;
        int nameWidth = hasName && hasDescription
            ? Math.max(0, availableWidth - descriptionWidth - 8)
            : availableWidth;

        if (hasName) {
            String fittedName = fitText(name, nameWidth);
            gui.text(font, Component.literal(fittedName), x + 8, textY, 0xFFFFFFFF, false);
        }
        if (hasDescription) {
            String fittedDescription = fitText(description, descriptionWidth);
            gui.text(font, Component.literal(fittedDescription),
                x + width - 8 - font.width(fittedDescription), textY, 0xFFAAAAAA, false);
        }
    }

    private String fitText(String text, int maxWidth) {
        if (text == null || maxWidth <= 0) return "";
        if (font.width(text) <= maxWidth) return text;
        String ellipsis = "...";
        int targetWidth = Math.max(0, maxWidth - font.width(ellipsis));
        int end = text.length();
        while (end > 0 && font.width(text.substring(0, end)) > targetWidth) end--;
        return text.substring(0, end) + ellipsis;
    }
    
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        AppearanceTab activeTab = activeTab();
        if (activeTab == AppearanceTab.COSMETICS && PersonaManager.isSideSelectable(selectedCosmetic)
                && mouseY < y + 52) return false;
        if ((button == 0 || button == InputConstants.MOUSE_BUTTON_LEFT) && mouseX >= previewLeft && mouseX <= previewRight && mouseY >= previewTop && mouseY <= previewBottom) {
            isDraggingPreview = true;
            return true;
        }
        return false;
    }
    
    public boolean mouseReleased(int button) {
        if ((button == 0 || button == InputConstants.MOUSE_BUTTON_LEFT) && isDraggingPreview) {
            isDraggingPreview = false;
            return true;
        }
        return false;
    }
    
    private void renderRotatableEntity(GuiGraphicsExtractor gui, int centerX, int centerY, int boxWidth, int boxHeight, int scale, PreviewPlayer entity) {
        int halfW = boxWidth / 2, halfH = boxHeight / 2;
        GuiUtils.renderEntityInRect(gui, entity, rotationX * 3, centerX - halfW, centerY - halfH, centerX + halfW, centerY + halfH, scale);
    }
    
    public void updateButtonsForTab(AppearanceTab tabIndex) {
        reposition(x, y, width, height);
        this.rotationX = tabIndex == AppearanceTab.CAPES ? -220.0F / 3.0F : 0.0F;
        if (replayEmoteButton != null) WidgetVisibility.setVisible(replayEmoteButton, tabIndex == AppearanceTab.EMOTES);
        if (favoriteButton != null) WidgetVisibility.setVisible(favoriteButton.getButton(), tabIndex == AppearanceTab.SKINS);
        if (selectButton != null) {
            selectButton.setMessage(Component.translatable("bedrockskins.button.equip"));
            if (tabIndex == AppearanceTab.EMOTES) {
                int gap = 4;
                int actionX = x + 8;
                int actionWidth = Math.max(10, width - 16);
                int halfWidth = Math.max(10, (actionWidth - gap) / 2);
                selectButton.setX(actionX);
                selectButton.setWidth(halfWidth);
                if (replayEmoteButton != null) {
                    replayEmoteButton.setX(actionX + halfWidth + gap);
                    replayEmoteButton.setWidth(Math.max(10, actionWidth - halfWidth - gap));
                }
            }
        }
        updateFavoriteButton();
    }

    public void renderSprites(GuiGraphicsExtractor gui) {
        if (favoriteButton != null) favoriteButton.renderSprites(gui);
    }

    public void cleanup() {
        if (this.dummyPlayer != null) this.dummyPlayer.close();
        this.dummyPlayer = null;
    }
    
    private static class FavoriteHeartButton {
        private final SpriteIconButton button;
        private final Identifier fullSprite;
        private boolean isFavorited = false;

        public FavoriteHeartButton(int size, Identifier containerSprite, Identifier fullSprite, Button.OnPress onPress) {
            this.fullSprite = fullSprite;
            this.button = SpriteIconButton.builder(Component.empty(), onPress, true)
                    .size(size, size).sprite(containerSprite, 12, 12).build();
        }

        public AbstractWidget getButton() { return button; }
        public void setSelected(boolean selected) { this.isFavorited = selected; }
        public void setActive(boolean active) { button.active = active; }
        public void setTooltip(Component tooltip) { button.setTooltip(Tooltip.create(tooltip)); }

        public void renderSprites(GuiGraphicsExtractor graphics) {
            if (WidgetVisibility.isVisible(button) && isFavorited) {
                graphics.blitSprite(RenderPipelines.GUI_TEXTURED, fullSprite, button.getX() + 4, button.getY() + 4, 12, 12);
            }
        }
    }
}
