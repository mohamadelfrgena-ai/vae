package io.github.brandonitaly.bedrockskins.mixin.render;

import net.minecraft.client.model.geom.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

@Mixin(ModelPart.class)
public interface ModelPartAccessor {
    @Accessor("cubes")
    List<ModelPart.Cube> bedrockSkins$getCubes();

    @Accessor("children")
    java.util.Map<String, ModelPart> bedrockSkins$getChildren();
}
