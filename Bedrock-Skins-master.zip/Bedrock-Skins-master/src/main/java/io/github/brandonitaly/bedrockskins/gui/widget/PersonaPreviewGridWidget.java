package io.github.brandonitaly.bedrockskins.gui.widget;

import io.github.brandonitaly.bedrockskins.gui.preview.GuiSkinUtils;
import io.github.brandonitaly.bedrockskins.gui.preview.GuiUtils;
import io.github.brandonitaly.bedrockskins.gui.preview.PreviewPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import io.github.brandonitaly.bedrockskins.util.BedrockSkinsSprites;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Shared preview and lifecycle behavior for Persona cosmetic and emote grids. */
abstract class PersonaPreviewGridWidget<T>
        extends CardGridWidget<PersonaPreviewGridWidget.PreviewCell<T>> {
    private static final int CELL_WIDTH = 60;
    private final Consumer<T> onSelect;
    private final Supplier<T> selected;
    private final Font font;

    PersonaPreviewGridWidget(Minecraft client, int width, int height, int y, int itemHeight,
                             int cellHeight, Consumer<T> onSelect, Supplier<T> selected, Font font) {
        super(client, width, height, y, itemHeight, CELL_WIDTH, cellHeight);
        this.onSelect = onSelect;
        this.selected = selected;
        this.font = font;
    }

    protected abstract String id(T value);
    protected abstract Component name(T value);
    protected abstract void initializePreview(PreviewPlayer player, T value);
    protected void initializePlayerAppearance(T value, PreviewPlayer player) {
        GuiSkinUtils.applyCurrentEquippedSkin(Minecraft.getInstance(), player);
    }
    protected void beforeRender(PreviewPlayer player, T value) {}
    protected void renderOverlay(T value, GuiGraphicsExtractor graphics, int x, int y) {}
    protected boolean isEquipped(T value) { return false; }
    protected void renderPaperDoll(T value, PreviewPlayer preview, GuiGraphicsExtractor graphics,
                                   int x, int y, int width, int height) {
        GuiUtils.renderGridEntityInRect(graphics, preview, 0.0F,
            x + 1, y + 1, x + width - 1, y + height - 1);
    }

    protected final void addValuesRow(List<T> values) {
        addCellsRow(values.stream().map(PreviewCell::new).toList());
    }

    @Override
    protected final void renderCell(PreviewCell<T> cell, GuiGraphicsExtractor graphics, int x, int y,
                                    boolean hovered, int mouseX, int mouseY) {
        PreviewPlayer preview = cell.player(this);
        beforeRender(preview, cell.value);
        T current = selected.get();
        boolean valueSelected = current != null && id(current).equals(id(cell.value));
        var cardSprite = valueSelected ? BedrockSkinsSprites.CARD_SELECTED
            : hovered ? BedrockSkinsSprites.CARD_HOVER : BedrockSkinsSprites.CARD_IDLE;
        graphics.blitSprite(RenderPipelines.GUI_TEXTURED, cardSprite,
            x, y, cellWidth(), cellHeight());
        renderPaperDoll(cell.value, preview, graphics, x, y, cellWidth(), cellHeight());
        if (isEquipped(cell.value)) {
            graphics.blitSprite(RenderPipelines.GUI_TEXTURED, GuiUtils.EQUIPPED_BORDER,
                x, y, cellWidth(), cellHeight());
        }
        if (hovered) graphics.setTooltipForNextFrame(font, name(cell.value), mouseX, mouseY);
        renderOverlay(cell.value, graphics, x, y);
    }

    @Override
    protected final boolean clickCell(PreviewCell<T> cell, MouseButtonEvent click, boolean doubled) {
        onSelect.accept(cell.value);
        GuiUtils.playButtonClickSound();
        return true;
    }

    @Override
    protected final void cleanupCell(PreviewCell<T> cell) {
        if (cell.player == null) return;
        cell.player.close();
        cell.player = null;
    }

    protected static final class PreviewCell<T> {
        private final T value;
        private PreviewPlayer player;
        private PreviewCell(T value) { this.value = value; }

        private PreviewPlayer player(PersonaPreviewGridWidget<T> grid) {
            if (player == null) {
                player = new PreviewPlayer("");
                grid.initializePlayerAppearance(value, player);
                grid.initializePreview(player, value);
            }
            return player;
        }
    }
}
