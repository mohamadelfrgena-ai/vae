package io.github.brandonitaly.bedrockskins.gui.preview;

import io.github.brandonitaly.bedrockskins.client.appearance.skin.ClientSkinSync;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.SkinManager;
import io.github.brandonitaly.bedrockskins.pack.model.LoadedSkin;
import io.github.brandonitaly.bedrockskins.pack.model.SkinId;
import io.github.brandonitaly.bedrockskins.pack.loader.SkinPackLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.MojangSkinManager;
import io.github.brandonitaly.bedrockskins.client.persistence.StateManager;

import java.util.Objects;
import java.util.Optional;

public final class GuiSkinUtils {

    private GuiSkinUtils() {}

    public static String translatedOrFallback(String translationKey, String fallback) {
        String translated = SkinPackLoader.getTranslation(translationKey);
        return translated != null ? translated : fallback;
    }

    public static String getSkinDisplayNameText(LoadedSkin skin) {
        return skin == null ? "" : translatedOrFallback(skin.safeSkinName, skin.skinDisplayName);
    }

    public static Optional<String> getSkinDescriptionText(LoadedSkin skin) {
        if (skin == null) return Optional.empty();
        String description = translatedOrFallback(skin.safeSkinName + ".description", "");
        return description.isEmpty() ? Optional.empty() : Optional.of(description);
    }

    public static String getPackDisplayName(String packId) {
        return translatedOrFallback(packId, packId);
    }

    public static boolean isSkinCurrentlyEquipped(LoadedSkin skin) {
        if (MinecraftAccountSkin.is(skin)) return SkinManager.getLocalSelectedKey() == null;
        if (ImportSkinAction.is(skin)) return false;
        return Objects.equals(SkinManager.getLocalSelectedKey(), skin != null ? skin.skinId : null);
    }

    public static void applySelectedSkin(Minecraft minecraft, LoadedSkin skin) throws Exception {
        if (skin == null) return;

        SkinId skinId = skin.skinId != null ? skin.skinId : SkinId.of(skin.serializeName, skin.skinDisplayName);
        SkinManager.setLocalSkin(skinId);
        if (minecraft.player != null) {
            ClientSkinSync.syncCurrentSkin(minecraft);
            minecraft.player.refreshDimensions();
        }
    }

    public static void resetSelectedSkin(Minecraft minecraft) {
        if (minecraft.player != null) {
            SkinManager.resetSkin(minecraft.player.getUUID());
            ClientSkinSync.sendResetSkinPayload();
            minecraft.player.refreshDimensions();
        } else {
            StateManager.updateSelectedSkin(null);
        }
    }

    public static void applyAutoSelectedPreview(Minecraft minecraft, PreviewPlayer previewPlayer) {
        if (previewPlayer == null) return;
        
        SkinManager.resetPreviewSkin(previewPlayer.getUuid());
        previewPlayer.clearForcedBody();
        previewPlayer.clearForcedModel();
        SkinId capeOverrideId = SkinManager.getLocalCapeOverride();
        Identifier capeId = null;
        if (capeOverrideId != null) {
            var capeSkin = SkinPackLoader.getLoadedSkin(capeOverrideId);
            if (capeSkin != null) {
                capeId = capeSkin.capeIdentifier;
            }
        }
        if (capeId != null) {
            previewPlayer.setForcedCape(capeId);
        } else {
            previewPlayer.clearForcedCape();
        }
        refreshAutoSelectedProfileSkin(minecraft, previewPlayer);
    }

    public static void refreshAutoSelectedProfileSkin(Minecraft minecraft, PreviewPlayer previewPlayer) {
        if (previewPlayer == null) return;
        
        PlayerSkin sessionSkin = BedrockSessionSkin.getSessionPlayerSkin();
        if (sessionSkin != null) {
            previewPlayer.setForcedProfileSkin(sessionSkin);
            previewPlayer.setForcedModel(sessionSkin.model());
            return;
        }

        var profile = minecraft.getGameProfile();
        if (profile != null) {
            PlayerSkin skin = minecraft.getSkinManager().createLookup(profile, false).get();
            previewPlayer.setForcedProfileSkin(skin);
            if (skin != null) {
                previewPlayer.setForcedModel(skin.model());
            }
        }
    }

    public static void applyLoadedSkinPreview(PreviewPlayer previewPlayer, LoadedSkin skin) {
        applyLoadedSkinPreview(previewPlayer, skin, true);
    }

    public static void applyLoadedSkinPreview(PreviewPlayer previewPlayer, LoadedSkin skin, boolean ignoreCapeOverrides) {
        if (previewPlayer == null) return;
        var previewUuid = previewPlayer.getUuid();

        if (MinecraftAccountSkin.is(skin)) {
            applyAutoSelectedPreview(Minecraft.getInstance(), previewPlayer);
            return;
        }

        previewPlayer.clearForcedProfileSkin();
        previewPlayer.clearForcedBody();
        if (skin != null) {
            boolean slim = MojangSkinManager.isSkinSlim(skin);
            previewPlayer.setForcedModel(slim ? PlayerModelType.SLIM : PlayerModelType.WIDE);
        } else {
            previewPlayer.clearForcedModel();
        }

        if (skin == null) {
            SkinManager.resetPreviewSkin(previewUuid);
            previewPlayer.setForcedCape(null);
            return;
        }

        if (skin.skinId != null) {
            SkinManager.setPreviewSkin(previewUuid, skin.skinId.pack(), skin.skinId.name());
            SkinPackLoader.registerTextureFor(skin.skinId);
            previewPlayer.setForcedBody(skin.identifier);
        }
        
        Identifier resolved = SkinManager.resolveCape(skin, !ignoreCapeOverrides);
        if (resolved == null && !ignoreCapeOverrides) {
            previewPlayer.clearForcedCape();
        } else {
            previewPlayer.setForcedCape(SkinManager.CAPE_NONE.equals(resolved) ? null : resolved);
        }
    }

    public static void applyCurrentEquippedSkin(Minecraft minecraft, PreviewPlayer previewPlayer) {
        if (previewPlayer == null) return;
        SkinId currentKey = SkinManager.getLocalSelectedKey();
        if (currentKey != null) {
            LoadedSkin skin = SkinPackLoader.getLoadedSkin(currentKey);
            if (skin != null) {
                applyLoadedSkinPreview(previewPlayer, skin, false);
                return;
            }
        }
        applyAutoSelectedPreview(minecraft, previewPlayer);
    }
}
