package io.github.brandonitaly.bedrockskins.gui.screen;

import io.github.brandonitaly.bedrockskins.gui.preview.*;
import io.github.brandonitaly.bedrockskins.gui.widget.*;

import io.github.brandonitaly.bedrockskins.client.persistence.BedrockSkinsConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

public class BedrockSkinsConfigScreen extends OptionsSubScreen {
    public BedrockSkinsConfigScreen(Screen previous) {
        super(previous, Minecraft.getInstance().options, Component.translatable("bedrockskins.gui.mod_options"));
    }

    @Override
    protected void addOptions() {
        if (this.list != null) {
            this.list.addSmall(BedrockSkinsConfig.asOptions());
        }
    }

    @Override
    protected void addFooter() {
        LinearLayout footer = this.layout.addToFooter(LinearLayout.horizontal().spacing(8));

        footer.addChild(Button.builder(Component.translatable("dataPack.validation.reset"), (button) -> {
            BedrockSkinsConfig.resetToDefault();
            this.minecraft.gui.setScreen(new BedrockSkinsConfigScreen(this.lastScreen));
        }).build());

        footer.addChild(Button.builder(CommonComponents.GUI_DONE, (button) -> {
            this.minecraft.gui.setScreen(this.lastScreen);
        }).build());
    }
}
