package io.github.brandonitaly.bedrockskins.gui.preview;

import io.github.brandonitaly.bedrockskins.client.render.model.BedrockModelManager;
import io.github.brandonitaly.bedrockskins.client.render.model.BedrockPlayerModel;
import io.github.brandonitaly.bedrockskins.client.appearance.persona.PersonaManager;
import io.github.brandonitaly.bedrockskins.client.appearance.skin.SkinManager;
import io.github.brandonitaly.bedrockskins.gui.screen.SkinSelectionScreen;
import io.github.brandonitaly.bedrockskins.gui.WidgetVisibility;
import io.github.brandonitaly.bedrockskins.pack.model.SkinId;
import io.github.brandonitaly.bedrockskins.util.BedrockSkinsSprites;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.PlainTextButton;
import net.minecraft.client.gui.components.SpriteIconButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
//? if <=26.2 {
import org.lwjgl.glfw.GLFW;
//?}
import net.minecraft.network.chat.Component;

public class PaperDollWidget extends AbstractWidget {
    public static final int PREVIEW_W = 78;
    public static final int PREVIEW_H = 112;
    public static final int BTN_SIZE = 20;
    private static final int RENDER_PADDING_TOP = 14;
    private static final int SIZE_CAP = 56;
    private static final double Y_TRANSLATION = 0.9;
    private static final double PLAYER_HEIGHT_BLOCKS = 1.8;
    private static final int SPACER = 8;

    private PreviewPlayer previewPlayer;
    private final SpriteIconButton openSkinButton;

    private float previewYaw = 0.0F;
    private boolean draggingPreview = false;
    private boolean leftMouseDown = false;
    private double lastRotMouseX = 0.0;

    public PaperDollWidget(Screen parentScreen) {
        super(getDefaultLeft(parentScreen, parentScreen.width), getDefaultTop(parentScreen, parentScreen.height),
            PREVIEW_W, PREVIEW_H + BTN_SIZE + SPACER, Component.translatable("bedrockskins.button.wardrobe.tooltip"));

        Minecraft minecraft = Minecraft.getInstance();
        String name = minecraft.getGameProfile() != null ? minecraft.getGameProfile().name() : "Preview";
        this.previewPlayer = new PreviewPlayer(name);
        this.previewPlayer.setShowNameTag(true);
        updatePreviewSkin(minecraft);
        PersonaManager.setPreviewFromLocal(this.previewPlayer.getUuid());

        this.openSkinButton = SpriteIconButton.builder(
            Component.empty(),
            b -> minecraft.gui.setScreen(new SkinSelectionScreen(parentScreen)),
            true
        )
        .size(BTN_SIZE, BTN_SIZE)
        .sprite(BedrockSkinsSprites.WARDROBE_ICON, 16, 16)
        .build();
        this.openSkinButton.setTooltip(Tooltip.create(Component.translatable("bedrockskins.button.wardrobe.tooltip")));
    }

    static AbstractWidget findMenuTargetButton(Iterable<? extends GuiEventListener> children) {
        AbstractWidget target = null;
        for (var child : children) {
            if (!(child instanceof Button widget) || !WidgetVisibility.isVisible(widget)) continue;
            if (widget instanceof PlainTextButton
                || (widget instanceof SpriteIconButton && widget.getWidth() <= BTN_SIZE)) continue;
            if (target == null || widget.getY() > target.getY()
                || (widget.getY() == target.getY() && widget.getX() > target.getX())) {
                target = widget;
            }
        }
        return target;
    }

    public static int getDefaultLeft(Screen parentScreen, int width) {
        AbstractWidget target = findMenuTargetButton(parentScreen.children());
        return target != null ? target.getX() + target.getWidth() + 20
            : Math.round((float) (width * 5 / 6.0 - PREVIEW_W / 2.0));
    }

    public static int getDefaultTop(Screen parentScreen, int height) {
        AbstractWidget target = findMenuTargetButton(parentScreen.children());
        return target != null ? target.getY() + target.getHeight() - 115
            : Math.round((float) (height / 2.0 - PREVIEW_H / 2.0));
    }

    private int getModelSize() {
        return Math.min((PREVIEW_H + RENDER_PADDING_TOP) / 3, SIZE_CAP);
    }

    private double getModelFeet(int top) {
        double centerY = top + (PREVIEW_H - RENDER_PADDING_TOP) / 2.0;
        return centerY + Y_TRANSLATION * getModelSize();
    }

    private double getModelTop(int top) {
        float heightMultiplier = 1.0f;
        SkinId selected = SkinManager.getLocalSelectedKey();
        if (selected != null) {
            BedrockPlayerModel model = BedrockModelManager.getModel(selected);
            if (model != null) heightMultiplier = model.heightMultiplier;
        }
        return getModelFeet(top) - (PLAYER_HEIGHT_BLOCKS * getModelSize() * heightMultiplier);
    }

    private void updatePreviewSkin(Minecraft minecraft) {
        GuiSkinUtils.applyCurrentEquippedSkin(minecraft, previewPlayer);
    }

    private boolean isMouseOverModel(int mouseX, int mouseY) {
        int left = this.getX();
        int top = this.getY();
        return mouseX >= left && mouseX <= left + PREVIEW_W
            && mouseY >= top && mouseY <= top + PREVIEW_H;
    }

    //~ if >=26.1 'renderWidget' -> 'extractWidgetRenderState' {
    @Override
    //? if >=26.4-snapshot-5 {
    /*protected void extractWidgetRenderState(GuiGraphicsExtractor guiGraphics) {
        int mouseX = guiGraphics.mouseX();
        int mouseY = guiGraphics.mouseY();
    *///?} else {
    protected void extractWidgetRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float delta) {
    //?}
    //~}
        if (this.previewPlayer == null) return;

        // The paper doll uses a synthetic UUID, so keep its Persona preview bound
        // to the persisted local loadout rather than a world-only player entity.
        PersonaManager.setPreviewFromLocal(this.previewPlayer.getUuid());

        Minecraft minecraft = Minecraft.getInstance();
        if (SkinManager.getLocalSelectedKey() == null) {
            GuiSkinUtils.refreshAutoSelectedProfileSkin(minecraft, this.previewPlayer);
        }

        //? if >26.2 {
        /*boolean leftDown = (org.lwjgl.sdl.SDLMouse.SDL_GetMouseState((java.nio.FloatBuffer) null, (java.nio.FloatBuffer) null) & org.lwjgl.sdl.SDLMouse.SDL_BUTTON_LMASK) != 0;*/
        //?} else {
        long window = minecraft.getWindow().handle();
        boolean leftDown = window != 0L && GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        //?}

        if (leftDown && !this.leftMouseDown && isMouseOverModel(mouseX, mouseY)) {
            this.draggingPreview = true;
            this.lastRotMouseX = mouseX;
        }
        this.leftMouseDown = leftDown;
        if (!leftDown) this.draggingPreview = false;

        if (this.draggingPreview) {
            this.previewYaw -= (float) (mouseX - this.lastRotMouseX) * 1.6F;
            this.lastRotMouseX = mouseX;
        }

        int left = this.getX();
        int top = this.getY();

        GuiUtils.renderEntityInRect(guiGraphics, this.previewPlayer, this.previewYaw, left - 40, top - RENDER_PADDING_TOP, left + PREVIEW_W + 40, top + PREVIEW_H, SIZE_CAP);

        if (this.previewPlayer.shouldShowName()) {
            Font font = minecraft.font;
            int nametagTopY = (int) Math.round(getModelTop(top) - SPACER - font.lineHeight);
            GuiUtils.renderNameTag(guiGraphics, font, this.previewPlayer.getDisplayName(), left + (PREVIEW_W / 2), Math.max(2, nametagTopY));
        }

        this.openSkinButton.setX(left + (PREVIEW_W - BTN_SIZE) / 2);
        this.openSkinButton.setY((int) Math.round(getModelFeet(top) + SPACER));
        //~ if >=26.1 'render' -> 'extractRenderState' {
        //? if >=26.4-snapshot-5 {
        /*this.openSkinButton.extractRenderState(guiGraphics);
        *///?} else {
        this.openSkinButton.extractRenderState(guiGraphics, mouseX, mouseY, delta);
        //?}
        //~}
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
        if (!this.visible || !this.active) return false;
        return this.openSkinButton.mouseClicked(click, doubled) || this.isMouseOver(click.x(), click.y());
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narrationElementOutput) {
        narrationElementOutput.add(NarratedElementType.TITLE, Component.translatable("bedrockskins.button.wardrobe.tooltip"));
    }

    public void removed() {
        if (this.previewPlayer != null) {
            this.previewPlayer.close();
            this.previewPlayer = null;
        }
    }
}
