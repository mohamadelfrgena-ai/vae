AddonStation phone app: addon page, stat icons, store cards and "Link a PS4 console"

AddonStation_phone_design.html          open in a browser (Dark/Light, English/Arabic, all states)
SPEC_PHONE_ITEM_AND_PS4_LINK.md         the specification (give this to the Android Studio agent)
captures/sheet_01..06.jpg               every screen and state
icons/*.svg                             the stat icons (Android Studio: New > Vector Asset > Local file)

Added: addon page state "Needs Legendary plan" (gold card + gold button with a crown), same design as "Needs plan" (Epic). See captures/sheet_07.jpg.
