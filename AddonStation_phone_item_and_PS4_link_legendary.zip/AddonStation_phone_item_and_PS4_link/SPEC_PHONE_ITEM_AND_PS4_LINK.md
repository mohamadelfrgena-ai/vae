# AddonStation phone app: new addon page, stat icons, store cards, and "Link a PS4 console"

Open `AddonStation_phone_design.html` next to this file (pick a screen, switch Dark/Light and English/Arabic). `captures/` has every screen and state. `icons/` has the stat icons as SVG (Android Studio: *New → Vector Asset → Local file (SVG)*).

> **For the AI agent in Android Studio:** implement the screens in sections 2–4 in the existing Compose code (keep the current theme tokens, fonts, bottom bar and repositories). Sections 5–6 add a new feature that needs new server code (section 6.4); build the UI first against the contract in 6.4 and ask the owner for the server part. Do not change anything not mentioned here.

## 1. What changed
1. **Addon (download) page** redesigned: cover with floating buttons, title, creator row, **stat tiles with new icons** (downloads, views, rating, size), info chips, description card, similar content, and a **sticky action bar** that changes with the state (10 states).
2. **Store cards** redesigned with the same icons, badges and a save heart.
3. **Stat icon set** (replaces the emoji-style icons for downloads and views).
4. **Settings → new "Devices" section** with **Link a PS4 console** and **Consoles** (list/unlink).

## 2. Stat icons (replace the emoji icons)
| Meaning | Icon | Color | File |
|---|---|---|---|
| Downloads | tray + arrow | `#6FA8FF` | `ic_stat_downloads.svg` |
| Views | eye | `#4FD1C5` | `ic_stat_views.svg` |
| Rating | filled star | `#F0C25E` | `ic_stat_rating.svg` |
| Favorites | heart | `#FF7A9A` | `ic_stat_favorites.svg` |
| File size | document | `#9DB0CF` | `ic_stat_size.svg` |
| Version | tag | `#7FD99A` | `ic_stat_version.svg` |
| Added (date) | clock | `#B79BFF` | `ic_stat_added.svg` |
| Saved folder | folder | `#6FA8FF` | `ic_stat_folder.svg` |
Rules: 24 dp grid, 2 dp round stroke; **never emoji** (they differ per phone). Sizes: **14 dp** in card chips, **20 dp** inside a 36 dp tinted rounded square (radius 12, color = icon color at 18% opacity) in the stat tiles, 28 dp in headers.
**Numbers:** 1,240 → `1.2K`, 12,500 → `12K`, 1,200,000 → `1.2M`; under 1,000 show the full number. Arabic uses Arabic-Indic digits and the unit "ألف / م" (see the Arabic previews). File size: `28 MB` / `٢٨ م.ب`.

## 3. Store cards (list screen)
Header: logo 44, title (pixel font 26), AC pill. Search 50 high, segmented Addons | Worlds, sort chips. Grid **2 columns, gap 12**.
Card (radius 18, surface + 1 dp border): padding 8; **cover** 98 high (radius 12, soft top/bottom shade) with **badge top-start** and **save heart top-end** (28 dp glass circle; filled pink when saved); **NEW** chip bottom-start (shown when `created_at` < 14 days); title 14 sp/800, 2 lines; creator row (avatar 18 + name 11 sp, blue); **stat row**: downloads, views, rating (rating only if `rating_count` > 0).
Badges (from `plan` and `ac_price`): **Free** green `#2FAE63`; **Epic** purple `#9B6BFF` with gem; **Legendary** gold `#F0C25E` (dark text) with crown; **AC price** dark glass with coin + price when the item is unlocked with AC.

## 4. Addon (download) page
### 4.1 Layout (top to bottom, 390 dp wide reference)
1. **Cover** 262 dp high, bottom corners 28, shade top and bottom. Floating glass circles (42 dp): **back** (start), **share** and **save heart** (end). Bottom-start **type chip** ("ADD-ON" / "WORLD", from `content_type`); bottom-end **access badge** (Free / Epic / Legendary / coin + AC price).
2. **Title** (pixel font 26 sp, up to 2 lines) then **creator row**: avatar 40 (gold ring) + name + verified tick + "Creator" + "Profile ›" (opens the creator profile).
3. **Stat card** (radius 20): four equal columns with 1 dp dividers: **Downloads** (`downloads_count`), **Views** (`views_count`), **Rating** (`rating`, caption "`rating_count` ratings"), **Size** (`file_size`). Each: 36 dp icon tile, value 16 sp/800, caption 11 sp muted.
4. **State note** (only in some states, see 4.2) directly under the stats.
5. **Info chips** (scroll, height 32): `v{version}`, "Added {created_at}", `category`, "Bedrock" (fixed: the store is Bedrock-only).
6. **Description card** (radius 20, label with icon, 14 sp, "Read more" after 4 lines).
7. **Similar content** (horizontal cards 132 dp wide: cover, title, downloads + views).
8. **Sticky action bar** (bottom, gradient fade into the background, padding 16, button height **56 dp**, radius 18): main button (flex 1) + 56 dp square secondary button.
### 4.2 States (what the bar and note show)
| State | When (existing app logic) | Note under the stats | Main button | Secondary |
|---|---|---|---|---|
| **Free** | access OK, nothing to pay | none | **Download** (blue gradient) | Save (heart) |
| **Paid with AC** | `plan` free/any but needs `ac_price` and not unlocked | "Your balance: 190 AC. After unlocking: 40 AC." (gold) | **Unlock with AC · 150** (gold) | Save |
| **Needs a plan (Epic)** | `RequiresEpic` | purple card "Requires the Epic plan / Your plan: Free…" | **Upgrade to Epic** (purple, gem) → plans screen | Save |
| **Needs a plan (Legendary)** | `RequiresLegendary` | gold card "Requires the Legendary plan / Your plan: Free…" (same layout as the Epic card) | **Upgrade to Legendary** (gold gradient, dark text, **crown** icon) → plans screen | Save |
| **Signed out** | `RequiresLogin` | "Create a free account to download and save addons." | **Sign in to download** (outlined) | Save |
| **Downloading** | download running | "12.4 / 28 MB · You can leave this screen" | progress bar button "Downloading… 62%" (uses `item_download_progress`) | ✕ cancel |
| **Downloaded** | file saved | green card "Downloaded · Open the file with Minecraft to import it." | **Open file** (green) | Share |
| **Limit reached** | download limit of the plan (`plan_download_limit`) | orange card with the reset time | **Upgrade plan** (purple) | Save |
| **Failed** | network/server error (`item_download_failed`) | red card "Download failed…" | **Try again** | Save |
| **No file** | `file_path` empty (`item_file_missing`) | orange card "The download file is not uploaded yet" | disabled **Download** | Save |
Unlocking with AC keeps the existing server call; after success the state becomes **Free/Download** and the AC pill updates.
### 4.3 Behaviour
- Entering the page records one view (existing `record_content_view`). Save toggles the existing favorite call; the heart on the cover and in the bar stay in sync.
- The bar never covers content: the scroll area has bottom padding = bar height + 24.
- RTL: everything mirrors (back arrow, buttons order, tile order); numbers use Arabic-Indic digits.
- Colors/tokens are the app's current tokens (dark `#0A0F1C` bg etc.; Light is in the preview).
### 4.4 New texts (English / Arabic); other texts reuse the app's existing keys
| English | Arabic |
|---|---|
| Unlock with AC | فتح بـ AC |
| Your balance: 190 AC. After unlocking: 40 AC. | رصيدك: 190 AC. بعد الفتح: 40 AC. |
| Requires the Epic plan | يتطلب خطة Epic |
| Your plan: Free. Upgrade to unlock Epic addons. | خطتك: Free. ارقِّ لفتح إضافات Epic. |
| Upgrade to Epic / Upgrade plan | الترقية إلى Epic / ترقية الخطة |
| Requires the Legendary plan | يتطلب خطة Legendary |
| Your plan: Free. Upgrade to unlock Legendary addons. | خطتك: Free. ارقِّ لفتح إضافات Legendary. |
| Upgrade to Legendary | الترقية إلى Legendary |
| Sign in to download | سجّل الدخول للتحميل |
| Create a free account to download and save addons. | أنشئ حساباً مجانياً لتحميل الإضافات وحفظها. |
| You can leave this screen | تقدر تغادر هذه الشاشة |
| Downloaded | تم التحميل |
| Open the file with Minecraft to import it. | افتح الملف عبر Minecraft لاستيراده. |
| Open file | فتح الملف |
| Try again | حاول مرة أخرى |
| Check your connection and try again. | تحقق من اتصالك وحاول مرة أخرى. |
| The limit resets in 3 days. | يتجدد الحد بعد 3 أيام. |
| Added [date] | أضيف [التاريخ] |
| NEW | جديد |
**Confirm with the owner:** the app has no text about *where* the file is saved or how it is opened, so the "Downloaded" note only says to open it with Minecraft; keep whatever the app already does.

## 5. Settings: new "Devices" section
At the top of Settings, above Account: section label **DEVICES** and a highlighted card **Link a PS4 console** (blue-to-purple tint, 56 dp gradient tile with a gamepad icon, red **NEW** badge, one-line description, chevron) and below it a normal row **Consoles** with the number of linked consoles. The rest of Settings stays as is (Account, Preferences, Support, About, Log out). Hide the NEW badge after the user has opened the feature once.

## 6. Link a PS4 console
Purpose: the PS4 app shows a short code; the user types it on the phone and approves; the PS4 is then signed in as that user **without typing a password on the TV**.
### 6.1 Screens
1. **Enter code** (Settings → Link a PS4 console): hero (phone ··· console), title, 3 numbered steps, label "CODE FROM YOUR TV", **6 boxes** (3 + 3 with a dash, always left-to-right, uppercase letters/digits, auto-advance, paste allowed), **Link console** button (disabled until 6 characters), security note. States: **typing**, **code ready**, **wrong code** (red boxes + message), **expired** (orange message), **too many tries** (red message with the countdown, boxes dimmed, button disabled).
2. **Approve** (bottom sheet after a valid code): console card (name "PS4", app version, "requested 1 min ago", the code), "It will be signed in as [avatar, name, @username]", what it **can** do (browse, download and chat; use your AC balance) and **cannot** do (change password or email; buy or change plans), **Allow** (blue) and **Cancel**, plus "If you did not ask for this, tap Cancel."
3. **Linked** (success): check mark between phone and console, "PS4 linked!", text with the user's name, the console row with an **Online** pill, **Done** and **Manage consoles**.
4. **Consoles** (list): rows with console icon, name, **Online** pill (active in the last 5 minutes), "Last active …", "Linked [date]", red **unlink** button; note "Unlinking signs the PS4 out of your account right away."; **Unlink all consoles**; **+ Link** in the top bar. **Empty** state with a button. **Unlink dialog**: "Unlink this PS4? It will be signed out and will need a new code to sign in again." (Cancel / red Unlink).
### 6.2 Rules
- Code: 6 characters from an alphabet without look-alikes (no 0, O, 1, I), valid **10 minutes**, **single use**.
- Wrong codes: **5 attempts per minute per user**, then lock for 60 s (message with countdown).
- The user must be signed in (otherwise open Sign in first).
- Approving is explicit; never auto-approve. After approval the PS4 gets its own session; the phone session is unaffected.
- A user can have several consoles (suggest max 5); linking a 6th asks to unlink one.
- Unlinking revokes that PS4's session immediately (it falls back to the welcome screen).
### 6.3 New texts (English / Arabic)
| English | Arabic |
|---|---|
| DEVICES | الأجهزة |
| Link a PS4 console | ربط جهاز PS4 |
| Sign in on your PS4 without typing a password | سجّل الدخول على PS4 بدون كتابة كلمة المرور |
| Consoles / Linked consoles | الأجهزة / الأجهزة المرتبطة |
| Sign in on your PS4 without typing | سجّل الدخول على PS4 بدون كتابة |
| Your PS4 shows a short code. Enter it here and approve. | يعرض PS4 رمزاً قصيراً. أدخله هنا ثم وافق. |
| Open AddonStation on your PS4 | افتح AddonStation على PS4 |
| Choose “Sign in with a code” | اختر «الدخول برمز» |
| Type the code shown on the TV here | اكتب الرمز الظاهر على التلفزيون هنا |
| CODE FROM YOUR TV | الرمز من التلفزيون |
| Link console | ربط الجهاز |
| This code is not correct. Check the code on your TV. | الرمز غير صحيح. تحقق من الرمز على التلفزيون. |
| This code expired. Press “New code” on your PS4. | انتهت صلاحية الرمز. اضغط «رمز جديد» على PS4. |
| Too many wrong attempts. Try again in 0:58. | محاولات خاطئة كثيرة. حاول بعد 0:58. |
| Only enter a code you see on your own PS4. You will be asked to approve before anything is linked. | لا تدخل إلا رمزاً تراه على جهاز PS4 الخاص بك. سنطلب موافقتك قبل أي ربط. |
| Allow this PS4 to sign in? | السماح لهذا الـ PS4 بتسجيل الدخول؟ |
| It will be signed in as | سيتم تسجيل الدخول باسم |
| Browse, download and chat | التصفح والتحميل والدردشة |
| Use your AC balance | استخدام رصيد AC |
| Cannot change your password or email | لا يغير كلمة المرور أو البريد |
| Cannot buy or change plans | لا يشتري الخطط ولا يغيّرها |
| Allow | سماح |
| If you did not ask for this, tap Cancel. | إذا لم تطلب هذا، اضغط إلغاء. |
| PS4 linked! | تم ربط الـ PS4! |
| Your PS4 is now signed in as [Name]. You can unlink it any time from Settings. | جهاز PS4 مسجّل الدخول الآن باسم [الاسم]. تقدر تفصله في أي وقت من الإعدادات. |
| Online | متصل |
| Last active … / Linked [date] | آخر نشاط … / رُبط [التاريخ] |
| Unlinking signs the PS4 out of your account right away. | فصل الجهاز يُخرجه من حسابك فوراً. |
| Unlink all consoles | فصل كل الأجهزة |
| No consoles linked | لا توجد أجهزة مرتبطة |
| Link your PS4 to sign in on the TV without typing. | اربط PS4 لتسجّل الدخول على التلفزيون بدون كتابة. |
| Unlink this PS4? | فصل هذا الـ PS4؟ |
| It will be signed out and will need a new code to sign in again. | سيتم تسجيل خروجه وسيحتاج رمزاً جديداً للدخول. |
| Unlink | فصل |
(Texts in the other six languages follow once these are approved.)
### 6.4 Server work needed (NOT in the current app; to be built by whoever manages Supabase)
This is a **proposal**; names can change. The phone and the PS4 must use the same contract.
| Piece | Purpose |
|---|---|
| Table `console_links` | `id`, `user_id`, `device_name`, `app_version`, `created_at`, `last_seen_at`, `revoked_at`, `refresh_ref` |
| Table `console_link_codes` | `code` (unique), `device_name`, `app_version`, `poll_secret_hash`, `created_at`, `expires_at`, `approved_by` (user id, null until approved), `approved_at`, `used_at` |
| RPC `console_code_create(p_device_name, p_app_version)` | called by the **PS4 (not signed in)**; returns `code`, `expires_at`, `poll_secret` (kept on the PS4) |
| RPC `console_code_lookup(p_code)` | called by the **phone (signed in)**; returns device name, version, requested-at for the approve sheet; counts attempts (5/min/user) |
| RPC `console_code_approve(p_code)` | phone approves; marks the code approved for `auth.uid()` |
| Edge Function `console-session` | called by the PS4 with `poll_secret`: returns `pending`, `expired`, or, once approved, **a session for that user** (access + refresh token) and creates the `console_links` row. It runs with the service role **on the server only**; the service-role key must never be inside any app |
| RPC `console_list()` | the user's linked consoles (for the Consoles screen); `Online` = `last_seen_at` within 5 minutes |
| RPC `console_unlink(p_id)`, `console_unlink_all()` | revoke the console's session and set `revoked_at` |
Security: RLS so users only see their own `console_links`; codes are never listed to clients; poll secret stored hashed; all attempts and approvals written to an audit log; codes and secrets are not logged. The PS4 side of this flow is in the PS4 design package (welcome → "Sign in with a code").

## 7. Open points
1. How the app currently saves and opens downloaded files (to adjust the "Downloaded" note and the Open button).
2. Max consoles per user and whether a console can be renamed.
3. Whether the "Bedrock" chip should come from data or stay fixed.
