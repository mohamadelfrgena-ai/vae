#!/usr/bin/env python3
"""Add or replace entries in assets/ui.pak (format ASUI0001) without rebuilding it.

  python3 tools/pak_set.py assets/ui.pak --dir assets --dir assets/logos qr_app=my_qr.png

  --dir D     adds every image in folder D (not recursive); the entry name is the file name without extension
  name=file   adds/replaces one entry

Names used by UI v2:
  bg_welcome  welcome page          bg_splash  email sign-in          bg_cave  "sign in with a code"
  bn_<season>_<hero|wide|strip>   seasonal sale banners (winter, spring, summer, autumn) cropped for Home / Deals / Store
  logo_fox, logo_app, logo_bear, logo_minecraft   start-up legal splash
  qr_app      QR code of the app-download page (square PNG, 512x512 or larger)
"""
import os, struct, sys

def read_pak(path):
    d = open(path, "rb").read()
    assert d[:8] == b"ASUI0001", "not an ASUI0001 pak"
    n = struct.unpack_from("<I", d, 8)[0]
    off, items = 12, []
    for _ in range(n):
        nl, dl = struct.unpack_from("<HI", d, off); off += 6
        name = d[off:off + nl].decode(); off += nl
        items.append([name, d[off:off + dl]]); off += dl
    return items

def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    path, args = sys.argv[1], sys.argv[2:]
    items = read_pak(path)
    index = {n: i for i, (n, _) in enumerate(items)}
    sets, i = [], 0
    while i < len(args):
        if args[i] == "--dir":
            d = args[i + 1]; i += 2
            for f in sorted(os.listdir(d)):
                if f.lower().endswith((".png", ".jpg", ".jpeg")):
                    sets.append((os.path.splitext(f)[0], os.path.join(d, f)))
        else:
            name, file = args[i].split("=", 1); sets.append((name, file)); i += 1
    for name, file in sets:
        data = open(file, "rb").read()
        if name in index: items[index[name]][1] = data; print("replaced", name, len(data), "bytes")
        else: items.append([name, data]); index[name] = len(items) - 1; print("added   ", name, len(data), "bytes")
    out = b"ASUI0001" + struct.pack("<I", len(items))
    for n, d in items:
        nb = n.encode(); out += struct.pack("<HI", len(nb), len(d)) + nb + d
    open(path, "wb").write(out)
    print("ok:", len(items), "entries")

main()
