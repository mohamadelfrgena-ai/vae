# AddonStation — UI Spec: Home, Chat Rooms, Chat

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait only. Design reference width: **390 dp**; all sizes below are dp / sp. Dark theme only for these screens.
**Out of scope here:** the bottom navigation bar (handled separately). Leave a content bottom padding slot for it; do not draw it.

Placeholders in square brackets, e.g. `[Username]`, `[Addon name]`, are data-bound values. Never hardcode them.

---

## 1. Design tokens

### Colors
| Token | Hex | Use |
|---|---|---|
| bg | `#0A0F1C` | screen background |
| surface | `#121A2B` | cards, inputs, chips |
| surfaceHigh | `#1A2438` | pills, secondary buttons, avatars bg |
| barSurface | `#0E1526` | top bars, composer bar |
| border | `#223049` | 1dp card/input borders, dividers |
| text | `#EAF0FA` | primary text |
| textMuted | `#9DB0CF` | secondary text, hints (`#C4D1E8` for chip labels) |
| blue | `#2E7BEF` | primary buttons, own messages, NEW badge |
| blueLink | `#6FA8FF` | "View all" links |
| gold | `#F0C25E` | pixel headings, AC balance, Legendary, Admin |
| goldDeep bg | `#1B1405` | Legendary card/banner background (text on gold buttons) |
| goldBorder | `#8A6A22` | Legendary card border |
| epic | `#9B6BFF` | EPIC badge |
| green | `#7FD99A` | "online" text |
| freeGreen | `#3C9D5A` | FREE badge |

These are approximated from the app icon (navy / blue / gold). Keep them in one `AppColors` object so they are easy to change.

### Typography
- **Pixel font** (`assets/fonts/pixel_regular.ttf`) for screen titles, section headings, hero slogan, Legendary label. UPPERCASE, letter spacing ~1sp.
  Sizes: screen title 16sp, section heading 13sp (12sp in rooms list), hero slogan 17sp (line height 1.5), app name in top bar 15sp.
- **Body font:** Nunito (Google Fonts) — or the system sans if unavailable. Weights 500/700/800.
  Sizes: greeting 22sp/800, card title 14sp/800, secondary 12sp, button 13–14sp/800, small badge 10sp/800.
- Numbers (AC balance, counters) may use `assets/fonts/roboto_medium_numbers.ttf`.

### Shape & sizing
- Cards radius 14–16dp; hero 20dp; pills 20–22dp; buttons 12dp; avatars circular.
- Min touch target **44dp** (buttons and icon buttons).
- Screen horizontal padding 16dp (chat list 12dp).

### Icons
Use Material Icons (Outlined, 22dp, tint `text` unless noted): Notifications, Search (tint textMuted), ArrowBack, PushPin (tint gold), Group, Image/AddPhotoAlternate, EmojiEmotions or StickyNote2 (stickers), Send, Download (white on blue button).

---

## 2. Screen: Home

Vertical scroll (`LazyColumn`), background `bg`. Bottom content padding for the external nav bar.

### 2.1 Top bar (not sticky)
Row, padding 16/16/12, vertically centered, gap 10:
1. `app_icon.png` 40×40, radius 10.
2. App name "ADDONSTATION", pixel font 15sp, weight fills remaining width.
3. AC pill: height 36, radius 22, bg `surfaceHigh`, padding start 6 / end 12; `coin_ac.png` 24×24 + balance text 14sp/800 in `gold`. Tap → AC wallet.
4. Bell icon button: 44×44 circle, bg `surface`.

### 2.2 Greeting + search
- Small line 13sp/700 `textMuted`, big line 22sp/800.
  - **Time-based small line:** "Good morning" before 12:00, "Good evening" from 18:00 (afternoon: use "Good evening" too unless a separate string exists).
  - **Logged in:** big line = "Welcome back, [Username]".
  - **Logged out:** big line = "Welcome to" followed by the app name, and show the Guest card (2.5).
- Search field: height 48, radius 14, bg `surface`, 1dp `border`, padding 14, search icon 20dp + hint "Search addons and worlds...", margin top 12. Tap opens search.

### 2.3 Hero banner
Margin 16 horizontal, height 250, radius 20, clipped.
- Background image `hero_home.jpg` (crop to fill).
- Vertical gradient overlay: top `bg` @10% alpha → bottom `bg` @92% alpha (stop at ~78%).
- Content anchored bottom, padding 16:
  - Slogan, pixel 17sp, `gold`, 3 lines: "DREAM IT." / "BUILD IT." / "CREATE IT."
  - Subtitle 13sp `#D3DDF0`, margin 6/12: "Addons and worlds ready for your adventure"
  - Buttons row, gap 10, height 44, radius 12:
    - "Start now" — filled `blue`, white text 14sp/800, horizontal padding 20.
    - "Join the family" — outlined 1dp `gold`, gold text. **Hide this one when the user is logged in.**

### 2.4 Plan cards (below hero, column gap 12, margin top 16)
- **Current plan card** (`FreePlanCard` / `ActivePlanCard`): surface bg, 1dp border, radius 16, padding 14.
  Left: "Your current plan" 12sp/700 muted; plan name 16sp/800 ("Free"); description 12sp muted ("Free content · Basic access · No subscription"). Right: "Upgrade" button 44h, bg `surfaceHigh`.
  For an active paid plan show plan name and "Expires on [date]" instead of Upgrade.
- **Legendary promo card:** gradient 135° `#3A2A0B` → `#1B1405`, 1dp `goldBorder`, radius 16, padding 14. Title "JOIN LEGENDARY" pixel 13sp gold; text "Legendary addons · Legendary worlds · Priority access" 12sp `#E8D5A3`; button "View" bg gold, dark text. Hide if the user already has Legendary.

### 2.5 Guest card (logged out only)
Same style as plan card. Text "Sign in to continue your adventure"; buttons "Sign in" and "Create account".

### 2.6 Category chips
Row, gap 8, margin top 22, horizontal padding 16 (horizontally scrollable). Chip height 40, radius 20, padding 16, text 13sp.
"All" (selected: bg `blue`, white, 800) · "Addons" · "Worlds" · "Favorites" (unselected: bg `surface`, text `#C4D1E8`, 700). Selecting filters the sections below.

### 2.7 Section header (reused)
Row, padding 22/16/10. Left: pixel 13sp uppercase title. Right: "View all" 13sp/700 `blueLink` (min touch 44dp).

### 2.8 Section "LATEST ADDONS" (string: "Latest addons")
Horizontal list, gap 12, padding 16. Item width **150**, bg `surface`, radius 14, clipped:
- Thumbnail height 100 (item image; fallback `thumb_placeholder.jpg`), badge top-left 6dp: text 10sp/800, radius 8, padding 2×8:
  NEW → blue/white · EPIC → `#9B6BFF`/white · LEGENDARY → gold/`#1B1405`. Free items: no badge.
- Below, padding 8/10/10: title 14sp/800 (`[Addon name]`), "By [Creator]" 12sp muted.

### 2.9 Section "MOST DOWNLOADED"
Vertical list, gap 10, padding 16 horizontal. Row: bg `surface`, radius 14, padding 10, gap 12:
thumbnail 64×64 radius 10 · column (title 14sp/800, "By [Creator]" 12sp muted) weight 1 · download button 44×44 radius 12 bg `blue`, white Download icon 20dp.

### 2.10 Section "FEATURED CREATORS"
Header + caption "Creator specials selected by AddonStation" (12sp muted, padding 0/16/10).
Horizontal row, gap 14, padding 16. Item width 72, centered: avatar 64×64 circle with 2dp ring (gold / epic / blue / border depending on rank), name 12sp/700 below. Missing avatar → `ic_default_profile.jpg`.

### 2.11 States
- Loading: skeleton blocks (bg `surface`) in the same shapes.
- Empty section: "No content published yet".
- Error: "Something went wrong" + "Tap to retry".

---

## 3. Screen: Chat Rooms (list)

Column, background `bg`. Bottom padding slot for the external nav bar.

- **Title row:** padding 16/16/8. "COMMUNITY" pixel 16sp (weight 1) + "All rooms" 12sp/700 muted.
- **Rules banner:** margin 16/8, bg `surface`, 1dp `border`, radius 14, padding 12/14, text 12sp `#C4D1E8`: "⚠️ Community rules · Violations may lead to a mute or a ban".
- **Section label** "MAIN ROOMS" — pixel 12sp, gold, padding 12/16/4.
- **Room rows**, min height 56, padding 6/16, gap 12:
  - Icon 44×44 circle (PNG already round; use `ic_room_*.png`).
  - Column: room name 15sp/800; last message preview 12sp muted, single line ellipsis.
  - Trailing: time 11sp muted; unread badge (blue circle, white 11sp/800 count) when unread > 0.
- Main rooms, in this order: General (`ic_room_general`), Minecraft (`ic_room_minecraft`), Creator (`ic_room_creator`), Support (`ic_room_support`), Social Media Makers (`ic_room_social`).
- **Section label** "LANGUAGE ROOMS", then rows in this order: Arabic (`lang_ar`), French (`lang_fr`), Portuguese (`lang_pt`), Russian (`lang_ru`), Chinese (`lang_zh`), English (`lang_en`), Spanish (`lang_es`), Türkçe (`lang_tr`).
- Tapping a row opens the Chat screen for that room.
- Logged out: show "Chat is for members only — sign in to enter the rooms" with a Sign in button instead of the list.
- First entry: community-rules gate with button "I agree and enter the chat".

---

## 4. Screen: Chat (room)

Column, full height, background `bg`: **top bar → pinned strip → message list (weight 1) → composer**. Composer sits above the keyboard (`imePadding`).

### 4.1 Top bar
bg `barSurface`, bottom border 1dp `border`, padding 10/8/10/4, gap 8, height ≥ 64.
Back (44×44) · room icon 40 circle · column [room name 16sp/800; "[N] online" 12sp/700 `green`, or "Nobody is online right now" in muted] weight 1 · Pin button (gold icon, opens "Pinned messages") · Members button.

### 4.2 Pinned strip
Shown only when something is pinned. bg `#1B1405`, bottom border 1dp `#5A4416`, padding 8/16, text 12sp/700 `gold`, single line: "Pinned messages · [Pinned message text]". Tap opens the pinned list.

### 4.3 Message list
`LazyColumn`, reverse layout (newest at bottom), padding 14/12, item gap 14. Auto-scroll to bottom for new messages unless the user scrolled up; then show the "↓ New messages" pill (height 32, radius 16, bg `blue`, white 12sp/800, centered above the composer, margin bottom 8).

**Incoming message** (row, gap 10):
- Avatar 40 circle (fallback `ic_default_profile.jpg`).
- Column: header row (gap 6): username 14sp/800 in the role color, role badge, time 11sp muted. Then content.
- Username colors: Admin → `gold` + badge "ADMIN" (bg gold, text `#1B1405`, 10sp/800, radius 6, padding 1×6); other members → a stable per-user color from [`#9B6BFF`, `#7FD99A`, `#6FA8FF`, `#EAF0FA`].
- Text: 14sp, line height 1.4.
- **Reply quote** (above the text): bg `surface`, 3dp left bar `blue`, radius 6, padding 6/10, text 12sp muted "↩ Replying to [Name]".
- **Image attachment:** max width 230, height 130 (fit by aspect ratio, max 230×260), radius 12, tap → fullscreen.
- **Sticker:** 96×96, no bubble.
- **Reactions:** chips under the message, height 28, radius 14, padding 0/10, bg `surfaceHigh`, 12sp/800, e.g. "👍 3". Tap toggles own reaction.
- Long-press menu: Add reaction, Reply, Copy text, Pin/Unpin, Report, Mute this user, Block user, Delete (own message within 3 minutes; admins/moderators any message).

**Own message:** right-aligned, max width 260, bg `blue`, white text 14sp, radius 16/16/4/16, padding 10/14. No avatar or name.

**Typing indicator:** "[Name] is typing…" 12sp muted, padding-start 50, below the last message.

**Deleted message:** italic muted "Message deleted."

### 4.4 Composer
bg `barSurface`, top border 1dp `border`, padding 8/8/18, gap 6, items centered:
Add photo (44 circle, bg `surface`) · Stickers (44 circle, bg `surface`) · text field (weight 1, height 44, radius 22, bg `surface`, 1dp border, padding 0/16, 14sp, hint "Message [Room name]") · Send (44 circle, bg `blue`, white send icon).
- Reply mode: show a strip above the composer "↩ Replying to [Name]" with a close icon.
- Max 500 characters. Rate limit message: "Wait [N]s".
- Stickers button opens a bottom sheet with sticker packs and a grid; choosing one lets the user add a caption, then send.
- Read-only rooms: replace the composer with "Read-only room — only the admin can post".
- Muted user: "You are muted until [time]". Banned: "You are banned from the chat."
- Only the admin can send video and audio files. Image types: JPG / PNG / WEBP, max 4 MB.
- Links and personal data are not allowed in messages (show: "Links and personal data are not allowed").

---

## 5. Assets
```
assets/
  images/
    app_icon.png            top bar icon
    coin_ac.png             AC currency icon
    hero_home.jpg           home hero background
    thumb_placeholder.jpg   fallback thumbnail
    ic_default_profile.jpg  default avatar
  room_icons/ic_room_*.png  13 room icons (general, minecraft, creator, support, social, lang_ar/en/es/fr/pt/ru/tr/zh)
  fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
```
Copy images and room icons to `res/drawable-nodpi/` (keep file names). Fonts go to `res/font/`.
