# AddonStation — UI Spec: Sign in, Create account, Settings, Notification settings

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait, dark theme. Design width **390 dp**; sizes are dp/sp. **No bottom navigation bar** on any of these screens.
Placeholders in brackets (`[email]`, `[username]`, `[Language]`, `[x.y]`, `[time]`, `[Date]`) are data-bound values. All texts below already exist in the app's current `strings.xml`: reuse the existing string resources and keep the same wording. Do not remove or rename any existing setting or its behavior.

Screens:
1. Sign in
2. Create account
3. Settings
4. Notification settings (opens from Settings → Notifications)

---

## 0. Tokens
Colors: bg `#0A0F1C` · surface `#121A2B` · surfaceHigh `#1A2438` · barSurface `#0E1526` · border `#223049` · divider `#1D2940` · text `#EAF0FA` · textMuted `#9DB0CF` (labels `#C4D1E8`) · blue `#2E7BEF` · blueLight `#6FA8FF` · gold `#F0C25E` · goldDark `#1B1405` · goldBorder `#8A6A22` · green `#3FBF6A` (text `#7FD99A`) · purple `#9B6BFF` · teal `#2DD4BF` · accent blue `#4C9AFF` · red `#FF6B78` (text `#FF8791`, button `#B3414B`, border `#5A2830`/`#6B2D36`, bg `#1A1015`/`#22121A`→`#150B10`).
Approximated from the app icon; keep every color in one `AppColors` object.

Fonts: pixel font `assets/fonts/pixel_regular.ttf` for screen titles and uppercase section labels (UPPERCASE, letter spacing 1sp; section label 11sp, screen title 15sp, header brand 16sp). Body: Nunito 500/700/800 (or system sans). Numbers may use `roboto_medium_numbers.ttf`.
Shapes: cards radius 16–18 · buttons radius 12–14 · icon tiles 44×44 radius 12 · pills radius 20+. Min touch target 44dp. Horizontal screen margin 16dp.

**Top bar** (Settings screens): bg `barSurface`, bottom border 1dp `border`, padding 10, back button 44×44 circle bg `surface` with ArrowBack, then title in pixel font 15sp, 6dp gap.

---

## 1. Sign in
Column, bg `bg`, vertically fills the screen (footer pinned to the bottom).

**Header (height 210):** `login_bg.jpg` center-crop; overlay vertical gradient `bg`@25% alpha → `bg` solid at 96%. Centered at the bottom (12dp up): app icon 64×64 radius 16 with 2dp `gold` border (`app_icon.png`), then "ADDONSTATION" pixel 16sp, letter spacing 1sp, margin top 8.

**Body (horizontal padding 24):**
- Title "Sign in" 26sp/800, centered. Subtitle "Sign in to continue your adventure" 13sp muted, centered, margin top 4.
- Fields (margin top 14 between them): label above (12sp/700 `#C4D1E8`, 6dp gap), field height 52, radius 14, bg `surface`, 1dp `border`, padding start 14, hint 14sp muted.
  - Email — hint `name@example.com`, keyboard type email.
  - Password — hint `••••••••`, password transform, trailing eye icon button 44×44 (show/hide).
- "Forgot password?" right-aligned, 13sp/700 `blueLight`, 44dp tall touch area, margin top 6 → opens the existing password-reset flow.
- Primary button "Sign in": full width, height 52, radius 14, bg `blue`, white 16sp/800.
- **No guest / anonymous option on this screen.**
- Loading: button shows progress and the existing "signing in" text, disabled. Errors: show under the relevant field in `red` text 12sp (existing error strings).

**Footer (pinned, padding 0/24/28):** centered 14sp muted "Don't have an account?" + "Create account" in `gold` 800 (44dp tall touch area) → opens Create account.

---

## 2. Create account
Same header as Sign in.
**Body (padding 24):**
- Title "Create account" 26sp/800 centered; subtitle "Join the family" 13sp muted.
- Fields, same style as Sign in:
  1. **Username** — hint `[username]`; helper below (11sp muted, margin 4): "3–24 characters · English letters, digits and _ only".
  2. **Email** — hint `name@example.com`.
  3. **Password** — helper "At least 6 characters"; eye toggle.
  4. **Confirm password** — eye toggle.
- Info card (margin top 14): bg `surface`, 1dp `border`, radius 14, padding 10×12, row: 36 circle (bg `surfaceHigh`, avatar/smile icon) + text 12sp `#C4D1E8` "Your new account gets a free default avatar automatically".
- Terms text, 11sp muted, centered, line height 1.5, margin top 14: "By creating an account you agree to the community rules and the terms set by AddonStation."
- Primary button "Create account" (same style as Sign in), margin top 14.
- On success: show the existing "confirm your email, then sign in" message and go to Sign in.
**Footer:** "Already have an account?" + "Sign in" (gold 800).
Validation: username length/characters, valid email, password ≥ 6, passwords match — errors inline under each field.

---

## 3. Settings
Vertical scroll. Order, all items required:

**Profile header card** (margin 16/16/0, bg `surface`, 1dp `border`, radius 20, clipped): banner strip height 64 (user banner or `login_bg.jpg`, fading into card color), avatar 64×64 circle with 3dp `gold` border overlapping the strip by 30, then column: display name 18sp/800, `@[username]` 12sp/700 muted + " · Online" in `#7FD99A`; plan chip on the right ("Free" etc.: surfaceHigh bg, `#C4D1E8`, 11sp/800, radius 8).

**Plan card** (margin 12/16): gradient 135° `#3A2A0B` → `#1B1405`, 1dp `goldBorder`, radius 18, padding 16. Row: 44 gold circle with star icon + column ["My plan" 11sp `#E8D5A3`; "Your plan: Free" 17sp/800 gold; "Free content · Basic access · No subscription" 12sp `#E8D5A3`]. Buttons row (gap 10, height 46, radius 12, weight 1 each): **Upgrade** (gold bg, goldDark text) and **Buy subscription** (bg `#2A2210`, gold text, 1dp goldBorder). Paid plans show "Expires on [date]" instead of the free description.

**Section label style:** row with a 6×14 accent bar (radius 2) + pixel 11sp label in the same accent color, padding 26/20/10.
**Group card style:** margin 0/16, bg `surface`, 1dp `border`, radius 18, clipped. Row: min height 68, padding 12×14, gap 14: icon tile 44 · column [title 15sp/800; optional sub 12sp muted, line height 1.35] weight 1 · optional value 13sp/700 `#C4D1E8` (max 120 wide, right aligned) · trailing control (chevron 18dp `#6B7A94`, switch, segmented control, or "Edit" pill). Dividers: 1dp `divider`, inset starting at 70dp (after the icon).

Sections (accent color) and rows:
1. **ACCOUNT** (`#4C9AFF`)
   - Email — `ic_set_email` — value `[email]` (read-only, no chevron)
   - Username — user icon (blue tile) — sub "3–24 characters: English letters, digits and _" — value `[username]` — "Edit" pill (12sp/800 `blueLight` on blue@13%, radius 10, padding 6×12)
   - Password — lock icon (purple tile) — value `••••••••` — "Edit" pill
2. **PREFERENCES** (`#3FBF6A`)
   - App language — `ic_set_language` — value `[Language]` — chevron
   - App theme — `ic_set_appearance` — segmented control **Dark | Light** (selected = blue fill white text; container bg `bg`, 1dp border, radius 12, padding 3, segment height 34)
   - Online status — eye icon (green tile) — sub "The online status switch is for Legendary subscribers only." — switch (off by default; locked for non-Legendary)
3. **NOTIFICATIONS** (`#9B6BFF`)
   - Notification settings — `ic_set_notifications` — sub "Choose what reaches you — 5 separate sections" — chevron → screen 4
4. **SUPPORT** (`#F0C25E`)
   - Help center — `ic_set_help`
   - Contact us — `ic_set_contact` — sub "Your mail app opens straight to the support address — we reply within 24 hours."
   - Report a problem — `ic_set_report` — sub "Describe the problem (screen, steps, device) — your mail app opens with your device details"
5. **ABOUT** (`#4C9AFF`)
   - About the app — info icon (blue tile)
   - Privacy policy — `ic_set_privacy`
   - Terms of use — `ic_set_terms`
   - App version — `ic_set_version` — value `[x.y]` (no chevron)
6. **ADMIN TOOLS** (`#F0C25E`) — **only for admin accounts**
   - Admin dashboard — shield icon (gold tile) — sub "Visible to admin accounts only" — "Open Dashboard" pill (gold on gold@13%)
7. **ACCOUNT ACTIONS** (`#FF6B78`)
   - **Log out:** standalone full-width button (margin 0/16), height 56, radius 16, bg `surface`, 1dp `#5A2830`, centered row: logout icon 22dp + "Log out" 16sp/800 `#FF8791`.
   - **Delete account card** (margin 14/16/0, gradient 180° `#22121A` → `#150B10`, 1dp `#6B2D36`, radius 18, padding 16):
     - Row: 44 tile (bg red@15%, 1dp red@40%, warning-triangle icon in `#FF6B78`) + title "Delete account" 16sp/800 `#FF8791`.
     - Text 13sp, line height 1.5, `#E6B3B8`, margin top 12: "Deleting your account removes your profile permanently. This cannot be undone."
     - Button "Delete account": full width, height 48, radius 12, bg `#B3414B`, white 14sp/800, trash icon 20dp + label, margin top 14. Tapping must open a confirmation dialog first (Cancel / Delete).
8. Footer text centered 12sp muted: "© 2026 AddonStation — All rights reserved" (padding 22/16/24).

Tile icon rules: where an original `ic_set_*.png` exists (email, language, appearance, notifications, help, contact, report, privacy, terms, version) use it as-is at 44×44 with radius 12. For the others use a Material Outlined icon, size 22, tinted with the tile's accent color on a tile of 44×44, bg accent@15%, 1dp accent@33%, radius 12.

---

## 4. Notification settings
Top bar title "NOTIFICATION SETTINGS". Scrollable.
1. **Permission banner** (only when permission not granted; margin 16/16/0): bg `#1B1405`, 1dp `#5A4416`, radius 16, padding 14. Text 13sp gold, line height 1.4: "Android needs your permission before the app can send you notifications." Button "Allow notifications" (44h, radius 12, bg gold, goldDark text 13sp/800, padding 18).
2. **Master switch card** (margin 12/16): gradient 135° `#102244` → `#121A2B`, 1dp `blue`, radius 18, padding 16. Left: pixel 11sp `blueLight` "MASTER SWITCH"; "Allow notifications" 17sp/800; "Turn off to silence everything instantly" 12sp `#C4D1E8`. Right: switch. When off, every switch below is disabled (dimmed).
3. Section label "5 SECTIONS" (purple) + caption "Choose what reaches you — 5 separate sections" 12sp muted.
4. **Group card** with 5 rows (row = icon tile 44 + title 15sp/800 + sub 12sp muted + switch; padding 14; inset dividers at 70dp):
   - Chat messages — chat icon, accent blue — "Room messages, mentions and replies"
   - Friends & social — group icon, green — "Friend requests and social activity"
   - Subscriptions — star icon, gold — "Plan activation, payments and AC — silent"
   - New content — sparkle icon, purple — "New addons, worlds and maps"
   - Reminders — clock icon, teal — "Gentle come-back reminders — no sound". Expanded block under it (indent 58): "Come-back reminder" 13sp/800; "How long a gap before we send one gentle reminder? Never more than one every two weeks." 12sp muted; chips **3 days · 7 days · 14 days** (height 36, radius 18, padding 16, selected = blue fill white, others surfaceHigh `#C4D1E8`); caption "Only if you've been away a while".
5. Section label "QUIET HOURS" (teal) + card (padding 14): row moon icon (purple tile) + "Quiet hours" 15sp/800 + "Non-urgent notifications wait until quiet hours end" + switch. Below, two equal time fields (gap 10): labels "From" / "To" 12sp/700 muted, field height 48, radius 12, bg `bg`, 1dp `border`, time 16sp/800 centered (opens a time picker). Note 12sp muted: "Mentions and replies still arrive immediately — delaying them would make them pointless."
6. Button "Send me a test notification": full width, height 48, radius 14, transparent, 1dp `blue`, text `blueLight` 14sp/800, margin 20/16/24.

---

## 5. Assets
```
assets/
  images/login_bg.jpg           header background (Sign in / Create account) and default banner
  images/app_icon.png           app icon in the auth header
  images/ic_default_profile.jpg default avatar
  settings_icons/ic_set_*.png   email, language, appearance, notifications, help, contact, report, privacy, terms, version
  fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
```
Copy images and icons into `res/drawable-nodpi/` (keep file names) and fonts into `res/font/`. Material icons: ArrowBack, Visibility / VisibilityOff, Logout, Delete, Warning, Person, Lock, Info, Shield, ChatBubbleOutline, Groups, Star, AutoAwesome, Schedule, NightsStay.
