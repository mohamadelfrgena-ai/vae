// Headless test: runs the REAL app code with a fake network and a fake display, checks behaviour, and writes PPM frames
// (python3 tools/ppm2png.py converts them) so the layout can be reviewed without a console.
//   g++ -std=c++17 -I src -o /tmp/ps4_test tests/headless_test.cpp src/core/*.cpp && /tmp/ps4_test
#include <cstdio>
#include <cstdlib>
#include <map>
#include <string>
#include <vector>
#include "../src/core/app.hpp"
#include "../src/core/json.hpp"

using namespace as;

static int g_fail = 0;
#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); ++g_fail; } } while (0)

struct FakeHttp : IHttp {
  std::vector<HttpRequest> log;
  bool request(const HttpRequest& q, HttpResponse& r) override {
    log.push_back(q);
    r.status = 200;
    if (q.url.find("/auth/v1/token") != std::string::npos) r.body = "{\"access_token\":\"AT\",\"refresh_token\":\"RT\",\"user\":{\"id\":\"u1\"}}";
    else if (q.url.find("/rpc/") != std::string::npos) r.body = "120";
    else if (q.url.find("content_items") != std::string::npos) {
      r.body = "[";
      for (int i = 0; i < 12; ++i) {
        char b[400];
        snprintf(b, sizeof b, "%s{\"id\":\"c%d\",\"title\":\"Addon number %d\",\"creator_name\":\"Creator %d\",\"required_plan\":\"%s\",\"downloads\":%d,\"views\":%d,\"description\":\"A short description of item %d.\",\"platforms\":[\"ps4\",\"pc\"]}", i ? "," : "", i, i, i, i % 3 == 0 ? "epic" : (i % 4 == 0 ? "legendary" : "free"), 100 * i, 50 * i, i);
        r.body += b;
      }
      r.body += "]";
    } else if (q.url.find("chat_channels") != std::string::npos) r.body = "[{\"id\":\"r1\",\"name\":\"General\"},{\"id\":\"r2\",\"name\":\"Minecraft\"},{\"id\":\"r3\",\"name\":\"Support\",\"read_only\":true}]";
    else if (q.url.find("chat_messages") != std::string::npos && q.method == "GET") r.body = "[{\"id\":\"m3\",\"username\":\"Sam\",\"content\":\"See you there\",\"user_id\":\"u1\",\"created_at\":\"t3\"},{\"id\":\"m2\",\"username\":\"Lina\",\"content\":\"Did anyone try the new addon?\",\"user_id\":\"u2\",\"created_at\":\"t2\"},{\"id\":\"m1\",\"username\":\"Omar\",\"content\":\"Hello everyone\",\"user_id\":\"u3\",\"created_at\":\"t1\"}]";
    else r.body = "{}";
    return true;
  }
};
struct FakeDisplay : IDisplay {
  std::vector<uint32_t> buf;
  int presents = 0;
  FakeDisplay() : buf(1920 * 1080) {}
  int width() const override { return 1920; }
  int height() const override { return 1080; }
  uint32_t* backBuffer() override { return buf.data(); }
  void present() override { ++presents; }
};
struct FakeInput : IInput {
  uint32_t mask = 0;
  std::vector<std::string> answers;
  size_t idx = 0;
  uint32_t poll() override { return mask; }
  bool promptText(const std::string&, const std::string&, bool, std::string& out) override { if (idx >= answers.size()) return false; out = answers[idx++]; return true; }
};
struct FakeStorage : IStorage {
  std::map<std::string, std::string> kv;
  bool load(const std::string& k, std::string& o) override { std::map<std::string, std::string>::iterator it = kv.find(k); if (it == kv.end()) return false; o = it->second; return true; }
  bool save(const std::string& k, const std::string& v) override { kv[k] = v; return true; }
};
struct FakeClock : IClock { double t = 0; double now() override { return t; } };

static void savePpm(const std::vector<uint32_t>& b, const char* path) {
  FILE* f = fopen(path, "wb");
  if (!f) return;
  fprintf(f, "P6\n1920 1080\n255\n");
  for (size_t i = 0; i < b.size(); ++i) { unsigned char c[3] = {(unsigned char)(b[i] >> 16), (unsigned char)(b[i] >> 8), (unsigned char)b[i]}; fwrite(c, 1, 3, f); }
  fclose(f);
}

static void press(App& app, FakeInput& in, uint32_t mask, FakeClock& clk) {
  in.mask = mask; app.tick(); in.mask = 0; app.tick();   // press then release
  for (int i = 0; i < 4; ++i) app.tick();                // let a queued load run
  clk.t += 0.1;
}

int main() {
  FakeHttp http; FakeDisplay disp; FakeInput in; FakeStorage st; FakeClock clk;
  Platform p = {&http, &disp, &in, &st, &clk};
  // ---- json
  { Json j; CHECK(Json::parse("{\"a\":[1,2,{\"b\":\"x\\u00e9\\ud83d\\ude00\"}],\"t\":true}", j)); CHECK(j["a"].size() == 3); CHECK(j["a"].at(2)["b"].str() == "x\xc3\xa9\xf0\x9f\x98\x80"); CHECK(j["t"].boolean());
    Json k; CHECK(!Json::parse("{\"a\":", k)); CHECK(!Json::parse("[1,2,]x", k)); CHECK(Json::escape("a\"b\n") == "\"a\\\"b\\n\""); }
  // ---- api client builds the right requests
  { ApiClient api(&http, "https://x.supabase.co/", "ANON"); std::vector<ContentItem> v;
    CHECK(api.listContent("addon", "downloads", 20, 10, v).ok); CHECK(v.size() == 12);
    const HttpRequest& q = http.log.back();
    CHECK(q.url == "https://x.supabase.co/rest/v1/content_items?select=*&published=eq.true&type=eq.addon&order=downloads.desc&limit=10&offset=20");
    bool hasKey = false, anonAuth = false; for (size_t i = 0; i < q.headers.size(); ++i) { if (q.headers[i].first == "apikey" && q.headers[i].second == "ANON") hasKey = true; if (q.headers[i].first == "Authorization" && q.headers[i].second == "Bearer ANON") anonAuth = true; }
    CHECK(hasKey); CHECK(anonAuth);
    CHECK(api.signIn("a@b.c", "pw\"1").ok); CHECK(api.signedIn()); CHECK(http.log.back().body == "{\"email\":\"a@b.c\",\"password\":\"pw\\\"1\"}");
    api.listContent("world", "newest", 0, 5, v); bool userAuth = false; for (size_t i = 0; i < http.log.back().headers.size(); ++i) if (http.log.back().headers[i].second == "Bearer AT") userAuth = true; CHECK(userAuth); }
  // ---- the app
  App app(p, "https://x.supabase.co", "ANON");
  app.init(); for (int i = 0; i < 6; ++i) app.tick();
  CHECK(app.screen() == S_HOME); CHECK(app.items().size() == 12);
  app.draw(); savePpm(disp.buf, "/tmp/ps4_home.ppm");
  press(app, in, BTN_DOWN, clk); press(app, in, BTN_RIGHT, clk); app.draw(); savePpm(disp.buf, "/tmp/ps4_home_focus.ppm");
  press(app, in, BTN_CROSS, clk); CHECK(app.screen() == S_ITEM); app.draw(); savePpm(disp.buf, "/tmp/ps4_item.ppm");
  press(app, in, BTN_CIRCLE, clk); CHECK(app.screen() == S_HOME);
  press(app, in, BTN_R1, clk); CHECK(app.screen() == S_STORE); CHECK(app.items().size() == 12);
  press(app, in, BTN_DOWN, clk); press(app, in, BTN_DOWN, clk); press(app, in, BTN_RIGHT, clk); press(app, in, BTN_DOWN, clk); app.draw(); savePpm(disp.buf, "/tmp/ps4_store.ppm");
  press(app, in, BTN_R1, clk); CHECK(app.screen() == S_CHAT); app.draw(); savePpm(disp.buf, "/tmp/ps4_chat.ppm");
  press(app, in, BTN_CROSS, clk); CHECK(app.screen() == S_ROOM); app.draw(); savePpm(disp.buf, "/tmp/ps4_room.ppm");
  in.answers.push_back("hello from ps4"); size_t before = http.log.size(); press(app, in, BTN_SQUARE, clk);
  bool posted = false; for (size_t i = before; i < http.log.size(); ++i) if (http.log[i].method == "POST" && http.log[i].url.find("chat_messages") != std::string::npos && http.log[i].body.find("hello from ps4") != std::string::npos) posted = true;
  CHECK(!posted);                     // guest: must ask to sign in first, never post anonymously
  press(app, in, BTN_CIRCLE, clk); press(app, in, BTN_R1, clk); CHECK(app.screen() == S_SETTINGS);
  press(app, in, BTN_RIGHT, clk); CHECK(app.lang() == LANG_AR); CHECK(st.kv["lang"] == "ar"); app.draw(); savePpm(disp.buf, "/tmp/ps4_settings_ar.ppm");
  printf(g_fail ? "TESTS FAILED (%d)\n" : "ALL TESTS PASSED (%d failures)\n", g_fail);
  return g_fail ? 1 : 0;
}
