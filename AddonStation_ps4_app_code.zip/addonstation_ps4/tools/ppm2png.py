# Converts the headless test frames (/tmp/ps4_*.ppm) to PNG so the layout can be reviewed.   python3 tools/ppm2png.py
import glob
from PIL import Image
for f in glob.glob('/tmp/ps4_*.ppm'):
    Image.open(f).save(f.replace('.ppm', '.png')); print(f.replace('.ppm', '.png'))
