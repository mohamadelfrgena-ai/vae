# One database for Android, iOS, PC and PS4

## Principle
There is **one Supabase project**. Every client app is just another front-end for it. Nothing about the data is copied or kept per device:
same accounts (email + password), same tables, same security rules (Row Level Security), same storage buckets.

```
Android app ─┐
iOS app ─────┤
PC program ──┼──►  Supabase  (Auth + PostgREST tables + RPC + Storage)  ──►  one PostgreSQL database
PS4 app ─────┘
```

## What every client must do
| Topic | Rule |
|---|---|
| Keys | Put only the project URL and the public **anon** key in the app. The `service_role` key never leaves the server/admin tools. |
| Sign-in | `POST {url}/auth/v1/token?grant_type=password` (email, password) returns `access_token` + `refresh_token`. Send `apikey: <anon>` and `Authorization: Bearer <access_token>` on every request. Refresh with `grant_type=refresh_token`. |
| Reading/writing data | `GET/POST {url}/rest/v1/<table>?...` (PostgREST). RLS decides what each user can see or change; the clients do not enforce permissions themselves. |
| Business rules | Mute/ban, slow mode, link filter, plan limits, AC balance changes, payments: **on the server** (RLS, triggers, RPC), so all clients behave the same. |
| Chat | Android/iOS/PC can use Supabase Realtime (WebSocket). The PS4 app polls `chat_messages` every ~3 s (simple and reliable on a console). |
| Files | Covers and downloads come from Supabase Storage URLs (public or signed). |
| Client info | Send a header like `X-Client-Info: addonstation-ps4/0.1` so you can see in logs which client made a request. |

## Mapping the PS4 code to your real schema
The PS4 code ships with **assumed** names in `src/core/schema.hpp`. Fill them from the Android app:
1. Find the repository classes in the Android project (package `data/`): the ones that call Supabase for content, chat channels, messages, profile and wallet.
2. Copy each **table name**, **column name** and **RPC name** into `schema.hpp` (and the join/columns used for the creator name and the sender name).
3. If content has a platform column (which consoles/PCs it supports), set `C_PLATFORMS`; if not, delete it and the PS4 app shows every item.
4. Check the RLS policies allow the same reads for the signed-in user as the Android app does (the PS4 app uses the same JWT).

## Optional: sign in without typing ("link by code")
A console is painful for typing an email and password. Suggested flow (needs a small backend addition, then a button in the Android/iOS/PC apps):
1. Console calls RPC `create_device_code()` → returns a short code (e.g. `K7P-4QX`) valid for 10 minutes; the console shows it.
2. The user opens the AddonStation app on the phone or PC (already signed in) → Settings → "Link a console" → types the code.
3. The phone calls RPC `claim_device_code(code)`, which stores the user id on that code row.
4. The console polls `get_device_session(code)`; when claimed it receives a normal session for that user. Delete the code row.
Table `device_links(code, user_id null, created_at, expires_at)`, all three RPCs `SECURITY DEFINER`, rate-limited, one use per code.

## Per-platform notes
- **PC program**: same REST calls; can use Realtime for chat; keep the refresh token in the OS credential store.
- **iOS**: same as Android (Supabase Swift SDK or the same REST calls).
- **PS4**: refresh token is saved on the console data partition (clear text in this version; protect it or use the link-by-code flow); no push notifications.

## Checklist for the developer / AI agent
- [ ] `config.h` filled (URL + anon key), no service_role key anywhere.
- [ ] `schema.hpp` matches the real tables, columns and RPC.
- [ ] RLS policies reviewed for anonymous (browsing) and signed-in users.
- [ ] Platform column / filter decided.
- [ ] Download/install behaviour decided and implemented the same way on every client.
- [ ] Strings table regenerated from the Android resources.

## Offer banners, exclusives and sale prices (added)
The tables `promo_banners`, `promo_collections`, `promo_collection_items` and `featured_slots` are shared by every client; the sale price is applied by the server when AC is charged. Full description: `SPEC_OFFER_BANNERS.md`.
