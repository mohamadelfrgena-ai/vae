# Offer banners and exclusives: one place for all apps

The owner writes the offers (for example "Winter Sale") **once**, in the admin, and the Android, iOS, PC and PS4 apps all show them. Nothing is hard-coded in any app.
Admin editor design: `reference/banner_admin_preview.html` (list + editor with live preview).

## 1. What a banner contains
Image (landscape **2080 × 1040**, ratio 2:1, JPG/WEBP under 700 KB; keep the important art in the right 45%, the text sits on the left), and per language (en, ar, fr, tr, es, ru, pt, zh): label, title, subtitle, badge text, button texts. Behaviour: what opens on tap (the Deals page of a collection, one item, or a link), look (theme: winter / sunset / night / custom accent), countdown on/off, start and end date-time, platforms (Android, iOS, PC, PS4), order, status (draft / published). The app shows a banner only when it is published, between start and end, and the platform is ticked.

## 2. Tables (Supabase) — suggested
```sql
create table promo_collections (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,                -- 'winter-sale-2026'
  title jsonb not null,                     -- {"en":"Winter Sale","ar":"تخفيضات الشتاء",...}
  theme text not null default 'winter',
  starts_at timestamptz, ends_at timestamptz
);
create table promo_collection_items (       -- which content is in the sale and at what price
  collection_id uuid references promo_collections on delete cascade,
  content_id uuid not null,                 -- FK to the content table
  discount_percent int check (discount_percent between 1 and 95),
  sale_price_ac int,                        -- optional fixed price (wins over percent)
  primary key (collection_id, content_id)
);
create table promo_banners (
  id uuid primary key default gen_random_uuid(),
  slot text not null default 'home_hero',   -- 'home_hero' | 'store_strip' | 'deals_header'
  sort_order int not null default 0,
  theme text not null default 'winter',
  image_url text not null,
  kicker jsonb, title jsonb, subtitle jsonb, badge jsonb, cta jsonb, cta2 jsonb,   -- per-language texts
  target_type text not null check (target_type in ('collection','item','link')),
  target_id text,                           -- collection id or content id
  target_url text,
  show_countdown boolean not null default false,
  starts_at timestamptz, ends_at timestamptz,
  platforms text[] not null default '{android,ios,pc,ps4}',
  status text not null default 'draft' check (status in ('draft','published')),
  created_at timestamptz not null default now()
);
create table featured_slots (               -- the three Exclusives tiles
  slot text primary key check (slot in ('exclusive_big','exclusive_small_1','exclusive_small_2')),
  content_id uuid not null
);
```
Use the real names/keys of your project; match the existing content table.

## 3. Security (RLS)
- Everyone (anon + signed in) can **read** banners where `status='published'` and now() is between `starts_at` and `ends_at`; collections and their items likewise; featured_slots always.
- Only the **admin account** can insert/update/delete these tables (same admin check the admin panel already uses).
- **Sale prices must be enforced on the server.** The function that unlocks/charges AC for a content item must read the current price from `promo_collection_items` (percent or fixed) and the collection dates, never trust the price sent by the app, so the discount is identical on every platform.

## 4. Exclusives
`featured_slots` points three slots to content items; the owner picks them in the admin (a small "Exclusives" section: choose 3 items, with a preview). Apps read the three rows and the content details in one request. The EXCLUSIVE chip + AC price chip are drawn by the app (price = sale price if the item is in an active collection).

## 5. What each client does
1. On Home (and every 15 min while open) request: published banners for slot `home_hero` filtered by platform and dates, ordered by `sort_order`; the exclusives; the items of the collections they point to.
2. Pick text by app language, fall back to English; download the image once and cache it (key = image URL).
3. PS4: banner slides every 7 s; L2/R2 change it; pause while focused. Android/iOS/PC: same banner as a swipeable card on top of Home (mobile) or a hero (PC).
4. Tapping: `collection` → Deals page (the items of that collection with their sale prices), `item` → Item details, `link` → open the link (PS4: only internal targets).
5. Countdown = `ends_at - now()` using the **server time** (send a `Date` header/RPC to avoid wrong device clocks).

## 6. Admin editor behaviour (see the preview)
List with status chips (Live / Scheduled / Draft), platforms, drag to reorder (writes `sort_order`); editor with live preview of the banner card, language chips for the texts, image upload (check size/ratio), target picker, theme chips, countdown switch, start/end pickers, platform switches, **Save draft / Publish / Delete**. Validate: title and image required, end after start, at least one platform. Publishing writes `status='published'`; the audit log should record who changed what.
