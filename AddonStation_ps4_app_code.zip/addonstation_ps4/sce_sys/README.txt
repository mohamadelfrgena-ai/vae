The package needs an sce_sys folder (param.sfo, icon0.png, ...). Copy the sce_sys folder of one of the OpenOrbis toolchain
samples and edit it: title ("AddonStation"), title id (same as TITLE_ID in Makefile.ps4), content id, version.
param.sfo is created/edited with the toolchain's PkgTool (sfo commands). Icon: 512x512 PNG (the AddonStation app icon).
