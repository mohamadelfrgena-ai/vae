# AddonStation for PS4: source code (C++)

A native PS4 app written in C/C++ for the **OpenOrbis** (open-source) PS4 toolchain. It talks to the **same Supabase database** as the Android, iOS and PC apps (see `docs/SHARED_BACKEND.md`). This package is **source code only**: nothing was built into a `.pkg`.

## What was verified, and what was not
| Part | Status |
|---|---|
| `src/core` (JSON, API client, app logic, UI, renderer, 8-language strings) | **Compiled with `-Wall -Wextra` and tested here** (`make -f Makefile.test`): 15 checks pass; the real UI code rendered the frames in `docs/rendered_frames/` |
| `src/platform/platform_ps4.cpp`, `Makefile.ps4` | **Never compiled and never run on a console.** Written from the public OpenOrbis samples; every platform call is marked `// VERIFY`. Compare each one with the headers/samples of your toolchain version |
| Network schema (`src/core/schema.hpp`) | **Assumed table/column names.** Replace them with the real ones used by the Android app |
| Text input (sign-in, chat) | Not implemented on the console yet (`promptText` returns false). See "Still to do" |

## Folder map
```
src/core/            portable code (same on every platform)
  app.cpp/.hpp         screens, navigation, loading, drawing (Home, Store, Item, Chat room, Settings)
  api_client.*         Supabase REST/Auth client (sign-in, content, rooms, messages, wallet)
  schema.hpp           ONE file that maps the app to your real tables and columns
  json.*               small JSON reader/escaper (no libraries)
  soft_renderer.*      software renderer into a 1920x1080 pixel buffer + placeholder bitmap font
  i18n.*, strings_table.hpp   8 languages generated from the Android string files
  theme.hpp            design tokens (colors, sizes) = SPEC_PS4_UI.md
src/platform/
  iplatform.hpp        the only interface between the app and a device (HTTP, display, input, storage, clock)
  platform_ps4.*       PS4 implementation (OpenOrbis)
src/main_ps4.cpp     entry point
tools/gen_strings.py  builds strings_table.hpp from <android-project>/app/src/main/res
tools/gen_font.py     builds font_data.hpp
tests/headless_test.cpp   runs the real app with a fake network and fake screen
config/config.example.h   copy to src/config.h and fill in
Makefile.ps4 / Makefile.test
docs/SHARED_BACKEND.md    how all clients share one database
```

## 1. Run the tests on a normal computer (no console)
```
make -f Makefile.test          # builds + runs the tests, writes /tmp/ps4_*.ppm
python3 tools/ppm2png.py       # turns the frames into PNG pictures
```

## 2. Connect it to your database
1. `cp config/config.example.h src/config.h`, then put your Supabase **URL** and the public **anon** key (the same two values the Android app uses). Never the `service_role` key.
2. Open `src/core/schema.hpp` and replace every `ASSUMED` name with the real table/column/RPC names from the Android app's repository classes.
3. Strings: `python3 tools/gen_strings.py <android-project>/app/src/main/res > src/core/strings_table.hpp`.

## 3. Build for the console (needs the OpenOrbis toolchain)
Set `OO_PS4_TOOLCHAIN`, copy a sample's `sce_sys` folder (see `sce_sys/README.txt`), then `make -f Makefile.ps4` and fix whatever differs in your toolchain version. Running a package on a console is a separate matter (it depends on the console you own and how it is set up); it is not covered here. Distributing on a retail console in the normal way requires Sony's official developer program and SDK.

## Still to do (known gaps)
- **Text input** on the console: implement `Ps4Input::promptText` with the system IME dialog, or add the "link by code" sign-in described in `docs/SHARED_BACKEND.md` (no typing needed).
- **Titles use the F77 Minecraft font** (`assets/fonts/F77-Minecraft.ttf`, license in `assets/fonts/FONT_LICENSE.txt`: CC BY-ND, attribution required, do not modify; confirm bundling is allowed). It needs the TTF renderer below.
- **Real fonts**: the built-in bitmap font only draws ASCII. For good text and for Arabic/Russian/Chinese add a TTF renderer (e.g. stb_truetype) and, for Arabic, text shaping + right-to-left reordering.
- **Cover pictures**: covers are generated color gradients. Add an image decoder (e.g. stb_image) and download the pictures.
- **Download / install flow**: the Download button only shows a message. Connect it to the real feature once its behaviour on the console is decided.
- **Threads**: network calls block the frame (the app shows a loading frame first). Move them to a worker thread for smoother input.
- **TLS certificates**: if HTTPS fails, load a CA bundle with the toolchain's SSL API. Do not disable certificate checks.
- Profile screen, wallet details, notifications, friends: not in this first version (the design package describes them).
- **Offer banner carousel, Exclusives tiles, Deals tab, promo strip and sale prices**: designed (see `AddonStation_ps4_design.zip`) but **not coded yet**. The current Home shows the first item as a simple hero. The database side is in `docs/SPEC_OFFER_BANNERS.md`.

## Languages
All 8 app languages are in the table (en, ar, fr, tr, es, ru, pt, zh). Only English/ASCII draws correctly until the TTF renderer is added. Arabic is right-to-left: the layout already mirrors; the text shaping is the missing part.
