// Copy this file to src/config.h (it is git-ignored) and fill in YOUR project's values.
// These are the SAME two values the Android / iOS / PC apps already use for the same Supabase project.
// NEVER put the service_role key in a client app. Only the public "anon" key belongs here.
#pragma once
#define AS_SUPABASE_URL      "https://YOUR-PROJECT.supabase.co"
#define AS_SUPABASE_ANON_KEY "YOUR-PUBLIC-ANON-KEY"
#define AS_APP_VERSION       "ps4-0.1"
