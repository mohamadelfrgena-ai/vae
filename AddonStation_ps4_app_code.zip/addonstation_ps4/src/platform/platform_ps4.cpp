// PS4 backend for the OpenOrbis toolchain (open-source, clean-room PS4 SDK): video out, controller, HTTPS, storage, clock.
//
// !! HONEST STATUS !!  This file was written from the public OpenOrbis samples/headers WITHOUT being compiled or run on a console.
// Every platform call is marked  // VERIFY  : check name, arguments and constants against the headers of YOUR toolchain version
// (OO_PS4_TOOLCHAIN/include/orbis/*.h) and the toolchain's own samples (Hello World, video out, pad, http). Fix what differs.
// The portable code in src/core is tested; this file is only the thin layer under it.
#ifdef AS_PLATFORM_PS4

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>
#include <vector>

#include <orbis/libkernel.h>     // VERIFY: kernel memory + time
#include <orbis/VideoOut.h>      // VERIFY
#include <orbis/Pad.h>           // VERIFY
#include <orbis/UserService.h>   // VERIFY
#include <orbis/Sysmodule.h>     // VERIFY
#include <orbis/Net.h>           // VERIFY
#include <orbis/Http.h>          // VERIFY
#include <orbis/Ssl.h>           // VERIFY

#include "platform_ps4.hpp"

namespace as {

// ------------------------------------------------------------------ video out
bool Ps4Display::init() {
  user_ = 0xFF;  // SCE_USER_SERVICE_USER_ID_SYSTEM equivalent: VERIFY
  handle_ = sceVideoOutOpen(ORBIS_VIDEO_USER_MAIN, ORBIS_VIDEO_OUT_BUS_MAIN, 0, NULL);   // VERIFY constant names
  if (handle_ < 0) return false;

  const size_t bytes = (size_t)W_ * H_ * 4;
  const size_t aligned = (bytes + 0x1FFFFF) & ~((size_t)0x1FFFFF);   // 2 MiB aligned
  off_t phys = 0;
  void* mem = NULL;
  // VERIFY: sample code allocates direct memory then maps it CPU+GPU read/write
  if (sceKernelAllocateDirectMemory(0, sceKernelGetDirectMemorySize(), aligned * 2, 0x200000, 3, &phys) != 0) return false;
  if (sceKernelMapDirectMemory(&mem, aligned * 2, 0x33 /* CPU_RW|GPU_RW */, 0, phys, 0x200000) != 0) return false;
  buf_[0] = (uint32_t*)mem;
  buf_[1] = (uint32_t*)((char*)mem + aligned);

  OrbisVideoOutBufferAttribute attr;   // VERIFY type name
  sceVideoOutSetBufferAttribute(&attr, ORBIS_VIDEO_OUT_PIXEL_FORMAT_B8_G8_R8_A8_SRGB, ORBIS_VIDEO_OUT_TILING_MODE_LINEAR,
                                ORBIS_VIDEO_OUT_ASPECT_RATIO_16_9, W_, H_, W_);
  void* addrs[2] = {buf_[0], buf_[1]};
  if (sceVideoOutRegisterBuffers(handle_, 0, addrs, 2, &attr) != 0) return false;
  sceVideoOutSetFlipRate(handle_, 0);
  index_ = 0;
  return true;
}

void Ps4Display::present() {
  sceVideoOutSubmitFlip(handle_, index_, ORBIS_VIDEO_OUT_FLIP_MODE_VSYNC, 0);   // VERIFY
  index_ ^= 1;
  while (sceVideoOutIsFlipPending(handle_) > 0) sceKernelUsleep(1000);          // simple wait; samples use flip events
}

// ------------------------------------------------------------------ controller
bool Ps4Input::init() {
  if (scePadInit() != 0) return false;                         // VERIFY
  int user = 0;
  if (sceUserServiceGetInitialUser(&user) != 0) return false;  // VERIFY: initial user = the one who started the app
  pad_ = scePadOpen(user, ORBIS_PAD_PORT_TYPE_STANDARD, 0, NULL);
  return pad_ >= 0;
}

uint32_t Ps4Input::poll() {
  OrbisPadData d;   // VERIFY
  memset(&d, 0, sizeof d);
  if (scePadReadState(pad_, &d) != 0) return 0;
  uint32_t m = 0;
  if (d.buttons & ORBIS_PAD_BUTTON_CROSS) m |= BTN_CROSS;
  if (d.buttons & ORBIS_PAD_BUTTON_CIRCLE) m |= BTN_CIRCLE;
  if (d.buttons & ORBIS_PAD_BUTTON_SQUARE) m |= BTN_SQUARE;
  if (d.buttons & ORBIS_PAD_BUTTON_TRIANGLE) m |= BTN_TRIANGLE;
  if (d.buttons & ORBIS_PAD_BUTTON_L1) m |= BTN_L1;
  if (d.buttons & ORBIS_PAD_BUTTON_R1) m |= BTN_R1;
  if (d.buttons & ORBIS_PAD_BUTTON_UP) m |= BTN_UP;
  if (d.buttons & ORBIS_PAD_BUTTON_DOWN) m |= BTN_DOWN;
  if (d.buttons & ORBIS_PAD_BUTTON_LEFT) m |= BTN_LEFT;
  if (d.buttons & ORBIS_PAD_BUTTON_RIGHT) m |= BTN_RIGHT;
  if (d.buttons & ORBIS_PAD_BUTTON_OPTIONS) m |= BTN_OPTIONS;
  // left stick as a d-pad (0..255, centre 128)
  if (d.leftStick.y < 60) m |= BTN_UP;
  if (d.leftStick.y > 196) m |= BTN_DOWN;
  if (d.leftStick.x < 60) m |= BTN_LEFT;
  if (d.leftStick.x > 196) m |= BTN_RIGHT;
  return m;
}

bool Ps4Input::promptText(const std::string&, const std::string&, bool, std::string&) {
  // TODO: implement with the system IME dialog (sceImeDialogInit / sceImeDialogGetStatus / sceImeDialogGetResult).
  // Until then sign-in cannot type. Alternative that avoids typing on a console: "link by code" (see SHARED_BACKEND.md).
  return false;
}

// ------------------------------------------------------------------ storage + clock
static std::string pathFor(const std::string& key) { return std::string("/data/addonstation/") + key + ".txt"; }  // VERIFY: /data is writable

bool Ps4Storage::load(const std::string& key, std::string& out) {
  FILE* f = fopen(pathFor(key).c_str(), "rb");
  if (!f) return false;
  char b[2048];
  size_t n = fread(b, 1, sizeof b - 1, f);
  fclose(f);
  out.assign(b, n);
  return true;
}
bool Ps4Storage::save(const std::string& key, const std::string& value) {
  sceKernelMkdir("/data/addonstation", 0777);   // VERIFY
  FILE* f = fopen(pathFor(key).c_str(), "wb");
  if (!f) return false;
  fwrite(value.data(), 1, value.size(), f);
  fclose(f);
  return true;   // NOTE: the refresh token is stored in clear text on the console's data partition
}
double Ps4Clock::now() { return (double)sceKernelGetProcessTime() / 1000000.0; }   // VERIFY: microseconds

// ------------------------------------------------------------------ HTTPS (sceHttp)
bool Ps4Http::init() {
  // VERIFY: module ids / names differ between toolchain versions
  sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_NET);
  sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_HTTP);
  sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_SSL);
  if (sceNetInit() != 0) return false;
  netPool_ = sceNetPoolCreate("addonstation", 1024 * 1024, 0);
  sslCtx_ = sceSslInit(512 * 1024);
  httpCtx_ = sceHttpInit(netPool_, sslCtx_, 1024 * 1024);
  if (httpCtx_ < 0) return false;
  tmpl_ = sceHttpCreateTemplate(httpCtx_, "AddonStation-PS4/0.1", ORBIS_HTTP_VERSION_1_1, 1);   // VERIFY
  return tmpl_ >= 0;
}

bool Ps4Http::request(const HttpRequest& req, HttpResponse& res) {
  res = HttpResponse();
  int method = ORBIS_HTTP_METHOD_GET;   // VERIFY constant names
  if (req.method == "POST") method = ORBIS_HTTP_METHOD_POST;
  else if (req.method == "PATCH") method = ORBIS_HTTP_METHOD_PATCH;   // VERIFY: PATCH may be missing: then use POST + "X-HTTP-Method-Override" if the server allows it
  else if (req.method == "DELETE") method = ORBIS_HTTP_METHOD_DELETE;

  int conn = sceHttpCreateConnectionWithURL(tmpl_, req.url.c_str(), 1);
  if (conn < 0) { res.error = "connect"; return false; }
  int r = sceHttpCreateRequestWithURL(conn, method, req.url.c_str(), req.body.size());
  if (r < 0) { sceHttpDeleteConnection(conn); res.error = "request"; return false; }
  for (size_t i = 0; i < req.headers.size(); ++i)
    sceHttpAddRequestHeader(r, req.headers[i].first.c_str(), req.headers[i].second.c_str(), ORBIS_HTTP_HEADER_OVERWRITE);   // VERIFY
  // TLS: certificate verification must stay ON. If it fails, load a CA bundle (sceHttpsLoadCert) instead of disabling checks.
  int rc = sceHttpSendRequest(r, req.body.empty() ? NULL : req.body.data(), req.body.size());
  if (rc < 0) { sceHttpDeleteRequest(r); sceHttpDeleteConnection(conn); res.error = "send"; return false; }
  int status = 0;
  sceHttpGetStatusCode(r, &status);
  res.status = status;
  char buf[4096];
  for (;;) {
    int n = sceHttpReadData(r, buf, sizeof buf);
    if (n <= 0) break;
    res.body.append(buf, n);
    if (res.body.size() > 4 * 1024 * 1024) break;   // safety limit
  }
  sceHttpDeleteRequest(r);
  sceHttpDeleteConnection(conn);
  return true;
}

}  // namespace as
#endif  // AS_PLATFORM_PS4
