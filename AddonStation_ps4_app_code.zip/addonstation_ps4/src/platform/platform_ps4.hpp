// Declarations for the PS4 backend (implemented in platform_ps4.cpp, only built with -DAS_PLATFORM_PS4).
#pragma once
#include "iplatform.hpp"

namespace as {

class Ps4Display : public IDisplay {
 public:
  Ps4Display() : handle_(-1), index_(0), user_(0) { buf_[0] = buf_[1] = 0; }
  bool init();
  int width() const override { return W_; }
  int height() const override { return H_; }
  uint32_t* backBuffer() override { return buf_[index_]; }
  void present() override;
 private:
  static const int W_ = 1920, H_ = 1080;
  int handle_, index_, user_;
  uint32_t* buf_[2];
};

class Ps4Input : public IInput {
 public:
  Ps4Input() : pad_(-1) {}
  bool init();
  uint32_t poll() override;
  bool promptText(const std::string& title, const std::string& initial, bool secret, std::string& out) override;
 private:
  int pad_;
};

class Ps4Storage : public IStorage {
 public:
  bool load(const std::string& key, std::string& out) override;
  bool save(const std::string& key, const std::string& value) override;
};

class Ps4Clock : public IClock {
 public:
  double now() override;
};

class Ps4Http : public IHttp {
 public:
  Ps4Http() : netPool_(-1), sslCtx_(-1), httpCtx_(-1), tmpl_(-1) {}
  bool init();
  bool request(const HttpRequest& req, HttpResponse& res) override;
 private:
  int netPool_, sslCtx_, httpCtx_, tmpl_;
};

}  // namespace as
