// The ONLY boundary between the portable app and a device. Implement it once per platform
// (platform_ps4.cpp for the console, tests/ for headless tests). Everything else is shared.
#pragma once
#include <string>
#include <vector>
#include <utility>
#include "../core/types.hpp"

namespace as {

struct HttpRequest {
  std::string method;  // "GET" | "POST" | "PATCH" | "DELETE"
  std::string url;
  std::string body;    // JSON text for POST/PATCH
  std::vector<std::pair<std::string, std::string> > headers;
};
struct HttpResponse {
  int status = 0;      // 0 = transport error
  std::string body;
  std::string error;
};

class IHttp {
 public:
  virtual ~IHttp() {}
  // Blocking request over TLS. Must verify certificates.
  virtual bool request(const HttpRequest& req, HttpResponse& res) = 0;
};

// Draws into a 32-bit buffer (see SoftRenderer) and presents it.
class IDisplay {
 public:
  virtual ~IDisplay() {}
  virtual int width() const = 0;
  virtual int height() const = 0;
  virtual uint32_t* backBuffer() = 0;  // 0xAARRGGBB, width*height pixels, row stride = width
  virtual void present() = 0;          // flip + vsync
};

class IInput {
 public:
  virtual ~IInput() {}
  virtual uint32_t poll() = 0;  // returns the CURRENT held button mask (see Button)
  // System on-screen keyboard. Returns false if cancelled/unsupported.
  virtual bool promptText(const std::string& title, const std::string& initial, bool secret, std::string& out) = 0;
};

class IStorage {
 public:
  virtual ~IStorage() {}
  virtual bool load(const std::string& key, std::string& out) = 0;   // small values (tokens, language)
  virtual bool save(const std::string& key, const std::string& value) = 0;
};

class IClock {
 public:
  virtual ~IClock() {}
  virtual double now() = 0;  // seconds, monotonic
};

struct Platform {
  IHttp* http;
  IDisplay* display;
  IInput* input;
  IStorage* storage;
  IClock* clock;
};

}  // namespace as
