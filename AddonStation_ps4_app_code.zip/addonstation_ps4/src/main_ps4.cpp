// Entry point of the PS4 app. Build with the OpenOrbis toolchain (see Makefile.ps4 and README.md).
#ifdef AS_PLATFORM_PS4
#include "config.h"        // copy config/config.example.h to src/config.h and fill in your project values
#include "core/app.hpp"
#include "platform/platform_ps4.hpp"

int main() {
  as::Ps4Display display;
  as::Ps4Input input;
  as::Ps4Storage storage;
  as::Ps4Clock clock;
  as::Ps4Http http;
  if (!display.init() || !input.init() || !http.init()) return 1;   // nothing sensible to show without a screen / pad / network

  as::Platform p = {&http, &display, &input, &storage, &clock};
  as::App app(p, AS_SUPABASE_URL, AS_SUPABASE_ANON_KEY);
  app.init();
  while (app.tick()) {       // tick = input + logic (+ one blocking network request when a screen changes)
    app.draw();              // draw ends with display.present() which waits for vsync
  }
  return 0;
}
#endif
