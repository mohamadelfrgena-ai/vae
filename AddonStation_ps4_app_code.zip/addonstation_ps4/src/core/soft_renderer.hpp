// Software renderer: draws into a plain 32-bit buffer. The PS4 backend gives it the video-out frame buffer;
// the headless test gives it a std::vector and saves a PNG/PPM so the layout can be checked without a console.
#pragma once
#include <string>
#include "types.hpp"

namespace as {

class SoftRenderer {
 public:
  SoftRenderer(uint32_t* pixels, int w, int h) : px_(pixels), w_(w), h_(h) {}
  void setTarget(uint32_t* pixels) { px_ = pixels; }
  int width() const { return w_; }
  int height() const { return h_; }
  void clear(Color c);
  void fillRect(Rect r, Color c, int radius = 0);
  void strokeRect(Rect r, Color c, int thickness, int radius = 0);
  void fillGradient(Rect r, Color top, Color bottom);   // vertical
  // Placeholder bitmap font (ASCII). Returns the pixel width. Non-ASCII characters are drawn as '?'.
  int text(const std::string& s, int x, int y, int px, Color c, Align a = ALIGN_START, int maxWidth = 0);
  int textWidth(const std::string& s, int px) const;
  void setClip(Rect r) { clip_ = r; hasClip_ = true; }
  void clearClip() { hasClip_ = false; }

 private:
  void blend(int x, int y, Color c, int coverage);  // coverage 0..255
  uint32_t* px_;
  int w_, h_;
  Rect clip_ = {0, 0, 0, 0};
  bool hasClip_ = false;
};

}  // namespace as
