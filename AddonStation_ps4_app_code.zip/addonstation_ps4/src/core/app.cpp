#include "app.hpp"
#include "theme.hpp"
#include <cstdio>
#include <cstdlib>

namespace as {
using namespace theme;

App::App(const Platform& p, const std::string& url, const std::string& anon)
    : platform_(p), r_(0), lastBuf_(0), api_(p.http, url, anon), lang_(LANG_EN), screen_(S_HOME), back_(S_HOME),
      running_(true), needLoad_(false), prevHeld_(0), injected_(0), toastUntil_(0), ac_(-1), tab_(0), focus_(0),
      storeType_(0), storeSort_(0), storeRow_(2), roomIndex_(0), lastPoll_(0), loading_(false), loadDelay_(0) {
  static SoftRenderer renderer(0, W, H);
  r_ = &renderer;
}

void App::init() {
  std::string v;
  if (platform_.storage->load("lang", v)) lang_ = langFromCode(v);
  if (platform_.storage->load("refresh_token", v) && !v.empty()) {
    Session s;
    s.refreshToken = v;
    api_.setSession(s);
    if (!api_.refresh().ok) api_.signOut();               // expired: browse as guest
    else platform_.storage->save("refresh_token", api_.session().refreshToken);
  }
  setScreen(S_HOME);
}

void App::setScreen(Screen s) {
  screen_ = s;
  focus_ = 0;
  error_.clear();
  if (s == S_HOME) tab_ = 0; else if (s == S_STORE) tab_ = 1; else if (s == S_CHAT || s == S_ROOM) tab_ = 2; else if (s == S_SETTINGS) tab_ = 3;
  needLoad_ = (s != S_ITEM && s != S_SETTINGS);
  loadDelay_ = 2;  // draw a "loading" frame first, then do the blocking request
  loading_ = needLoad_;
}

void App::loadHome() {
  items_.clear();
  ApiResult r = api_.listContent("addon", "newest", 0, 12, items_);
  if (!r.ok) error_ = r.error;
  if (api_.signedIn()) api_.walletBalance(ac_);
}
void App::loadStore() {
  items_.clear();
  ApiResult r = api_.listContent(storeType_ == 0 ? "addon" : "world", storeSort_ == 0 ? "newest" : (storeSort_ == 1 ? "downloads" : "views"), 0, 20, items_);
  if (!r.ok) error_ = r.error;
}
void App::loadRooms() {
  rooms_.clear();
  ApiResult r = api_.listRooms(rooms_);
  if (!r.ok) error_ = r.error;
}
void App::loadMessages() {
  if (roomIndex_ < 0 || roomIndex_ >= (int)rooms_.size()) return;
  std::vector<Message> m;
  ApiResult r = api_.listMessages(rooms_[roomIndex_].id, 40, m);
  if (r.ok) messages_.swap(m); else error_ = r.error;
  lastPoll_ = platform_.clock->now();
}
void App::load() {
  error_.clear();
  if (screen_ == S_HOME) loadHome();
  else if (screen_ == S_STORE) loadStore();
  else if (screen_ == S_CHAT) loadRooms();
  else if (screen_ == S_ROOM) loadMessages();
  loading_ = false;
}

void App::signInFlow() {
  std::string email, pass;
  if (!platform_.input->promptText(T("auth_email"), "", false, email)) return;
  if (!platform_.input->promptText(T("auth_password"), "", true, pass)) return;
  ApiResult r = api_.signIn(email, pass);
  if (r.ok) { platform_.storage->save("refresh_token", api_.session().refreshToken); toast(T("common_sign_in") + " OK"); }
  else toast(r.error == "auth" ? T("auth_sign_in") + " ?" : T("msg_network_error"));
}

void App::handle(uint32_t p) {
  const bool top = (screen_ == S_HOME || screen_ == S_STORE || screen_ == S_CHAT || screen_ == S_SETTINGS);
  if (top && (p & (BTN_L1 | BTN_R1))) {
    int n = (tab_ + ((p & BTN_R1) ? 1 : 3)) % 4;
    static const Screen map[4] = {S_HOME, S_STORE, S_CHAT, S_SETTINGS};
    setScreen(map[n]);
    return;
  }
  if (p & BTN_CIRCLE) {
    if (screen_ == S_ITEM) { screen_ = back_; focus_ = 0; return; }
    if (screen_ == S_ROOM) { screen_ = S_CHAT; focus_ = roomIndex_; return; }
  }
  const int cols = 5;
  switch (screen_) {
    case S_HOME: {
      int n = (int)items_.size();
      if ((p & BTN_DOWN) && focus_ == 0 && n > 0) focus_ = 1;
      else if ((p & BTN_UP) && focus_ > 0) focus_ = 0;
      else if ((p & BTN_RIGHT) && focus_ >= 1 && focus_ < n) ++focus_;
      else if ((p & BTN_LEFT) && focus_ > 1) --focus_;
      if ((p & BTN_CROSS) && n > 0) {
        current_ = items_[focus_ == 0 ? 0 : focus_ - 1];
        back_ = S_HOME; screen_ = S_ITEM; focus_ = 0;
      }
      break;
    }
    case S_STORE: {
      int n = (int)items_.size();
      if (p & BTN_DOWN) { if (storeRow_ < 2) { ++storeRow_; focus_ = 0; } else if (focus_ + cols < n) focus_ += cols; }
      if (p & BTN_UP) { if (storeRow_ == 2 && focus_ < cols) storeRow_ = 1; else if (storeRow_ == 2) focus_ -= cols; else if (storeRow_ == 1) storeRow_ = 0; }
      if (p & BTN_RIGHT) {
        if (storeRow_ == 0 && storeType_ == 0) { storeType_ = 1; needLoad_ = true; loadDelay_ = 2; loading_ = true; }
        else if (storeRow_ == 1 && storeSort_ < 3) { ++storeSort_; if (storeSort_ < 3) { needLoad_ = true; loadDelay_ = 2; loading_ = true; } else storeSort_ = 2; }
        else if (storeRow_ == 2 && focus_ + 1 < n) ++focus_;
      }
      if (p & BTN_LEFT) {
        if (storeRow_ == 0 && storeType_ == 1) { storeType_ = 0; needLoad_ = true; loadDelay_ = 2; loading_ = true; }
        else if (storeRow_ == 1 && storeSort_ > 0) { --storeSort_; needLoad_ = true; loadDelay_ = 2; loading_ = true; }
        else if (storeRow_ == 2 && focus_ > 0) --focus_;
      }
      if ((p & BTN_CROSS) && storeRow_ == 2 && focus_ < n) { current_ = items_[focus_]; back_ = S_STORE; screen_ = S_ITEM; focus_ = 0; }
      break;
    }
    case S_ITEM:
      if ((p & BTN_RIGHT) && focus_ < 2) ++focus_;
      if ((p & BTN_LEFT) && focus_ > 0) --focus_;
      if (p & BTN_CROSS) {
        // Hook points. The download / save / share behaviour must be connected to the same backend features as the other apps.
        if (focus_ == 0) toast(T("item_download") + " ...");
        else if (focus_ == 1) toast(T("item_save") + " ...");
      }
      break;
    case S_CHAT: {
      int n = (int)rooms_.size();
      if ((p & BTN_DOWN) && focus_ + 1 < n) ++focus_;
      if ((p & BTN_UP) && focus_ > 0) --focus_;
      if ((p & BTN_CROSS) && n > 0) { roomIndex_ = focus_; messages_.clear(); setScreen(S_ROOM); }
      break;
    }
    case S_ROOM:
      if (p & BTN_SQUARE) {
        std::string text;
        if (!api_.signedIn()) { signInFlow(); break; }
        if (platform_.input->promptText(T("nav_chat"), "", false, text) && !text.empty()) {
          ApiResult r = api_.sendMessage(rooms_[roomIndex_].id, text);
          if (r.ok) loadMessages(); else toast(r.error == "auth" ? T("common_sign_in") : T("msg_generic_error"));
        }
      }
      break;
    case S_SETTINGS:
      if ((p & BTN_DOWN) && focus_ < 1) ++focus_;
      if ((p & BTN_UP) && focus_ > 0) --focus_;
      if (focus_ == 0 && (p & (BTN_LEFT | BTN_RIGHT))) {
        int l = (int)lang_ + ((p & BTN_RIGHT) ? 1 : LANG_COUNT - 1);
        lang_ = (Lang)(l % LANG_COUNT);
        platform_.storage->save("lang", langCode(lang_));
      }
      if (focus_ == 1 && (p & BTN_CROSS)) {
        if (api_.signedIn()) { api_.signOut(); platform_.storage->save("refresh_token", ""); ac_ = -1; }
        else signInFlow();
      }
      break;
  }
}

bool App::tick() {
  uint32_t held = platform_.input->poll() | injected_;
  injected_ = 0;
  uint32_t pressed = held & ~prevHeld_;
  prevHeld_ = held;
  if (pressed) handle(pressed);
  if (needLoad_) { if (loadDelay_ > 0) --loadDelay_; else { needLoad_ = false; load(); } }
  if (screen_ == S_ROOM && !needLoad_ && platform_.clock->now() - lastPoll_ > 3.0) loadMessages();  // chat = polling every 3 s
  return running_;
}

// ----------------------------------------------------------------- drawing
int App::X(int x, int w) const { return isRtl(lang_) ? W - x - w : x; }
void App::txt(const std::string& s, int x, int y, int px, Color c, int maxW, bool center) {
  if (center) { r_->text(s, x, y, px, c, ALIGN_CENTER, maxW); return; }
  if (isRtl(lang_)) r_->text(s, W - x, y, px, c, ALIGN_END, maxW); else r_->text(s, x, y, px, c, ALIGN_START, maxW);
}

static Color hashColor(const std::string& id, int shade) {
  unsigned h = 2166136261u;
  for (size_t i = 0; i < id.size(); ++i) { h ^= (unsigned char)id[i]; h *= 16777619u; }
  int r = 40 + (h & 0x7F), g = 40 + ((h >> 8) & 0x7F), b = 60 + ((h >> 16) & 0x7F);
  return Color{(uint8_t)(r * shade / 100), (uint8_t)(g * shade / 100), (uint8_t)(b * shade / 100), 255};
}

void App::drawFocus(Rect r, int radius) {
  Rect o = {r.x - 12, r.y - 12, r.w + 24, r.h + 24};
  r_->strokeRect(o, Color{46, 123, 239, 90}, 12, radius + 12);   // soft glow
  r_->strokeRect(Rect{r.x - 5, r.y - 5, r.w + 10, r.h + 10}, focusRing(), 5, radius + 5);
}

void App::drawBadge(const std::string& s, int x, int y, Color bg_, Color fg) {
  int w = r_->textWidth(s, 18) + 28;
  r_->fillRect(Rect{x, y, w, 34}, bg_, 10);
  r_->text(s, x + 14, y + 7, 18, fg);
}

void App::drawCard(const ContentItem& it, Rect r, bool focused) {
  if (focused) { r.x -= 8; r.y -= 8; r.w += 16; r.h += 16; }
  r_->fillRect(r, surface(), 24);
  Rect cover = {r.x, r.y, r.w, r.h * 62 / 100};
  r_->setClip(Rect{r.x, r.y, r.w, cover.h});
  r_->fillGradient(cover, hashColor(it.id + "a", 100), hashColor(it.id + "b", 55));   // placeholder: replace with the decoded cover image
  r_->clearClip();
  if (it.tier == "epic") drawBadge("EPIC", r.x + 14, r.y + 14, rgb(0x9B6BFF), rgb(0xFFFFFF));
  else if (it.tier == "legendary") drawBadge("LEGENDARY", r.x + 14, r.y + 14, gold(), rgb(0x1B1405));
  txt(it.title, r.x + 18, r.y + cover.h + 14, T_BODY - 2, text(), r.w - 36);
  txt(fmt1(T("item_by"), it.creator), r.x + 18, r.y + cover.h + 54, T_SMALL, muted(), r.w - 36);
  r_->strokeRect(r, border(), 2, 24);
  if (focused) drawFocus(r, 24);
}

void App::drawButton(Rect r, const std::string& label, bool primary, bool focused) {
  if (primary) r_->fillGradient(Rect{r.x, r.y, r.w, r.h}, blue(), rgb(0x4C9AFF));
  else r_->fillRect(r, Color{255, 255, 255, 28}, 24);
  if (primary) { r_->fillRect(Rect{r.x, r.y, r.w, 0}, blue(), 0); }
  r_->text(label, r.x + r.w / 2, r.y + (r.h - 30) / 2, 30, rgb(0xFFFFFF), ALIGN_CENTER, r.w - 40);
  r_->strokeRect(r, primary ? Color{255, 255, 255, 0} : Color{255, 255, 255, 80}, 3, 24);
  if (focused) drawFocus(r, 24);
}

void App::drawGlyph(char sym, int cx, int cy, int size) {
  Color c = sym == 'x' ? blueLight() : (sym == 'o' ? err() : (sym == 's' ? rgb(0xE58CC6) : (sym == 't' ? ok() : chip())));
  int h = size / 2;
  r_->strokeRect(Rect{cx - h, cy - h, size, size}, c, 3, h);
  if (sym == 'x') { r_->text("X", cx, cy - 12, 22, c, ALIGN_CENTER); }
  else if (sym == 'o') { r_->strokeRect(Rect{cx - 9, cy - 9, 18, 18}, c, 3, 9); }
  else if (sym == 's') { r_->strokeRect(Rect{cx - 9, cy - 9, 18, 18}, c, 3, 0); }
  else if (sym == 't') { for (int i = 0; i < 16; ++i) r_->fillRect(Rect{cx - i / 2, cy - 9 + i, i + 1, 1}, c, 0); }
  else if (sym == 'l') { r_->text("L1", cx, cy - 11, 20, c, ALIGN_CENTER); }
  else if (sym == 'r') { r_->text("R1", cx, cy - 11, 20, c, ALIGN_CENTER); }
}

void App::drawTopBar() {
  r_->fillRect(Rect{X(SAFE_X, 60), 30, 60, 60}, surface(), 16);
  r_->strokeRect(Rect{X(SAFE_X, 60), 30, 60, 60}, gold(), 3, 16);
  txt("ADDONSTATION", SAFE_X + 78, 50, 24, text());
  const char* keys[4] = {"nav_home", "nav_store", "nav_chat", "nav_settings"};
  int x = 560;
  drawGlyph('l', X(x - 50, 38) + 19, 62, 38);
  for (int i = 0; i < 4; ++i) {
    std::string label = T(keys[i]);
    int w = r_->textWidth(label, T_TAB) + 24;
    int px = X(x, w);
    r_->text(label, px + w / 2, 46, T_TAB, i == tab_ ? rgb(0xFFFFFF) : muted(), ALIGN_CENTER);
    if (i == tab_) r_->fillRect(Rect{px, 92, w, 5}, blueLight(), 2);
    x += w + 24;
  }
  drawGlyph('r', X(x, 38) + 19, 62, 38);
  // AC pill + avatar
  char buf[32];
  if (ac_ >= 0) snprintf(buf, sizeof buf, "%d", ac_); else snprintf(buf, sizeof buf, "-");
  int pw = 70 + r_->textWidth(buf, 28) + 24;
  int pxx = X(W - SAFE_X - 56 - 20 - pw, pw);
  r_->fillRect(Rect{pxx, 32, pw, 56}, surfaceHi(), 28);
  r_->fillRect(Rect{isRtl(lang_) ? pxx + pw - 50 : pxx + 8, 40, 40, 40}, gold(), 20);
  r_->text(buf, isRtl(lang_) ? pxx + pw - 70 : pxx + 62, 44, 28, gold(), isRtl(lang_) ? ALIGN_END : ALIGN_START);
  r_->fillRect(Rect{X(W - SAFE_X - 56, 56), 32, 56, 56}, surfaceHi(), 28);
  r_->strokeRect(Rect{X(W - SAFE_X - 56, 56), 32, 56, 56}, gold(), 3, 28);
}

void App::drawLegend(const char* const* syms, const std::string* labels, int n) {
  r_->fillGradient(Rect{0, H - LEGEND_H, W, LEGEND_H}, Color{5, 8, 16, 0}, Color{5, 8, 16, 230});
  int x = SAFE_X;
  for (int i = 0; i < n; ++i) {
    int w = 44 + 14 + r_->textWidth(labels[i], T_LEGEND) + 40;
    int px = X(x, w);
    drawGlyph(syms[i][0], isRtl(lang_) ? px + w - 22 : px + 22, H - LEGEND_H / 2 - 4, 44);
    r_->text(labels[i], isRtl(lang_) ? px + w - 22 - 44 : px + 44 + 14, H - LEGEND_H / 2 - 16, T_LEGEND, chip(), isRtl(lang_) ? ALIGN_END : ALIGN_START);
    x += w;
  }
}

void App::drawHome() {
  Rect hero = {X(SAFE_X, W - 2 * SAFE_X), 130, W - 2 * SAFE_X, 470};
  if (!items_.empty()) {
    r_->setClip(hero);
    r_->fillGradient(hero, hashColor(items_[0].id + "a", 110), hashColor(items_[0].id + "b", 45));
    r_->clearClip();
  } else r_->fillRect(hero, surface(), 32);
  r_->fillGradient(Rect{hero.x, hero.y + hero.h / 2, hero.w, hero.h / 2}, Color{10, 15, 28, 0}, Color{10, 15, 28, 235});
  if (!items_.empty()) {
    txt(T("home_exclusives"), SAFE_X + 56, 280, 22, gold());
    txt(items_[0].title, SAFE_X + 56, 320, T_TITLE, rgb(0xFFFFFF), 1000);
    txt(fmt1(T("item_by"), items_[0].creator), SAFE_X + 56, 400, T_BODY, chip(), 1000);
    drawButton(Rect{X(SAFE_X + 56, 360), 470, 360, 84}, T("item_download"), true, focus_ == 0);
  }
  txt(T("home_recommended"), SAFE_X, 640, T_H2, text());
  int n = (int)items_.size();
  for (int i = 0; i < n && i < 5; ++i) {
    Rect c = {X(SAFE_X + i * 360, 330), 700, 330, 270};
    if (focus_ != i + 1) drawCard(items_[i], c, false);
  }
  for (int i = 0; i < n && i < 5; ++i) if (focus_ == i + 1) drawCard(items_[i], Rect{X(SAFE_X + i * 360, 330), 700, 330, 270}, true);
}

void App::drawStore() {
  int x = SAFE_X;
  const char* ty[2] = {"store_tab_addons", "store_tab_worlds"};
  r_->fillRect(Rect{X(x, 480), 140, 480, 76}, surface(), 22);
  for (int i = 0; i < 2; ++i) {
    Rect s = {X(x + 6 + i * 234, 228), 146, 228, 64};
    if (i == storeType_) r_->fillRect(s, blue(), 16);
    r_->text(T(ty[i]), s.x + s.w / 2, s.y + 18, 28, i == storeType_ ? rgb(0xFFFFFF) : muted(), ALIGN_CENTER);
  }
  if (storeRow_ == 0) drawFocus(Rect{X(x, 480), 140, 480, 76}, 22);
  const char* so[4] = {"store_sort_newest", "store_sort_downloads", "store_sort_views", "store_sort_rating"};
  int cx = SAFE_X + 520;
  for (int i = 0; i < 4; ++i) {
    std::string l = T(so[i]);
    int w = r_->textWidth(l, 24) + 60;
    Rect c = {X(cx, w), 146, w, 64};
    r_->fillRect(c, i == storeSort_ ? Color{46, 123, 239, 90} : surface(), 32);
    r_->strokeRect(c, i == storeSort_ ? blueLight() : border(), 2, 32);
    r_->text(l, c.x + w / 2, c.y + 20, 24, i == storeSort_ ? rgb(0xFFFFFF) : chip(), ALIGN_CENTER);
    if (storeRow_ == 1 && i == storeSort_) drawFocus(c, 32);
    cx += w + 14;
  }
  if (items_.empty() && !loading_) { r_->text(error_.empty() ? T("store_empty") : T("msg_network_error"), W / 2, 500, T_H2, muted(), ALIGN_CENTER); return; }
  const int cols = 5, cw = 330, ch = 270, gx = 30, gy = 40;
  int firstRow = (storeRow_ == 2 && focus_ / cols >= 2) ? focus_ / cols - 1 : 0;   // keeps 2 rows visible above the legend
  for (int pass = 0; pass < 2; ++pass)
    for (int i = 0; i < (int)items_.size(); ++i) {
      int row = i / cols - firstRow;
      if (row < 0 || row > 1) continue;
      bool f = storeRow_ == 2 && focus_ == i;
      if ((pass == 1) != f) continue;
      drawCard(items_[i], Rect{X(SAFE_X + (i % cols) * (cw + gx), cw), 250 + row * (ch + gy), cw, ch}, f);
    }
}

void App::drawItem() {
  Rect hero = {X(SAFE_X, 1000), 150, 1000, 560};
  r_->setClip(hero);
  r_->fillGradient(hero, hashColor(current_.id + "a", 110), hashColor(current_.id + "b", 45));
  r_->clearClip();
  if (current_.tier == "epic") drawBadge("EPIC", hero.x + 20, hero.y + 20, rgb(0x9B6BFF), rgb(0xFFFFFF));
  txt(T("item_description"), SAFE_X, 740, 20, gold());
  txt(current_.description.empty() ? "-" : current_.description, SAFE_X, 776, T_BODY, chip(), 1000);
  int rx = SAFE_X + 1056, rw = W - 2 * SAFE_X - 1056;
  txt(current_.title, rx, 150, 52, text(), rw);
  txt(fmt1(T("item_by"), current_.creator), rx, 222, T_BODY, muted(), rw);
  char b[64];
  snprintf(b, sizeof b, "%s %d", T("profile_stats_downloads").c_str(), current_.downloads);
  txt(b, rx, 290, T_BODY - 2, chip(), rw);
  // compatibility
  drawBadge("PS4", rx, 360, current_.ps4 ? rgb(0x1A2A52) : surfaceHi(), rgb(0x9CC1FF));
  drawBadge("PC", rx + 120, 360, current_.pc ? rgb(0xE7EEFB) : surfaceHi(), rgb(0x0B1226));
  drawButton(Rect{X(rx, rw), 450, rw, 92}, T("item_download"), true, focus_ == 0);
  drawButton(Rect{X(rx, rw), 566, rw, 92}, T("item_save"), false, focus_ == 1);
  drawButton(Rect{X(rx, rw), 682, rw, 92}, "Share", false, focus_ == 2);
}

void App::drawChat() {
  Rect panel = {X(SAFE_X, 1100), 140, 1100, 800};
  r_->fillRect(panel, surface(), 28);
  txt(T("comm_main_rooms"), SAFE_X + 30, 160, 20, gold());
  if (rooms_.empty() && !loading_) { r_->text(error_.empty() ? T("chat_no_messages") : T("msg_network_error"), W / 2, 500, T_H2, muted(), ALIGN_CENTER); return; }
  for (int i = 0; i < (int)rooms_.size() && i < 7; ++i) {
    Rect row = {X(SAFE_X + 20, 1060), 200 + i * 104, 1060, 96};
    if (i == focus_) { r_->fillRect(row, Color{46, 123, 239, 50}, 20); drawFocus(row, 20); }
    r_->fillRect(Rect{X(row.x + 20, 64), row.y + 16, 64, 64}, hashColor(rooms_[i].id, 100), 32);
    txt(rooms_[i].name, row.x + 110, row.y + 16, 28, text(), 640);
    if (rooms_[i].locked) drawBadge(T("comm_locked"), row.x + 820, row.y + 30, surfaceHi(), muted());
  }
}

void App::drawRoom() {
  Rect panel = {X(SAFE_X, W - 2 * SAFE_X), 140, W - 2 * SAFE_X, 780};
  r_->fillRect(panel, surface(), 28);
  txt(roomIndex_ < (int)rooms_.size() ? rooms_[roomIndex_].name : "", SAFE_X + 36, 160, 32, text(), 900);
  int y = 720;
  for (int i = (int)messages_.size() - 1; i >= 0 && y > 230; --i) {
    const Message& m = messages_[i];
    int w = r_->textWidth(m.text, 28) + 64; if (w > 900) w = 900;
    bool own = m.own;
    int bx = own ? (W - SAFE_X - 40 - w) : (SAFE_X + 40);
    Rect b = {X(bx, w), y, w, 80};
    if (own) r_->fillGradient(b, blue(), rgb(0x4C9AFF)); else r_->fillRect(b, bar(), 26);
    if (own) r_->strokeRect(b, blue(), 1, 26); else r_->strokeRect(b, border(), 2, 26);
    r_->text(m.text, b.x + 32, b.y + 25, 28, rgb(0xFFFFFF), ALIGN_START, w - 64);
    if (!own) r_->text(m.user, b.x + 4, b.y - 28, 20, blueLight(), ALIGN_START, 400);
    y -= 120;
  }
  Rect comp = {X(SAFE_X + 36, W - 2 * SAFE_X - 72), 830, W - 2 * SAFE_X - 72, 70};
  r_->fillRect(comp, bar(), 35); r_->strokeRect(comp, border(), 2, 35);
  drawGlyph('s', isRtl(lang_) ? comp.x + comp.w - 50 : comp.x + 50, 865, 44);
  r_->text(T("nav_chat") + " ...", isRtl(lang_) ? comp.x + comp.w - 100 : comp.x + 100, 848, 26, muted(), isRtl(lang_) ? ALIGN_END : ALIGN_START);
}

void App::drawSettings() {
  Rect panel = {X(SAFE_X, 1100), 140, 1100, 300};
  r_->fillRect(panel, surface(), 28);
  const char* names[LANG_COUNT] = {"English", "Arabic", "Fran\xc3\xa7" "ais", "T\xc3\xbcrk\xc3\xa7" "e", "Espa\xc3\xb1ol", "Russian", "Portugu\xc3\xaas", "Chinese"};
  Rect r0 = {X(SAFE_X + 20, 1060), 160, 1060, 120};
  if (focus_ == 0) { r_->fillRect(r0, Color{46, 123, 239, 50}, 20); drawFocus(r0, 20); }
  txt("Language", r0.x + 30, r0.y + 40, 30, text());
  r_->text(std::string("<  ") + names[lang_] + "  >", r0.x + r0.w - 40, r0.y + 40, 30, blueLight(), ALIGN_END);
  Rect r1 = {X(SAFE_X + 20, 1060), 290, 1060, 120};
  if (focus_ == 1) { r_->fillRect(r1, Color{46, 123, 239, 50}, 20); drawFocus(r1, 20); }
  txt(api_.signedIn() ? api_.session().email : T("common_sign_in"), r1.x + 30, r1.y + 40, 30, text(), 700);
}

void App::draw() {
  r_->setTarget(platform_.display->backBuffer());
  r_->clearClip();
  r_->clear(bg());
  drawTopBar();
  switch (screen_) {
    case S_HOME: drawHome(); break;
    case S_STORE: drawStore(); break;
    case S_ITEM: drawItem(); break;
    case S_CHAT: drawChat(); break;
    case S_ROOM: drawRoom(); break;
    case S_SETTINGS: drawSettings(); break;
  }
  if (loading_) r_->text(T("common_loading"), W / 2, H / 2, T_H2, muted(), ALIGN_CENTER);
  std::string lab[5];
  const char* sy[5];
  int n = 0;
  if (screen_ == S_ROOM) { sy[n] = "s"; lab[n++] = "Write"; sy[n] = "o"; lab[n++] = "Back"; }
  else { sy[n] = "x"; lab[n++] = "Select"; sy[n] = "o"; lab[n++] = "Back"; if (screen_ == S_STORE) { sy[n] = "s"; lab[n++] = T("store_search_hint"); } }
  drawLegend(sy, lab, n);
  if (!toast_.empty() && platform_.clock->now() < toastUntil_) {
    int w = r_->textWidth(toast_, 28) + 80;
    r_->fillRect(Rect{(W - w) / 2, H - 200, w, 70}, surfaceHi(), 35);
    r_->text(toast_, W / 2, H - 200 + 20, 28, text(), ALIGN_CENTER);
  }
  platform_.display->present();
}

}  // namespace as
