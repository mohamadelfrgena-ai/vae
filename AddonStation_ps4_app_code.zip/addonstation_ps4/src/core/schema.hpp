// ONE place that maps this app to the shared Supabase database.
// The Android app already talks to the real tables: copy the exact table / column / RPC names from its repository
// classes (data/ package) into this file. Everything below is an ASSUMED placeholder schema: check it before use.
#pragma once

namespace as {
namespace schema {

// ---- tables (PostgREST: GET {url}/rest/v1/<table>) ----
static const char* const T_CONTENT  = "content_items";   // ASSUMED: addons & worlds
static const char* const T_ROOMS    = "chat_channels";   // ASSUMED
static const char* const T_MESSAGES = "chat_messages";   // ASSUMED
static const char* const T_PROFILES = "profiles";        // ASSUMED

// ---- columns of T_CONTENT ----
static const char* const C_ID = "id";
static const char* const C_TITLE = "title";
static const char* const C_CREATOR = "creator_name";     // ASSUMED (may be a join with profiles)
static const char* const C_COVER = "cover_url";
static const char* const C_DESC = "description";
static const char* const C_TYPE = "type";                // 'addon' | 'world'
static const char* const C_TIER = "required_plan";       // 'free' | 'epic' | 'legendary'
static const char* const C_DOWNLOADS = "downloads";
static const char* const C_VIEWS = "views";
static const char* const C_CREATED = "created_at";
static const char* const C_PUBLISHED = "published";      // only rows with published=true are listed
static const char* const C_PLATFORMS = "platforms";      // ASSUMED text[]: e.g. {"ps4","pc"}; remove if the DB has no such column

// ---- RPC (POST {url}/rest/v1/rpc/<name>) ----
static const char* const RPC_WALLET = "get_my_ac_balance";  // ASSUMED: returns a number

}  // namespace schema
}  // namespace as
