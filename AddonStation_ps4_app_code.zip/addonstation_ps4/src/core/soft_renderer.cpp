#include "soft_renderer.hpp"
#include "font_data.hpp"
#include <cstring>

namespace as {

void SoftRenderer::blend(int x, int y, Color c, int cov) {
  if (x < 0 || y < 0 || x >= w_ || y >= h_) return;
  if (hasClip_ && (x < clip_.x || y < clip_.y || x >= clip_.x + clip_.w || y >= clip_.y + clip_.h)) return;
  int a = (c.a * cov) / 255;
  if (a <= 0) return;
  uint32_t* d = &px_[y * w_ + x];
  if (a >= 255) { *d = 0xFF000000u | (c.r << 16) | (c.g << 8) | c.b; return; }
  uint32_t o = *d;
  int or_ = (o >> 16) & 255, og = (o >> 8) & 255, ob = o & 255;
  int r = (c.r * a + or_ * (255 - a)) / 255, g = (c.g * a + og * (255 - a)) / 255, b = (c.b * a + ob * (255 - a)) / 255;
  *d = 0xFF000000u | (r << 16) | (g << 8) | b;
}

void SoftRenderer::clear(Color c) {
  uint32_t v = 0xFF000000u | (c.r << 16) | (c.g << 8) | c.b;
  for (int i = 0; i < w_ * h_; ++i) px_[i] = v;
}

// coverage of pixel (x,y) inside a rounded rect (1px soft edge)
static int roundedCoverage(int px, int py, const Rect& r, int rad) {
  if (rad <= 0) return 255;
  int cx = px < r.x + rad ? r.x + rad : (px >= r.x + r.w - rad ? r.x + r.w - rad - 1 : px);
  int cy = py < r.y + rad ? r.y + rad : (py >= r.y + r.h - rad ? r.y + r.h - rad - 1 : py);
  int dx = px - cx, dy = py - cy;
  int d2 = dx * dx + dy * dy;
  if (d2 <= (rad - 1) * (rad - 1)) return 255;
  if (d2 >= (rad + 1) * (rad + 1)) return 0;
  return 255 - (255 * (d2 - (rad - 1) * (rad - 1))) / (4 * rad);
}

void SoftRenderer::fillRect(Rect r, Color c, int rad) {
  if (rad > r.w / 2) rad = r.w / 2;
  if (rad > r.h / 2) rad = r.h / 2;
  int x0 = r.x < 0 ? 0 : r.x, y0 = r.y < 0 ? 0 : r.y, x1 = r.x + r.w > w_ ? w_ : r.x + r.w, y1 = r.y + r.h > h_ ? h_ : r.y + r.h;
  for (int y = y0; y < y1; ++y)
    for (int x = x0; x < x1; ++x) {
      bool corner = rad > 0 && (x < r.x + rad || x >= r.x + r.w - rad) && (y < r.y + rad || y >= r.y + r.h - rad);
      blend(x, y, c, corner ? roundedCoverage(x, y, r, rad) : 255);
    }
}

void SoftRenderer::strokeRect(Rect r, Color c, int t, int rad) {
  // draw as: outer rounded rect minus inner rounded rect (per pixel)
  Rect in = {r.x + t, r.y + t, r.w - 2 * t, r.h - 2 * t};
  int irad = rad > t ? rad - t : 0;
  int x0 = r.x < 0 ? 0 : r.x, y0 = r.y < 0 ? 0 : r.y, x1 = r.x + r.w > w_ ? w_ : r.x + r.w, y1 = r.y + r.h > h_ ? h_ : r.y + r.h;
  for (int y = y0; y < y1; ++y)
    for (int x = x0; x < x1; ++x) {
      int outer = roundedCoverage(x, y, r, rad);
      int inner = (x >= in.x && x < in.x + in.w && y >= in.y && y < in.y + in.h) ? roundedCoverage(x, y, in, irad) : 0;
      int cov = outer - inner;
      if (cov > 0) blend(x, y, c, cov);
    }
}

void SoftRenderer::fillGradient(Rect r, Color a, Color b) {
  for (int y = 0; y < r.h; ++y) {
    int t = r.h > 1 ? (y * 255) / (r.h - 1) : 0;
    Color c = {(uint8_t)((a.r * (255 - t) + b.r * t) / 255), (uint8_t)((a.g * (255 - t) + b.g * t) / 255), (uint8_t)((a.b * (255 - t) + b.b * t) / 255), (uint8_t)((a.a * (255 - t) + b.a * t) / 255)};
    fillRect(Rect{r.x, r.y + y, r.w, 1}, c, 0);
  }
}

int SoftRenderer::textWidth(const std::string& s, int px) const {
  int w = 0, scale256 = px * 256 / FONT_H;
  for (size_t i = 0; i < s.size(); ++i) {
    unsigned char ch = (unsigned char)s[i];
    if (ch >= 0x80) { if ((ch & 0xC0) != 0x80) w += FONT[31].adv * scale256 / 256; continue; }  // one '?' per UTF-8 char
    if (ch < 32 || ch > 126) continue;
    w += FONT[ch - 32].adv * scale256 / 256;
  }
  return w;
}

int SoftRenderer::text(const std::string& s, int x, int y, int px, Color c, Align a, int maxWidth) {
  int total = textWidth(s, px);
  std::string str = s;
  if (maxWidth > 0 && total > maxWidth) {  // ellipsis
    while (!str.empty() && textWidth(str + "...", px) > maxWidth) {
      str.erase(str.size() - 1);
      while (!str.empty() && ((unsigned char)str[str.size() - 1] & 0xC0) == 0x80) str.erase(str.size() - 1);
    }
    str += "...";
    total = textWidth(str, px);
  }
  if (a == ALIGN_CENTER) x -= total / 2;
  else if (a == ALIGN_END) x -= total;
  int scale256 = px * 256 / FONT_H, cx = x;
  for (size_t i = 0; i < str.size(); ++i) {
    unsigned char ch = (unsigned char)str[i];
    if (ch >= 0x80 && (ch & 0xC0) == 0x80) continue;
    int idx = (ch >= 32 && ch <= 126) ? ch - 32 : 31;  // '?' for anything else
    const Glyph& g = FONT[idx];
    if (g.w) {
      for (int row = 0; row < FONT_H; ++row) {
        uint16_t bits = g.rows[row];
        if (!bits) continue;
        int y0 = y + ((row + g.yoff) * scale256) / 256, y1 = y + ((row + g.yoff + 1) * scale256) / 256;
        if (y1 <= y0) y1 = y0 + 1;
        for (int col = 0; col < g.w; ++col) {
          if (!(bits & (1 << (g.w - 1 - col)))) continue;
          int x0 = cx + (col * scale256) / 256, x1 = cx + ((col + 1) * scale256) / 256;
          if (x1 <= x0) x1 = x0 + 1;
          for (int yy = y0; yy < y1; ++yy)
            for (int xx = x0; xx < x1; ++xx) blend(xx, yy, c, 255);
        }
      }
    }
    cx += g.adv * scale256 / 256;
  }
  return total;
}

}  // namespace as
