// The whole app: screens, navigation, data loading and drawing. Platform-independent (talks only to Platform).
#pragma once
#include <string>
#include <vector>
#include "types.hpp"
#include "models.hpp"
#include "i18n.hpp"
#include "api_client.hpp"
#include "soft_renderer.hpp"
#include "../platform/iplatform.hpp"

namespace as {

enum Screen { S_HOME = 0, S_STORE, S_CHAT, S_SETTINGS, S_ITEM, S_ROOM };

class App {
 public:
  App(const Platform& p, const std::string& supabaseUrl, const std::string& anonKey);
  void init();               // loads language + saved session, queues the first data load
  bool tick();               // one frame of logic. Returns false when the app should exit.
  void draw();               // renders into display->backBuffer() and calls present()

  // for tests
  Screen screen() const { return screen_; }
  void injectButtons(uint32_t pressedMask) { injected_ = pressedMask; }
  ApiClient& api() { return api_; }
  Lang lang() const { return lang_; }
  const std::vector<ContentItem>& items() const { return items_; }

 private:
  // logic
  void handle(uint32_t pressed);
  void load();               // runs the blocking network work for the current screen (after one "loading" frame was shown)
  void setScreen(Screen s);
  void loadStore();
  void loadHome();
  void loadRooms();
  void loadMessages();
  void toast(const std::string& s) { toast_ = s; toastUntil_ = platform_.clock->now() + 3.0; }
  void signInFlow();
  std::string T(const char* key) const { return tr(lang_, key); }
  // drawing
  int X(int x, int w) const;  // mirrors a rectangle for RTL languages
  void drawTopBar();
  void drawLegend(const char* const* syms, const std::string* labels, int n);
  void drawHome();
  void drawStore();
  void drawItem();
  void drawChat();
  void drawRoom();
  void drawSettings();
  void drawCard(const ContentItem& it, Rect r, bool focused);
  void drawButton(Rect r, const std::string& label, bool primary, bool focused);
  void drawFocus(Rect r, int radius);
  void drawGlyph(char sym, int cx, int cy, int size);
  void drawBadge(const std::string& s, int x, int y, Color bg, Color fg);

  Platform platform_;
  SoftRenderer* r_;
  uint32_t* lastBuf_;
  ApiClient api_;
  Lang lang_;
  Screen screen_, back_;
  bool running_, needLoad_;
  uint32_t prevHeld_, injected_;
  std::string toast_;
  double toastUntil_;
  std::string error_;

  // data
  std::vector<ContentItem> items_;
  std::vector<Room> rooms_;
  std::vector<Message> messages_;
  ContentItem current_;
  int ac_;
  // focus / selection
  int tab_;                  // 0 home, 1 store, 2 chat, 3 settings
  int focus_, storeType_, storeSort_, storeRow_;  // storeRow_: 0 = type, 1 = sort chips, 2 = grid
  int roomIndex_;
  double lastPoll_;
  bool loading_;
  int loadDelay_;
  void txt(const std::string& s, int x, int y, int px, Color c, int maxW = 0, bool center = false);
};

}  // namespace as
