#pragma once
#include <string>

namespace as {

enum Lang { LANG_EN = 0, LANG_AR, LANG_FR, LANG_TR, LANG_ES, LANG_RU, LANG_PT, LANG_ZH, LANG_COUNT };
const char* langCode(Lang l);
Lang langFromCode(const std::string& c);
inline bool isRtl(Lang l) { return l == LANG_AR; }

// Looks the key up in the generated table (strings_table.hpp). Falls back to English, then to the key itself.
const char* tr(Lang l, const char* key);
// Replaces the first "%1$s" (Android format) with arg.
std::string fmt1(const std::string& tmpl, const std::string& arg);

}  // namespace as
