#include "api_client.hpp"
#include "json.hpp"
#include "schema.hpp"
#include <cstdio>

namespace as {

ApiClient::ApiClient(IHttp* http, const std::string& baseUrl, const std::string& anonKey)
    : http_(http), base_(baseUrl), anon_(anonKey) {
  while (!base_.empty() && base_[base_.size() - 1] == '/') base_.erase(base_.size() - 1);
}

std::string ApiClient::urlEncode(const std::string& s) const {
  static const char* hex = "0123456789ABCDEF";
  std::string o;
  for (size_t i = 0; i < s.size(); ++i) {
    unsigned char c = (unsigned char)s[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') o += (char)c;
    else { o += '%'; o += hex[c >> 4]; o += hex[c & 15]; }
  }
  return o;
}

ApiResult ApiClient::call(const std::string& method, const std::string& path, const std::string& body, bool auth, std::string& responseBody) {
  ApiResult r;
  HttpRequest req;
  req.method = method;
  req.url = base_ + path;
  req.body = body;
  req.headers.push_back(std::make_pair("apikey", anon_));
  req.headers.push_back(std::make_pair("Accept", "application/json"));
  if (!body.empty()) req.headers.push_back(std::make_pair("Content-Type", "application/json"));
  // RLS decides what the user may read: send the user's JWT when signed in, otherwise the anon key.
  req.headers.push_back(std::make_pair("Authorization", "Bearer " + ((auth && session_.valid()) ? session_.accessToken : anon_)));
  HttpResponse res;
  if (!http_ || !http_->request(req, res)) { r.error = "network"; return r; }
  r.status = res.status;
  responseBody = res.body;
  if (res.status >= 200 && res.status < 300) { r.ok = true; return r; }
  if (res.status == 0) r.error = "network";
  else if (res.status == 401 || res.status == 403) r.error = "auth";
  else if (res.status >= 500) r.error = "server";
  else r.error = "request";
  return r;
}

ApiResult ApiClient::signIn(const std::string& email, const std::string& password) {
  std::string out;
  std::string body = "{\"email\":" + Json::escape(email) + ",\"password\":" + Json::escape(password) + "}";
  ApiResult r = call("POST", "/auth/v1/token?grant_type=password", body, false, out);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(out, j)) { r.ok = false; r.error = "parse"; return r; }
  session_.accessToken = j["access_token"].str();
  session_.refreshToken = j["refresh_token"].str();
  session_.userId = j["user"]["id"].str();
  session_.email = email;
  if (!session_.valid()) { r.ok = false; r.error = "auth"; }
  return r;
}

ApiResult ApiClient::refresh() {
  std::string out;
  std::string body = "{\"refresh_token\":" + Json::escape(session_.refreshToken) + "}";
  ApiResult r = call("POST", "/auth/v1/token?grant_type=refresh_token", body, false, out);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(out, j)) { r.ok = false; r.error = "parse"; return r; }
  session_.accessToken = j["access_token"].str();
  session_.refreshToken = j["refresh_token"].str(session_.refreshToken);
  return r;
}

void ApiClient::signOut() { session_ = Session(); }

static void fillItem(const Json& j, ContentItem& it) {
  it.id = j[schema::C_ID].str();
  it.title = j[schema::C_TITLE].str();
  it.creator = j[schema::C_CREATOR].str();
  it.coverUrl = j[schema::C_COVER].str();
  it.description = j[schema::C_DESC].str();
  it.type = j[schema::C_TYPE].str();
  it.tier = j[schema::C_TIER].str("free");
  it.downloads = j[schema::C_DOWNLOADS].integer();
  it.views = j[schema::C_VIEWS].integer();
  const Json& p = j[schema::C_PLATFORMS];
  if (p.isArray()) {  // if the column exists, honour it; otherwise the item is shown on every platform
    it.ps4 = it.pc = false;
    for (size_t i = 0; i < p.size(); ++i) { if (p.at(i).str() == "ps4") it.ps4 = true; if (p.at(i).str() == "pc") it.pc = true; }
  }
}

ApiResult ApiClient::listContent(const std::string& type, const std::string& sort, int offset, int limit, std::vector<ContentItem>& out) {
  std::string order = sort == "downloads" ? schema::C_DOWNLOADS : (sort == "views" ? schema::C_VIEWS : schema::C_CREATED);
  char nb[64];
  snprintf(nb, sizeof nb, "&limit=%d&offset=%d", limit, offset);
  std::string path = std::string("/rest/v1/") + schema::T_CONTENT + "?select=*&" + schema::C_PUBLISHED + "=eq.true&" +
                     schema::C_TYPE + "=eq." + urlEncode(type) + "&order=" + order + ".desc" + nb;
  std::string body;
  ApiResult r = call("GET", path, "", true, body);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(body, j) || !j.isArray()) { r.ok = false; r.error = "parse"; return r; }
  for (size_t i = 0; i < j.size(); ++i) { ContentItem it; fillItem(j.at(i), it); out.push_back(it); }
  return r;
}

ApiResult ApiClient::getContent(const std::string& id, ContentItem& out) {
  std::string body;
  ApiResult r = call("GET", std::string("/rest/v1/") + schema::T_CONTENT + "?select=*&" + schema::C_ID + "=eq." + urlEncode(id) + "&limit=1", "", true, body);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(body, j) || j.size() < 1) { r.ok = false; r.error = "notfound"; return r; }
  fillItem(j.at(0), out);
  return r;
}

ApiResult ApiClient::listRooms(std::vector<Room>& out) {
  std::string body;
  ApiResult r = call("GET", std::string("/rest/v1/") + schema::T_ROOMS + "?select=*&order=sort_order.asc", "", true, body);  // sort_order: ASSUMED
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(body, j) || !j.isArray()) { r.ok = false; r.error = "parse"; return r; }
  for (size_t i = 0; i < j.size(); ++i) {
    Room rm;
    rm.id = j.at(i)["id"].str();
    rm.name = j.at(i)["name"].str();
    rm.locked = j.at(i)["read_only"].boolean();  // ASSUMED column
    out.push_back(rm);
  }
  return r;
}

ApiResult ApiClient::listMessages(const std::string& roomId, int limit, std::vector<Message>& out) {
  char nb[32];
  snprintf(nb, sizeof nb, "&limit=%d", limit);
  std::string body;
  // newest first from the server; the UI reverses it so the latest message is at the bottom.
  ApiResult r = call("GET", std::string("/rest/v1/") + schema::T_MESSAGES + "?select=*&channel_id=eq." + urlEncode(roomId) + "&order=created_at.desc" + nb, "", true, body);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(body, j) || !j.isArray()) { r.ok = false; r.error = "parse"; return r; }
  for (size_t i = j.size(); i > 0; --i) {
    const Json& m = j.at(i - 1);
    Message ms;
    ms.id = m["id"].str();
    ms.user = m["username"].str();  // ASSUMED (often a join with profiles)
    ms.text = m["content"].str();
    ms.time = m["created_at"].str();
    ms.own = !session_.userId.empty() && m["user_id"].str() == session_.userId;
    out.push_back(ms);
  }
  return r;
}

ApiResult ApiClient::sendMessage(const std::string& roomId, const std::string& text) {
  if (!session_.valid()) { ApiResult r; r.error = "auth"; return r; }
  std::string body = "{\"channel_id\":" + Json::escape(roomId) + ",\"user_id\":" + Json::escape(session_.userId) + ",\"content\":" + Json::escape(text) + "}";
  std::string out;
  // The server (RLS + triggers) enforces mute/ban/slow-mode/links rules exactly as for the other apps.
  return call("POST", std::string("/rest/v1/") + schema::T_MESSAGES, body, true, out);
}

ApiResult ApiClient::walletBalance(int& out) {
  std::string body;
  ApiResult r = call("POST", std::string("/rest/v1/rpc/") + schema::RPC_WALLET, "{}", true, body);
  if (!r.ok) return r;
  Json j;
  if (!Json::parse(body, j)) { r.ok = false; r.error = "parse"; return r; }
  out = j.integer(0);
  return r;
}

}  // namespace as
