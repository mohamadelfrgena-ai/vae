// Tiny dependency-free JSON reader (enough for Supabase REST/Auth responses) + string escaper.
// No exceptions, no RTTI. Numbers are doubles. Strings are UTF-8; \uXXXX escapes are decoded (incl. surrogate pairs).
#pragma once
#include <string>
#include <vector>
#include <utility>

namespace as {

class Json {
 public:
  enum Type { NUL, BOOL, NUM, STR, ARR, OBJ };
  Json() : type_(NUL), b_(false), n_(0) {}
  Type type() const { return type_; }
  bool isNull() const { return type_ == NUL; }
  bool isArray() const { return type_ == ARR; }
  bool isObject() const { return type_ == OBJ; }
  size_t size() const { return type_ == ARR ? arr_.size() : (type_ == OBJ ? obj_.size() : 0); }
  const Json& at(size_t i) const;                   // array element or null
  const Json& operator[](const std::string& k) const;  // object member or null
  std::string str(const std::string& def = "") const { return type_ == STR ? s_ : def; }
  double num(double def = 0) const { return type_ == NUM ? n_ : def; }
  int integer(int def = 0) const { return type_ == NUM ? (int)n_ : def; }
  bool boolean(bool def = false) const { return type_ == BOOL ? b_ : def; }

  // Returns false on malformed input (out is left null).
  static bool parse(const std::string& text, Json& out);
  static std::string escape(const std::string& s);  // returns the quoted JSON string
 private:
  friend struct JsonParser;
  Type type_;
  bool b_;
  double n_;
  std::string s_;
  std::vector<Json> arr_;
  std::vector<std::pair<std::string, Json> > obj_;
};

}  // namespace as
