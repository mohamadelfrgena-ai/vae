// Talks to the SAME Supabase project as the Android / iOS / PC apps, over plain REST (PostgREST + GoTrue).
// No SDK needed: every call is an HTTPS request through IHttp.
#pragma once
#include <string>
#include <vector>
#include "models.hpp"
#include "../platform/iplatform.hpp"

namespace as {

struct ApiResult {
  bool ok = false;
  int status = 0;
  std::string error;  // short, user-facing-safe text (never contains tokens)
};

class ApiClient {
 public:
  ApiClient(IHttp* http, const std::string& baseUrl, const std::string& anonKey);
  const Session& session() const { return session_; }
  void setSession(const Session& s) { session_ = s; }
  bool signedIn() const { return session_.valid(); }

  ApiResult signIn(const std::string& email, const std::string& password);   // POST /auth/v1/token?grant_type=password
  ApiResult refresh();                                                       // POST /auth/v1/token?grant_type=refresh_token
  void signOut();

  // type: "addon" | "world"; sort: "newest" | "downloads" | "views"
  ApiResult listContent(const std::string& type, const std::string& sort, int offset, int limit, std::vector<ContentItem>& out);
  ApiResult getContent(const std::string& id, ContentItem& out);
  ApiResult listRooms(std::vector<Room>& out);
  ApiResult listMessages(const std::string& roomId, int limit, std::vector<Message>& out);
  ApiResult sendMessage(const std::string& roomId, const std::string& text);
  ApiResult walletBalance(int& out);

  // exposed for tests
  std::string urlEncode(const std::string& s) const;

 private:
  ApiResult call(const std::string& method, const std::string& path, const std::string& body, bool auth, std::string& responseBody);
  IHttp* http_;
  std::string base_, anon_;
  Session session_;
};

}  // namespace as
