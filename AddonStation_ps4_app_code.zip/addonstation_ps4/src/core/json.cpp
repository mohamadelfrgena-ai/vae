#include "json.hpp"
#include <cstdlib>
#include <cstring>
#include <cstdio>

namespace as {

static const Json kNull;
const Json& Json::at(size_t i) const { return (type_ == ARR && i < arr_.size()) ? arr_[i] : kNull; }
const Json& Json::operator[](const std::string& k) const {
  if (type_ == OBJ)
    for (size_t i = 0; i < obj_.size(); ++i)
      if (obj_[i].first == k) return obj_[i].second;
  return kNull;
}

struct JsonParser {
  const char* p;
  const char* end;
  int depth;
  void ws() { while (p < end && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) ++p; }
  static void utf8(std::string& s, unsigned cp) {
    if (cp < 0x80) s += (char)cp;
    else if (cp < 0x800) { s += (char)(0xC0 | (cp >> 6)); s += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { s += (char)(0xE0 | (cp >> 12)); s += (char)(0x80 | ((cp >> 6) & 0x3F)); s += (char)(0x80 | (cp & 0x3F)); }
    else { s += (char)(0xF0 | (cp >> 18)); s += (char)(0x80 | ((cp >> 12) & 0x3F)); s += (char)(0x80 | ((cp >> 6) & 0x3F)); s += (char)(0x80 | (cp & 0x3F)); }
  }
  bool hex4(unsigned& v) {
    if (end - p < 4) return false;
    v = 0;
    for (int i = 0; i < 4; ++i) {
      char c = *p++;
      v <<= 4;
      if (c >= '0' && c <= '9') v |= c - '0';
      else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
      else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
      else return false;
    }
    return true;
  }
  bool string(std::string& out) {
    if (p >= end || *p != '"') return false;
    ++p;
    while (p < end && *p != '"') {
      if (*p == '\\') {
        ++p;
        if (p >= end) return false;
        char c = *p++;
        switch (c) {
          case '"': out += '"'; break;
          case '\\': out += '\\'; break;
          case '/': out += '/'; break;
          case 'b': out += '\b'; break;
          case 'f': out += '\f'; break;
          case 'n': out += '\n'; break;
          case 'r': out += '\r'; break;
          case 't': out += '\t'; break;
          case 'u': {
            unsigned cp;
            if (!hex4(cp)) return false;
            if (cp >= 0xD800 && cp < 0xDC00) {
              if (end - p >= 6 && p[0] == '\\' && p[1] == 'u') {
                p += 2;
                unsigned lo;
                if (!hex4(lo)) return false;
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
              }
            }
            utf8(out, cp);
            break;
          }
          default: return false;
        }
      } else {
        out += *p++;
      }
    }
    if (p >= end) return false;
    ++p;
    return true;
  }
  bool value(Json& v) {
    if (++depth > 64) return false;
    ws();
    if (p >= end) return false;
    bool ok = false;
    char c = *p;
    if (c == '{') {
      ++p; v.type_ = Json::OBJ; ws();
      if (p < end && *p == '}') { ++p; ok = true; }
      else {
        for (;;) {
          ws();
          std::string k;
          if (!string(k)) break;
          ws();
          if (p >= end || *p != ':') break;
          ++p;
          Json child;
          if (!value(child)) break;
          v.obj_.push_back(std::make_pair(k, child));
          ws();
          if (p < end && *p == ',') { ++p; continue; }
          if (p < end && *p == '}') { ++p; ok = true; }
          break;
        }
      }
    } else if (c == '[') {
      ++p; v.type_ = Json::ARR; ws();
      if (p < end && *p == ']') { ++p; ok = true; }
      else {
        for (;;) {
          Json child;
          if (!value(child)) break;
          v.arr_.push_back(child);
          ws();
          if (p < end && *p == ',') { ++p; continue; }
          if (p < end && *p == ']') { ++p; ok = true; }
          break;
        }
      }
    } else if (c == '"') {
      v.type_ = Json::STR; ok = string(v.s_);
    } else if (end - p >= 4 && !strncmp(p, "true", 4)) { p += 4; v.type_ = Json::BOOL; v.b_ = true; ok = true; }
    else if (end - p >= 5 && !strncmp(p, "false", 5)) { p += 5; v.type_ = Json::BOOL; v.b_ = false; ok = true; }
    else if (end - p >= 4 && !strncmp(p, "null", 4)) { p += 4; v.type_ = Json::NUL; ok = true; }
    else {
      char* e = 0;
      double d = strtod(p, &e);
      if (e && e != p && e <= end) { p = e; v.type_ = Json::NUM; v.n_ = d; ok = true; }
    }
    --depth;
    return ok;
  }
};

bool Json::parse(const std::string& text, Json& out) {
  JsonParser ps;
  ps.p = text.data();
  ps.end = text.data() + text.size();
  ps.depth = 0;
  Json v;
  if (!ps.value(v)) { out = Json(); return false; }
  ps.ws();
  if (ps.p != ps.end) { out = Json(); return false; }
  out = v;
  return true;
}

std::string Json::escape(const std::string& s) {
  std::string o = "\"";
  for (size_t i = 0; i < s.size(); ++i) {
    unsigned char c = (unsigned char)s[i];
    switch (c) {
      case '"': o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n"; break;
      case '\r': o += "\\r"; break;
      case '\t': o += "\\t"; break;
      default:
        if (c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; }
        else o += (char)c;
    }
  }
  o += "\"";
  return o;
}

}  // namespace as
