// Shared basic types. No platform code in src/core: everything here must compile on PS4 (OpenOrbis), PC and tests.
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <utility>

namespace as {

struct Color { uint8_t r, g, b, a; };
inline Color rgb(uint32_t hex, uint8_t a = 255) { return Color{(uint8_t)(hex >> 16), (uint8_t)(hex >> 8), (uint8_t)hex, a}; }
struct Rect { int x, y, w, h; };

enum Align { ALIGN_START = 0, ALIGN_CENTER = 1, ALIGN_END = 2 };

// Controller buttons as a bit mask (the platform layer maps the real pad to this).
enum Button : uint32_t {
  BTN_CROSS = 1u << 0,    // select
  BTN_CIRCLE = 1u << 1,   // back
  BTN_SQUARE = 1u << 2,   // search / write
  BTN_TRIANGLE = 1u << 3, // menu
  BTN_L1 = 1u << 4,       // previous tab
  BTN_R1 = 1u << 5,       // next tab
  BTN_UP = 1u << 6,
  BTN_DOWN = 1u << 7,
  BTN_LEFT = 1u << 8,
  BTN_RIGHT = 1u << 9,
  BTN_OPTIONS = 1u << 10
};

}  // namespace as
