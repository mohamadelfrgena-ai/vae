#include "i18n.hpp"
#include "strings_table.hpp"
#include <cstring>

namespace as {

static const char* const kCodes[LANG_COUNT] = {"en", "ar", "fr", "tr", "es", "ru", "pt", "zh"};
const char* langCode(Lang l) { return kCodes[l]; }
Lang langFromCode(const std::string& c) {
  for (int i = 0; i < LANG_COUNT; ++i) if (c == kCodes[i]) return (Lang)i;
  return LANG_EN;
}

const char* tr(Lang l, const char* key) {
  for (int i = 0; i < STRINGS_COUNT; ++i) {
    if (strcmp(STRINGS[i].key, key) == 0) {
      const char* s = STRINGS[i].v[l];
      if (s && s[0]) return s;
      s = STRINGS[i].v[LANG_EN];
      return (s && s[0]) ? s : key;
    }
  }
  return key;
}

std::string fmt1(const std::string& t, const std::string& a) {
  size_t p = t.find("%1$s");
  if (p == std::string::npos) return t + " " + a;
  return t.substr(0, p) + a + t.substr(p + 4);
}

}  // namespace as
