#pragma once
#include <string>
#include <vector>

namespace as {

struct ContentItem {
  std::string id, title, creator, coverUrl, description, type, tier;
  int downloads = 0, views = 0;
  bool ps4 = true, pc = true;
};
struct Room {
  std::string id, name;
  int online = 0, unread = 0;
  bool locked = false;
};
struct Message {
  std::string id, user, text, time;
  bool own = false;
};
struct Session {
  std::string accessToken, refreshToken, userId, email;
  bool valid() const { return !accessToken.empty(); }
};

}  // namespace as
