// Design tokens for the PS4 / TV UI. Units are pixels at 1920x1080 (the renderer scales if the display differs).
// These match the PS4 design package (SPEC_PS4_UI.md): dark theme only.
#pragma once
#include "types.hpp"

namespace as {
namespace theme {

static const int W = 1920, H = 1080;
static const int SAFE_X = 96, SAFE_Y = 54;     // title-safe area
static const int TOPBAR_H = 120, LEGEND_H = 88;

inline Color bg()        { return rgb(0x0A0F1C); }
inline Color surface()   { return rgb(0x121A2B); }
inline Color surfaceHi() { return rgb(0x1A2438); }
inline Color bar()       { return rgb(0x0E1526); }
inline Color border()    { return rgb(0x223049); }
inline Color text()      { return rgb(0xEAF0FA); }
inline Color muted()     { return rgb(0x9DB0CF); }
inline Color chip()      { return rgb(0xC4D1E8); }
inline Color blue()      { return rgb(0x2E7BEF); }
inline Color blueLight() { return rgb(0x6FA8FF); }
inline Color focusRing() { return rgb(0x9CC1FF); }
inline Color gold()      { return rgb(0xF0C25E); }
inline Color ok()        { return rgb(0x3FBF6A); }
inline Color err()       { return rgb(0xFF6B78); }

// type sizes (px)
static const int T_TAB = 30, T_TITLE = 58, T_H2 = 36, T_BODY = 28, T_SMALL = 22, T_LEGEND = 24;

}  // namespace theme
}  // namespace as
