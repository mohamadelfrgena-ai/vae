AddonStation phone app: new loading and error states

AddonStation_phone_states_design.html      open in a browser (all states, Dark/Light, English/Arabic)
SPEC_PHONE_LOADING_AND_ERRORS.md           the specification (give this to the Android Studio agent)
captures/sheet_01..05.jpg                  every state
