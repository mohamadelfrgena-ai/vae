# AddonStation phone app: new loading and error states

Open `AddonStation_phone_states_design.html` (pick a screen and a state, Dark/Light, English/Arabic). `captures/` has every state.

> **For the AI agent in Android Studio:** replace the current "dim the screen + small spinner + Loading..." and the "red Network error text + grey Retry button" with the components below, as two reusable Compose pieces (`LoadingState` and `ErrorState`) used by every screen. Keep the app's tokens, fonts and bottom bar. Do not change anything else.

## 1. What was wrong before (from the screenshots)
- **Loading:** the whole screen was dimmed and a small spinner with "Loading..." sat on top of the old content, so the user saw nothing useful and the layout jumped when data arrived.
- **Network error:** a plain red line "Network error" and a grey "Retry" button on an empty dark screen, no icon, no explanation, the same for every kind of error.

## 2. Loading: which pattern to use
| Situation | Pattern | Details |
|---|---|---|
| A list or page is loading for the first time | **Skeleton** | Real header, search, tabs and chips stay visible; only the content is replaced by grey shimmer blocks with the **same shape and size** as the final cards (2-column grid for the Store, cover + title + stat tiles + description for the addon page). No dimming |
| User pulls down to refresh | **Pull indicator** | A small pill at the top "Refreshing…" with a spinner; the old content stays |
| End of a list (loading the next page) | **Loading more** | Two skeleton cards at the end of the grid and a pill "Loading more…" |
| Still loading after **8 seconds** | **Slow banner** | An orange banner above the skeleton: "Taking longer than usual…" "Your connection may be slow." with a Retry button |
| App start, restoring the session, or a whole tab with nothing to show | **Branded loader** | Full screen: app icon (gold border) inside a rotating blue ring, the name ADDONSTATION (pixel font), a **10-segment loader** (segments light up one after another, loop 1.9 s) and "Loading…". Inside a tab keep the bottom bar and use the smaller icon + ring |
Timings: shimmer **1.4 s** loop; ring **1.1 s** per turn; segments **1.9 s**. With "reduce motion" on, turn all animation off (static blocks, ring and segments fully visible).
Skeleton colors: blocks = the text color at 9–17% over the surface color (so they are visible in Dark and Light).
Accessibility: announce "Loading" once to screen readers; skeleton blocks are hidden from them.

## 3. Errors: which page for which error
| Error | Page | Icon color | Primary button | Secondary button |
|---|---|---|---|---|
| No internet / network failure | **Network error** ("No connection" look) | blue | **Retry** | none (only Retry) |
| Server answered 5xx or invalid response | **Server error** | orange | **Retry** | Back to Home |
| No answer within **15 s** | **Request timed out** | purple | **Retry** | Back to Home |
| Session expired / refresh failed (401 or 403) | **Your session ended** | gold | **Sign in** | Continue as guest |
| Anything else | **Something went wrong** | pink | **Retry** | Contact support |
| While retrying | same page, button replaced by a spinner | | | |
Page layout (centered, above the bottom bar): illustration (176 dp: soft glow, dashed ring, rounded 104 dp icon tile in the error color, a few small pixel squares), **title** (pixel font 22 sp), **explanation** (14 sp, muted, max 290 dp wide), optional line, buttons (full width up to 290 dp, height 52 dp, radius 18), optional small chip with the technical code ("Code 503") that copies on tap (for support).
Behaviour:
- **No internet:** retry automatically after 5 s, then 10 s, then 20 s (show "Retrying automatically in 5 s" with a small ring); then wait for the user. Retry immediately when the connection comes back.
- **Session ended:** clear the saved session, then show this page; "Continue as guest" opens Home as a signed-out user.
- Never show raw exception text to the user; log it (crash/diagnostics) instead.

## 4. Errors on top of content that is already there
If the screen already has data (cached or loaded before), **do not replace it with the error page.** Keep the content and show:
| Case | Component |
|---|---|
| Offline | **Banner** (orange): "You are offline. Showing saved content." + Retry |
| Connection returns and refresh succeeds | **Banner** (green): "Back online. Content updated." (hides after 3 s) |
| Server problem during a refresh | **Banner** (red): "Server error. Could not refresh. Showing saved content." + Retry |
| A small action failed (for example refresh from a pull) | **Snackbar** above the bottom bar: "Could not refresh" + Retry |
Use the **full error page only when there is nothing to show.**

## 5. Texts
Existing keys to reuse: `msg_network_error` (Network error), `msg_server_error` (Server error), `msg_generic_error` (Something went wrong), `common_retry` (Retry), `common_loading` (Loading...), `auth_sign_in`.
New texts (English / Arabic):
| English | Arabic |
|---|---|
| Check your Wi-Fi or mobile data, then try again. | تحقق من الواي فاي أو بيانات الجوال ثم حاول مرة أخرى. |
| Retrying automatically in 5 s | إعادة المحاولة تلقائياً بعد 5 ثوانٍ |
| Trying to reconnect… | جارٍ محاولة إعادة الاتصال… |
| Our server is not responding. It is not your connection. Please try again in a moment. | الخادم لا يستجيب، والمشكلة ليست في اتصالك. حاول بعد قليل. |
| Back to Home | العودة للرئيسية |
| Request timed out | انتهت مهلة الطلب |
| The connection is too slow. Move to a better signal and try again. | الاتصال بطيء جداً. انتقل لمكان بإشارة أفضل وحاول مرة أخرى. |
| Your session ended | انتهت جلستك |
| For your safety you were signed out. Sign in again to continue. | لسلامتك تم تسجيل خروجك. سجّل الدخول مرة أخرى للمتابعة. |
| Continue as guest | المتابعة كزائر |
| An unexpected problem happened. Try again, and if it continues contact support. | حدثت مشكلة غير متوقعة. حاول مرة أخرى، وإن استمرت تواصل مع الدعم. |
| Contact support | تواصل مع الدعم |
| Code | الرمز |
| Refreshing… | جارٍ التحديث… |
| Loading more… | جارٍ تحميل المزيد… |
| Taking longer than usual… | التحميل يأخذ وقتاً أطول من المعتاد… |
| Your connection may be slow. | قد يكون اتصالك بطيئاً. |
| You are offline | أنت غير متصل |
| Showing saved content. | نعرض المحتوى المحفوظ. |
| Back online | عاد الاتصال |
| Content updated. | تم تحديث المحتوى. |
| Could not refresh. Showing saved content. | تعذّر التحديث. نعرض المحتوى المحفوظ. |
| Could not refresh | تعذّر التحديث |
(Other six languages follow once these are approved.)

## 6. Where to apply
Store list, addon page, Home, Chat (rooms and room), Profile, Wallet, Notifications, Creators, Settings sub-screens: every screen that loads data uses `LoadingState` while loading and `ErrorState` (or the banner/snackbar when content exists). The splash/branded loader is only for app start and session restore.
