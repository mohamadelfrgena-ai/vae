AddonStation v7.4 - Focus ring: gold/orange glow + white comet (separate file)

src/screens.cpp -> replace the project's file with this one.
It already includes ALL v7.4 changes so far (glow, buttons, gem markers, mascot, settings icons) + this ring.

Focus ring now:
- glow in TWO colours only: gold (inner rings) -> orange (outer rings and ripples)
- a white light-comet circles the frame, one lap every 2.4 s, with a fading tail and a soft warm halo
- core ring (white on dark / black on light), breathing, light sweep on buttons and the small lift are kept

Switches at the top of focusRing():
  kGlowAccent  true = gold/orange | false = neutral white/black
  kComet       the circling comet
  kShine / kLift as before
To change colours edit c1 (inner) and c2 (outer) just below the switches.
No images / no ui.pak step.
