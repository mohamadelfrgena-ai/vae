# AddonStation — UI Spec: Community rules (chat entry gate)

Native Android app (Kotlin, Jetpack Compose, Material 3). Portrait. Design width **390 dp**; sizes are dp/sp. Dark theme is the main design; a Light theme and an Arabic (RTL) version are specified too.
This screen replaces the current "Community rules" screen that appears the first time a user opens the Chat tab. It keeps **all existing texts and behavior** — only the layout, icons and colors change. The bottom navigation bar stays visible (Chat tab selected), as it is today.

## 1. What changes
| Before | Now |
|---|---|
| Title wraps to two lines in the pixel font | Single-line title under a blue shield icon |
| Rules are bullet lines with emoji | One card, one row per rule, vector icon tiles (emoji removed) |
| All rules look the same, the ban/mute warning is just another bullet | The last rule is a separate warning card |
| Big empty space, buttons far from the thumb | Buttons pinned at the bottom just above the bar |
| Green "agree" button (not used anywhere else) | App blue gradient (same as Save / Join the family) |

## 2. Tokens
Dark / Light (same roles as `SPEC_HOME_V2.md`):
| Token | Dark | Light |
|---|---|---|
| bg | `#0A0F1C` | `#F4F7FC` |
| surface | `#121A2B` | `#FFFFFF` |
| border | `#223049` | `#D5DEEC` |
| text | `#EAF0FA` | `#0E1526` |
| textMuted | `#9DB0CF` | `#53627F` |
| card elevation | none | 0 1dp 3dp `#0E1526`@8% |
| warning card bg | gradient 135° `#3A1D0B` → `#1F0F08` | `#FFF1E0` |
| warning border | `#8A4A22` | `#F0B97A` |
| warning text | `#FFD9B3` | `#7A3E00` |
| warning icon | `#F0A04B` | `#C26A00` |
Primary blue gradient 135° `#2E7BEF` → `#4C9AFF` (both themes). Rule accent colors: blue `#4C9AFF`, red `#FF6B78`, orange `#F0A04B`, purple `#9B6BFF`.
Fonts: pixel font `assets/fonts/pixel_regular.ttf` for the English title only (21sp, letter spacing 2sp, uppercase). **Arabic:** use Tajawal ExtraBold 28sp, no letter spacing (the pixel font has no Arabic glyphs). Body: Nunito (Arabic: Tajawal). Min touch target 44dp.

## 3. Layout (top → bottom)
Column filling the screen, bg `bg`. Rules list scrolls if the screen is small or the font scale is large; **header stays at the top, buttons and the bottom bar stay pinned**.
1. **Header** (padding 20/16/0, centered column):
   - Shield icon in a 56×56 circle, gradient blue, white icon 28dp (shield with check), shadow 0 8dp 22dp blue@40%.
   - Title (margin top 12): `chat_rules_title_plain` — English: "COMMUNITY RULES" (pixel 21sp, color text); Arabic: "قواعد المجتمع" (Tajawal 28sp/800). Mark it as a heading for TalkBack.
2. **Rules card** (margin 16/16/0): bg surface, 1dp border, radius 20, clipped. Seven rows, height **52**, padding 0/14, gap 14. Dividers 1dp `border`, inset from the text start (68dp from the start edge).
   - Row = icon tile 40×40, radius 12, bg = accent@15%, 1dp border = accent@33%, icon 22dp tinted with the accent · rule text 15sp/700 text color, weight 1.
   | # | String (plain) | Icon (Material) | Accent |
   |---|---|---|---|
   | 1 | `chat_rule_1_plain` Respect all members | Favorite (heart) | blue `#4C9AFF` |
   | 2 | `chat_rule_2_plain` No insults or harassment | Block (circle-slash) | red `#FF6B78` |
   | 3 | `chat_rule_3_plain` No racism or discrimination | GroupOff (people with a slash) | red `#FF6B78` |
   | 4 | `chat_rule_4_plain` No suspicious links or ads | LinkOff | orange `#F0A04B` |
   | 5 | `chat_rule_5_plain` Do not share personal information | Lock | orange `#F0A04B` |
   | 6 | `chat_rule_6_plain` No inappropriate content | VisibilityOff | red `#FF6B78` |
   | 7 | `chat_rule_7_plain` No politics | AccountBalance (columns) | purple `#9B6BFF` |
3. **Warning card** (margin 12/16/0): radius 16, padding 12×14, gap 12, bg/border from the tokens; Warning (triangle) icon 26dp; text `chat_rule_8_plain` — "Violations may lead to a mute or a ban" — 14sp/800, line height 1.4. This is the 8th existing rule, shown on its own.
4. **Flexible spacer** (min height 12).
5. **Actions** (padding 0/16), pinned above the bar:
   - Primary `chat_accept_enter` — "I agree and enter the chat": full width, height **56**, radius 16, gradient blue, white 17sp/800, Check icon 22dp white before the text (gap 10), shadow 0 8dp 22dp blue@45%.
   - Secondary `chat_decline_home` — "Decline and go home": full width, height 48, margin top 10, radius 16, transparent, 1dp border, text textMuted 15sp/800.
6. **Bottom navigation bar** — as in `SPEC_WALLET_BOTTOMBAR.md` with the **Chat** tab selected (padding 20/12/12 around the bar so the raised Home button fits). Do not hide it on this screen.

## 4. Behavior (unchanged logic)
- Shown the first time a user opens Chat (and again if the rules version changes — keep the existing stored flag; add a `rulesVersion` if there is none).
- **Agree:** save acceptance, go to the chat rooms list. **Decline** and system Back: go to the Home tab, do not save.
- Primary button gets initial accessibility focus; the whole rules card is read as a list ("7 rules"); the warning card is read after it.
- Large fonts / small screens: the card + warning scroll together; keep both buttons visible.
- Signed-out users: keep the existing "Chat is for members only" gate before this screen.

## 5. Arabic (RTL)
`android:supportsRtl="true"`; use start/end. The row layout mirrors (icon tile at the right, text aligned right, divider inset from the right). None of the rule icons need mirroring. Use `chat_rule_*_plain` from `res/values-ar/strings_community_rules.xml`. Allow longer text: rows may grow to two lines (use `heightIn(min = 52.dp)`).

## 6. Strings
The app's current rule strings start with an emoji (`🤝 Respect all members`), which the new icons replace. `res/values/strings_community_rules.xml` and `res/values-ar/strings_community_rules.xml` contain emoji-free copies (`chat_rule_1_plain` … `chat_rule_8_plain`, `chat_rules_title_plain`) with the exact same wording as the existing strings. Keep the old keys for compatibility. `chat_accept_enter` and `chat_decline_home` are unchanged.

## 7. Assets
```
assets/fonts/pixel_regular.ttf, roboto_medium_numbers.ttf
```
No image files: all icons are Material Icons (Favorite, Block, GroupOff, LinkOff, Lock, VisibilityOff, AccountBalance, VerifiedUser or Shield, Warning, Check). Copy fonts to `res/font/`; merge the two strings files into the project (do not overwrite existing files).
